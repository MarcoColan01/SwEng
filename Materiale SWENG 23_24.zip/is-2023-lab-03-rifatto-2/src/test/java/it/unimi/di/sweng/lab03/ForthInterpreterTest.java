package it.unimi.di.sweng.lab03;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.util.NoSuchElementException;


@Timeout(2)
public class ForthInterpreterTest {
  private Interpreter interpreter;

  @BeforeEach
  public void setUp() {
    interpreter = new ForthInterpreter();
  }

  @Test
  public void emptyInputTest() {
    interpreter.input("");
    assertThat(interpreter.toString()).isEqualTo("<- Top");
  }

  @ParameterizedTest
  @CsvSource({"1, 1 <- Top", "1 2, 1 2 <- Top"})
  public void numericInputTest(String input, String output) {
    interpreter.input(input);
    assertThat(interpreter.toString()).isEqualTo(output);
  }

  @ParameterizedTest
  @CsvSource({"1 2, 1 2 <- Top", "'1\n2', 1 2 <- Top", "'1    2  \n3', 1 2 3 <- Top"})
  public void numericInputTest2(String input, String output) {
    interpreter.input(input);
    assertThat(interpreter.toString()).isEqualTo(output);
  }

  @ParameterizedTest
  @CsvSource({"1 2 +, 3 <- Top", "1 2 + 5 +, 8 <- Top"})
  public void sommeTest1(String input, String output) {
    interpreter.input(input);
    assertThat(interpreter.toString()).isEqualTo(output);
  }

  @ParameterizedTest
  @CsvSource({"1 2+, Token error '2+'", "1 2 +5 +, Token error '+5'", "1 +, Stack Underflow"})
  public void sommeTest2(String input, String output) {
    assertThatThrownBy(() -> interpreter.input(input))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessage(output);
  }

  @ParameterizedTest
  @CsvSource({"1 2 *, 2 <- Top", "1 2 * 5 *, 10 <- Top"})
  public void prodottiTest1(String input, String output) {
    interpreter.input(input);
    assertThat(interpreter.toString()).isEqualTo(output);
  }

  @ParameterizedTest
  @CsvSource({"1 2 -, -1 <- Top", "1 2 /, 0 <- Top"})
  public void altreOperazioniTest1(String input, String output) {
    ForthInterpreter interpreter2 = new ExtendedForthInterpreter();
    interpreter2.input(input);
    assertThat(interpreter2.toString()).isEqualTo(output);
  }

  @ParameterizedTest
  @CsvSource({"1 2 3 dup, 1 2 3 3 <- Top", "1 2 3 swap, 1 3 2 <- Top", "1 2 3 drop, 1 2 <- Top"})
  public void altreOperazioniTest2(String input, String output) {
    ForthInterpreter interpreter2 = new ExtendedForthInterpreter();
    interpreter2.input(input);
    assertThat(interpreter2.toString()).isEqualTo(output);
  }

  @ParameterizedTest
  @CsvSource({"1 2 + 3 * 4 dup 5 + drop swap, 4 9 <- Top"})
  public void altreOperazioniTest3(String input, String output) {
    ForthInterpreter interpreter2 = new ExtendedForthInterpreter();
    interpreter2.input(input);
    assertThat(interpreter2.toString()).isEqualTo(output);
  }

  @ParameterizedTest
  @CsvSource({"1 2 + 3 * drop swap"})
  public void altreOperazioniTest4(String input) {
    ForthInterpreter interpreter2 = new ExtendedForthInterpreter();
    assertThatThrownBy(() -> interpreter2.input(input))
            .isInstanceOf(IllegalArgumentException.class);
  }

  @ParameterizedTest
  @CsvSource({": raddoppia 2 * ; 5 raddoppia dup raddoppia, 10 20 <- Top"})
  public void macroTest(String input, String output) {
    interpreter.input(input);
    assertThat(interpreter.toString()).isEqualTo(output);
  }
}

