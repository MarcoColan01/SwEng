package it.unimi.di.sweng.lab03;

public class ExtendedForthInterpreter extends ForthInterpreter {
    public ExtendedForthInterpreter(){
        super();
        operations.put("-", () -> {
            checkStackUnderflow();
            stack.push(-stack.pop() + stack.pop());
        });

        operations.put("/", () -> {
            checkStackUnderflow();
            int denominatore = stack.pop();
            int numeratore = stack.pop();
            stack.push(numeratore/denominatore);
        });

        operations.put("dup", () -> stack.push(stack.getFirst()));

        operations.put("swap", () ->{
            if(stack.size() == 1) throw new IllegalArgumentException();
            int oldTop = stack.pop();
            int newTop = stack.pop();
            stack.push(oldTop);
            stack.push(newTop);
        });

        operations.put("drop", () ->{
            if(stack.size() == 1) throw new IllegalArgumentException();
            stack.removeFirst();
        });
    }
}
