package it.unimi.di.sweng.lab03;
import java.util.*;

public class ForthInterpreter implements Interpreter {
    final Deque<Integer> stack = new LinkedList<>();
    final Map<String, Runnable> operations = new HashMap<>();

    public ForthInterpreter(){
        operations.put("+", () -> {
            checkStackUnderflow();
            stack.push(stack.pop() + stack.pop());
        });
        operations.put("*", () -> {
            checkStackUnderflow();
            stack.push(stack.pop() * stack.pop());
        });
    }

    void checkStackUnderflow() {
        if (stack.size() == 1) throw new IllegalArgumentException("Stack Underflow");
    }

    @Override
    public void input(String program) {
        stack.clear();
        Scanner sc = new Scanner(program);
        while(sc.hasNext()) {
            String app = sc.next();
            if (app.matches("-?[0-9]+")) {
                stack.push(Integer.valueOf(app));
            }else if (operations.containsKey(app)) {
                operations.get(app).run();
            }else if (app.equals(":")){
                String nome = sc.next();
                String definizione = getDefinition(sc);
                operations.put(nome, () -> input(definizione));
            }else{
                throw new IllegalArgumentException("Token error '" + app + "'");
            }
        }
    }

    private String getDefinition(Scanner sc) {
        String def = sc.findInLine(".*?;");
        return def.substring(0,def.length()-1);
    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        if(stack.isEmpty()) return "<- Top";
        for(Integer val: stack){
            sb.insert(0, val + " ");
        }
        return sb.append("<- Top").toString();
    }
}
