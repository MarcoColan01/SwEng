package it.unimi.di.sweng.esame.model;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

class ModelTest {
    @Test
    void getStateEmpty(){
        Model SUT = new Model();
        assertThat(SUT.getState()).isEmpty();
    }

    @Test
    void getStateAfterReadFile(){
        Model SUT = new Model();
        SUT.readFile();
        List<Train> trains = SUT.getState();
        assertThat(trains.size()).isEqualTo(20);
        assertThat(trains).extracting("code", "destination").contains(tuple("TN 10471", "STRADELLA"));
        //extracting: prendi una lista ed estrai solo alcuni campi
    }
}