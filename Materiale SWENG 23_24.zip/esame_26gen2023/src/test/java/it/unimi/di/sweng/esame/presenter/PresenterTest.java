package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.model.Train;
import it.unimi.di.sweng.esame.view.DepartureView;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PresenterTest {
    @Test
    void updateTest() {
        DepartureView view = mock(DepartureView.class);
        DeparturePresenter SUT = new DeparturePresenter(view,0);
        Train train1 = mock(Train.class);
        Train train2 = mock(Train.class);

        //ciò che interessa al presenter è ciò che viene ritornato dal toString di treno
        when(train1.toString()).thenReturn("Cod1 Milano 14:12 10");
        when(train2.toString()).thenReturn("Cod2 Bologna 17:54 0");

        SUT.update(List.of(train1, train2));

        verify(view).set(0, "Cod1 Milano 14:12 10");
        verify(view).set(1, "Cod2 Bologna 17:54 0");
    }
}