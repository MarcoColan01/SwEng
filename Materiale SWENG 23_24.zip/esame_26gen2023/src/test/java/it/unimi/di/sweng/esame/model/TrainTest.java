package it.unimi.di.sweng.esame.model;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.time.Duration;
import java.time.LocalTime;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

class TrainTest {
    @ParameterizedTest
    @CsvSource({
            "12,20,18, 12,22,18",
            "12,24,18, 13,22,18",
            "12,20,18, 12,17,30"
    })
    void compareToLessThan(int ore1, int minuti1, int ritardo1, int ore2, int minuti2, int ritardo2) {
        /*In questo caso, a noi dei treni interessa solo sapere l'orario di partenza e i minuti di ritardo. Ha
        quindi senso implementare un metodo privato del test che crea un nuovo treno di questo tipo */
        Train t1 = creaTreno(ore1, minuti1, ritardo1);
        Train t2 = creaTreno(ore2, minuti2, ritardo2);
        assertThat(t1.compareTo(t2)).isNegative();
    }

    @ParameterizedTest
    @CsvSource({
            "12,20,18, 12,20,18",
            "12,24,18, 12,23,19",
            "12,20,60, 13,20,0"
    })
    void compareToEqual(int ore1, int minuti1, int ritardo1, int ore2, int minuti2, int ritardo2) {
        /*In questo caso, a noi dei treni interessa solo sapere l'orario di partenza e i minuti di ritardo. Ha
        quindi senso implementare un metodo privato del test che crea un nuovo treno di questo tipo */
        Train t1 = creaTreno(ore1, minuti1, ritardo1);
        Train t2 = creaTreno(ore2, minuti2, ritardo2);
        assertThat(t1.compareTo(t2)).isZero();
    }

    @NotNull
    private static Train creaTreno(int ore, int minuti, int ritardo) {
        return new Train("Cod1", "Milano", LocalTime.of(ore, minuti), Duration.ofMinutes(ritardo));
    }

}