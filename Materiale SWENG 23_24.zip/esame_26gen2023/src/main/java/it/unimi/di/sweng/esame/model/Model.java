package it.unimi.di.sweng.esame.model;

import it.unimi.di.sweng.esame.Main;
import it.unimi.di.sweng.esame.presenter.Observer;
import org.jetbrains.annotations.NotNull;

import java.io.InputStream;
import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Model implements Observable<List<Train>> {
    private @NotNull final Map<String, Train> trains = new HashMap<>();
    private @NotNull final List<Observer<List<Train>>> observers = new ArrayList<>();

    public void readFile() {
        InputStream is = Main.class.getResourceAsStream("/trains.csv");
        assert is != null;
        Scanner s = new Scanner(is);

        while (s.hasNextLine()) {
            String linea = s.nextLine();
            String[] el = linea.split(",");
            String cod = el[0];
            String destination = el[1];
            String depTime = el[2];
            String delay = el[3];

            Train train = new Train(cod, destination,
                    LocalTime.parse(depTime, DateTimeFormatter.ofPattern("H:m")),
                    Duration.ofMinutes(Integer.valueOf(delay)));

            trains.put(cod, train);
        }

    }


    @Override
    @NotNull
    public List<Train> getState() {
        return new ArrayList<>(trains.values());
    }

    //MVP deve aggiornare gli observer ogni volta che lo stato viene aggiornato
    @Override
    public void notifyObservers() {
        for (Observer<List<Train>> obs : observers) {
            obs.update(getState());
        }
    }

    @Override
    public void addObserver(@NotNull Observer<List<Train>> observer) {
        observers.add(observer);
    }

    public void departed(String trainCode) {
        if(trains.containsKey(trainCode)){
            trains.remove(trainCode);
            notifyObservers();
        }
    }

    public void changeDelay(String code, int delay){
        if(trains.containsKey(code)){
            Train train = trains.get(code);
            Train train2 = train.newDelay(Duration.ofMillis(delay));
            if(!train.equals(train2)){
                trains.put(code, train2);
                trains.put(code, train2);
                notifyObservers();
            }
        }
    }
}
