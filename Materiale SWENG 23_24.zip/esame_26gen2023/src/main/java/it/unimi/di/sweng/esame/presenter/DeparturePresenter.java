package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.Main;
import it.unimi.di.sweng.esame.model.Model;
import it.unimi.di.sweng.esame.view.DepartureView;
import org.jetbrains.annotations.NotNull;
import it.unimi.di.sweng.esame.model.Train;

import java.util.List;

public class DeparturePresenter implements Observer<List<Train>>, InputPresenter{
    private final DepartureView view;
    private int startTrain;
    private final Model model;

    public DeparturePresenter(DepartureView view, int startTrain, Model model) {
        this.view = view;
        this.startTrain = startTrain;
        this.model = model;
        view.addHandlers(this);
    }

    /*
    Per ogni treno dentro alla lista di treni, setta la vista in modo opportuno (i sarebbe la riga in cui
    viene stampato il treno nella vista)
     */
    @Override
    public void update(@NotNull List<Train> state) {
        int i = 0;
        state.sort(null);
        for (int j = 0; j + startTrain < state.size() && j < Main.MAX_ROW_ITEMS_IN_VIEW; j++) {
            Train train = state.get(j + startTrain);
            view.set(i++, train.toString());
        }
    }

    @Override
    public void action(@NotNull String text1, String text2) {
        model.departed(text1.substring(0,9).trim());
    }
}
