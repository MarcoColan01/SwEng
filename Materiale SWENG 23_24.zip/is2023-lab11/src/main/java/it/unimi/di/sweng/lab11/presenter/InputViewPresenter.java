package it.unimi.di.sweng.lab11.presenter;

import it.unimi.di.sweng.lab11.model.Aliment;
import it.unimi.di.sweng.lab11.model.GroceryListModel;
import it.unimi.di.sweng.lab11.model.Observable;
import it.unimi.di.sweng.lab11.model.Observer;
import it.unimi.di.sweng.lab11.view.InputView;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Objects;

public class InputViewPresenter implements InputPresenter, Observer<List<Aliment>> {
    private final GroceryListModel model;
    private final InputView inputView;
    public InputViewPresenter(GroceryListModel model, InputView inputView) {
        this.model = model;
        this.inputView = inputView;
    }

    @Override
    public void action(@NotNull String text, @NotNull String text1) {
        String message = model.addAliment(text, new Aliment(text, Integer.parseInt(text1)));
        if (!Objects.equals(message, "success")) {
            inputView.showError(message);
        } else {
            inputView.showSuccess();
        }

    }

    @Override
    public void update(@NotNull Observable<List<Aliment>> subject, @NotNull List<Aliment> state) {

    }
}
