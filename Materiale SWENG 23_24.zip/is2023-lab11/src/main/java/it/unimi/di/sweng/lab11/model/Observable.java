package it.unimi.di.sweng.lab11.model;

import org.jetbrains.annotations.NotNull;

public interface Observable<T> {
    void notifyObservers();
    void addObserver(@NotNull Observer<T> observer);
    @NotNull T getState();
}
