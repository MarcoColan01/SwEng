package it.unimi.di.sweng.lab11.model;

import org.jetbrains.annotations.NotNull;

public interface Observer<T> {
    void update(@NotNull Observable<T> subject, @NotNull T state);
}
