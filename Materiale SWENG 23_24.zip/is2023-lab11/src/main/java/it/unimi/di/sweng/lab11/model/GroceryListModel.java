package it.unimi.di.sweng.lab11.model;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import it.unimi.di.sweng.lab11.model.Observer;

public class GroceryListModel implements Observable<List<Aliment>>{
    private final Map<String, Aliment> aliments = new HashMap<>();
    private final List<Observer<List<Aliment>>> observers = new ArrayList<>();
    public String addAliment(String nome, Aliment aliment) {
        if(aliments.size() == 8) return "Non si possono inserire più di 8 alimenti.";
        if(aliment.getToBuyQty() <= 0) return "Non si possono inserire alimenti con quantità da comprare negativa o 0.";
        if(aliments.containsKey(nome)) aliments.get(nome).addToBuyQty(aliment.getToBuyQty());
        else aliments.put(nome, aliment);
        notifyObservers();
        return "success";
    }

    @Override
    public void notifyObservers() {
        for (Observer<List<Aliment>> observer : observers) {
            observer.update(this, getState());
        }
    }

    @Override
    public void addObserver(@NotNull Observer<List<Aliment>> observer) {
        observers.add(observer);
    }

    public @NotNull List<Aliment> getState() {
        return new ArrayList<>(aliments.values());
    }
}
