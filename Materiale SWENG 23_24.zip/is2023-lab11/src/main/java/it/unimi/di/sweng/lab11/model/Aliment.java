package it.unimi.di.sweng.lab11.model;

public class Aliment {
    private final String nome;
    private int toBuyQty;
    private int boughtQty = 0;
    public Aliment(String nome, int toBuyQty) {
        this.nome = nome;
        this.toBuyQty = toBuyQty;
    }

    public String getNome(){
        return nome;
    }

    public int getToBuyQty() {
        return toBuyQty;
    }

    public int getBoughtQty() {
        return boughtQty;
    }

    public void setBoughtQty(int boughtQty) {
        this.boughtQty = boughtQty;
        this.toBuyQty -= boughtQty;
    }

    public void addToBuyQty(int toBuyQty) {
        this.toBuyQty += toBuyQty;
    }

    @Override
    public boolean equals(Object o){
        if(o == this) return true;
        if(!(o instanceof Aliment)) return false;
        Aliment a = (Aliment) o;
        return a.nome == this.nome;
    }
}
