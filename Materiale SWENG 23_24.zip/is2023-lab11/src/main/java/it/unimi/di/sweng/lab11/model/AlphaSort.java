package it.unimi.di.sweng.lab11.model;

import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.List;

public class AlphaSort implements SortStrategy {
    @Override
    public void sortAliments(@NotNull List<Aliment> aliments) {
        aliments.sort(Comparator.comparing(Aliment::getNome));
    }
}
