package it.unimi.di.sweng.lab11.model;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public interface SortStrategy {
    SortStrategy NO_SORT = aliments -> {
        return;
    };
    void sortAliments(@NotNull List<Aliment> aliments);
}
