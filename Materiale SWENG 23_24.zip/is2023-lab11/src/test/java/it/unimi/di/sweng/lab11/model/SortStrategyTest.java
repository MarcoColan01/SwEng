package it.unimi.di.sweng.lab11.model;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIterable;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class SortStrategyTest {
    @Test
    void sortAlimentsTest(){
        SortStrategy SUT = new AlphaSort();
        Aliment aliment1 = mock(Aliment.class);
        Aliment aliment2 = mock(Aliment.class);
        Aliment aliment3 = mock(Aliment.class);
        when(aliment1.getNome()).thenReturn("pollo");
        when(aliment2.getNome()).thenReturn("patate");
        when(aliment3.getNome()).thenReturn("farina");
        List<Aliment> aliments = new ArrayList<>();
        aliments.add(aliment1);
        aliments.add(aliment2);
        aliments.add(aliment3);
        SUT.sortAliments(aliments);
        assertThatIterable(aliments).containsExactly(aliment3, aliment2, aliment1);
    }
}
