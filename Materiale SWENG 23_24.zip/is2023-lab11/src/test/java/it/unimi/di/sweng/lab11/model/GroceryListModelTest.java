package it.unimi.di.sweng.lab11.model;

import org.junit.jupiter.api.Test;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class GroceryListModelTest {
    @Test
    void addAlimentTest(){
        GroceryListModel SUT = new GroceryListModel();
        SUT.addAliment("mele", new Aliment("mele", 3));
        SUT.addAliment("pere", new Aliment("pere", 6));
        assertThat(SUT.getState().size()).isEqualTo(2);
    }

    @Test
    void notAddAlimentTest(){
        GroceryListModel SUT = new GroceryListModel();
        for(int i = 0; i < 8; i++){
            Aliment aliment = mock(Aliment.class);
            when(aliment.getToBuyQty()).thenReturn(1);
            SUT.addAliment(String.valueOf(i), aliment);
        }
        assertThat(SUT.addAliment("carote", mock(Aliment.class)))
                .isEqualTo("Non si possono inserire più di 8 alimenti.");
    }

    @Test
    void notifyObserverTest(){
        GroceryListModel SUT = new GroceryListModel();
        Observer<List<Aliment>> obs1 = mock(Observer.class);
        Observer<List<Aliment>> obs2 = mock(Observer.class);
        SUT.addObserver(obs1);
        SUT.addObserver(obs2);
        SUT.notifyObservers();
        verify(obs1).update(SUT, SUT.getState());
        verify(obs2).update(SUT, SUT.getState());
    }
}