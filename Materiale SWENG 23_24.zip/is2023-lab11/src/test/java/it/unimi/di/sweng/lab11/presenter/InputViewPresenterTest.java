package it.unimi.di.sweng.lab11.presenter;

import it.unimi.di.sweng.lab11.model.Aliment;
import it.unimi.di.sweng.lab11.model.GroceryListModel;
import it.unimi.di.sweng.lab11.view.InputView;
import it.unimi.di.sweng.lab11.view.OutputView;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class InputAlimentPresenterTest {
    @Test
    void actionTest(){
        InputView inputView = mock(InputView.class);
        GroceryListModel model = mock(GroceryListModel.class);
        InputPresenter SUT = new InputViewPresenter(model, inputView);

        SUT.action("tonno", "4");

        verify(model).addAliment("tonno", new Aliment("tonno", 4));
    }

}