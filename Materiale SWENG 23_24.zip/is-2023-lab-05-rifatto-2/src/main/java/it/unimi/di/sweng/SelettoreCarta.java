package it.unimi.di.sweng;

import ca.mcgill.cs.stg.solitaire.cards.Card;
import it.unimi.di.sweng.rubamazzetto.Partita;
import it.unimi.di.sweng.rubamazzetto.Tavolo;

import java.util.List;
import java.util.Random;

public interface SelettoreCarta {
    SelettoreCarta NULL = (mano, partita) -> {
        Random rand = new Random();
        return mano.get(rand.nextInt(mano.size()));
    };
    Card choiseCard(List<Card> mano, Partita partita);
}
