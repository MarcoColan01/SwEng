package it.unimi.di.sweng.rubamazzetto;

import ca.mcgill.cs.stg.solitaire.cards.Card;
import ca.mcgill.cs.stg.solitaire.cards.Rank;
import it.unimi.di.sweng.ChoiseCardEqualsMyTop;
import it.unimi.di.sweng.ChoiseCardOnEnemyTop;
import it.unimi.di.sweng.ChoiseCardOnTable;
import it.unimi.di.sweng.SelettoreCarta;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.List;

public class Giocatore {

  private final String nome;
  private List<Card> mano = new ArrayList<>();
  private Rank mazzettoTop;
  private final Partita partita;

  private int punti;

  public Giocatore(String nome, Partita partita) {
    this.nome = nome;
    partita.addGiocatore(this);
    this.partita = partita;
  }

  public Rank getMazzettoTop() {
    return mazzettoTop;
  }

  public int getPunti() {
    return punti;
  }

  public void daiCarta(Card carta) {
    mano.add(carta);
  }


  public void turno() {
    System.out.println(mano);
    SelettoreCarta chain = new ChoiseCardOnTable(
            new ChoiseCardOnEnemyTop(
                    new ChoiseCardEqualsMyTop(SelettoreCarta.NULL, this), this), this);
    Card cardToPlay = chain.choiseCard(getMano(), partita);
    System.out.println(cardToPlay);
    punti += partita.giocaCarta(this, cardToPlay);

  }

  @Override
  public String toString() {
    StringBuilder s = new StringBuilder(nome);
    s.append(": ");
    s.append("[").append(mano.size()).append("]");
    if (punti > 0) {
      s.append("mazzetto con ");
      s.append(punti);
      s.append(" carte, cima ");
      s.append(mazzettoTop);
      s.append("; ");
    }
    for (Card card : mano) {
      s.append(card.toString());
      s.append(", ");
    }
    return s.toString();
  }

  public int numCards() {
    return mano.size();
  }

  public void setPunti(int punti) {
    this.punti = punti;
  }

  public void mazzoRubato() {
    this.punti = 0;
    this.mazzettoTop = null;
    this.mano = new ArrayList<>();
  }

  public List<Card> getMano() {
    List<Card> cards = new ArrayList<>();
    for(Card card: mano){
      cards.add(Card.get(card.getRank(), card.getSuit()));
    }
    return cards;
  }
}
