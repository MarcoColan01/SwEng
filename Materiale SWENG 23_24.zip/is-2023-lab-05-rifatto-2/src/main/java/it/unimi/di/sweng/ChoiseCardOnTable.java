package it.unimi.di.sweng;

import ca.mcgill.cs.stg.solitaire.cards.Card;
import it.unimi.di.sweng.rubamazzetto.Giocatore;
import it.unimi.di.sweng.rubamazzetto.Partita;
import it.unimi.di.sweng.rubamazzetto.Tavolo;
import java.util.List;

public class ChoiseCardOnTable implements SelettoreCarta{
    private final SelettoreCarta next;
    private final Giocatore me;

    public ChoiseCardOnTable(SelettoreCarta next, Giocatore me) {
        this.me = me;
        this.next = next;
    }

    @Override
    public Card choiseCard(List<Card> mano, Partita partita) {
        System.out.println(mano);
        for(Card card: mano){
            if(partita.controllaSeCartaPresenteSuTavolo(card)) {
                return card;
            }
        }
        return next.choiseCard(mano, partita);
    }
}
