package it.unimi.di.sweng;

import ca.mcgill.cs.stg.solitaire.cards.Card;
import it.unimi.di.sweng.rubamazzetto.Giocatore;
import it.unimi.di.sweng.rubamazzetto.Partita;
import it.unimi.di.sweng.rubamazzetto.Tavolo;

import java.util.Iterator;
import java.util.List;

public class ChoiseCardEqualsMyTop implements SelettoreCarta {
    private final SelettoreCarta next;
    private final Giocatore me;
    public ChoiseCardEqualsMyTop(SelettoreCarta next, Giocatore me) {
        this.next = next;
        this.me = me;
    }

    @Override
    public Card choiseCard(List<Card> mano, Partita partita) {
        Iterator<Card> it = mano.iterator();
        it.next();
        while(it.hasNext()){
            Card card = it.next();
            if(card.getRank().equals(me.getMazzettoTop())) return card;
        }
        return next.choiseCard(mano, partita);
    }
}
