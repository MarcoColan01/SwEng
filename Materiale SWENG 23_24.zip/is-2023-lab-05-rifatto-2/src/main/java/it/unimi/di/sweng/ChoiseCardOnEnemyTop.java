package it.unimi.di.sweng;

import ca.mcgill.cs.stg.solitaire.cards.Card;
import ca.mcgill.cs.stg.solitaire.cards.Rank;
import it.unimi.di.sweng.rubamazzetto.Giocatore;
import it.unimi.di.sweng.rubamazzetto.Partita;
import it.unimi.di.sweng.rubamazzetto.Tavolo;

import java.util.Iterator;
import java.util.List;

public class ChoiseCardOnEnemyTop implements SelettoreCarta {
    private final SelettoreCarta next;
    private final Giocatore me;
    public ChoiseCardOnEnemyTop(SelettoreCarta next, Giocatore me) {
        this.next = next;
        this.me = me;
    }

    @Override
    public Card choiseCard(List<Card> mano, Partita partita) {
        for(Card card: mano){
            for(Giocatore enemy: partita){
                if (enemy.getMazzettoTop().equals(card.getRank()) && enemy != me) {
                    return card;
                }
            }
        }
        return next.choiseCard(mano, partita);
    }
}
