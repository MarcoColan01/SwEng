package it.unimi.di.sweng;

import ca.mcgill.cs.stg.solitaire.cards.Card;
import ca.mcgill.cs.stg.solitaire.cards.Rank;
import ca.mcgill.cs.stg.solitaire.cards.Suit;
import it.unimi.di.sweng.rubamazzetto.Giocatore;
import it.unimi.di.sweng.rubamazzetto.Partita;
import it.unimi.di.sweng.rubamazzetto.Tavolo;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIterable;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class RubaMazzettoTest {

    @InjectMocks
    Partita partita;

    @Mock
    Tavolo tavolo;

    @Mock
    Giocatore giocatore;

    @Mock
    Giocatore giocatore2;

    @Test
    void partitaIterableTest() {
        Partita partita = new Partita();
        List<Giocatore> giocatori = new ArrayList<>(List.of(
                new Giocatore("Marco", partita),
                new Giocatore("Matteo", partita)
        ));
        //when(partita.iterator()).thenReturn(giocatori.iterator());
        assertThatIterable(partita).containsExactlyElementsOf(giocatori);
    }

    @Test
    void distribuisciManoTest() {
        Partita partita = mock(Partita.class);
        partita.distribuisciMano(3);
    }

    @Test
    void checkCardOnTableTest() {
        when(tavolo.inMostra(Card.get(Rank.FIVE, Suit.SPADES))).thenReturn(true);
        assertThat(partita.controllaSeCartaPresenteSuTavolo(
                Card.get(Rank.FIVE, Suit.SPADES))).isTrue();
    }

    @Test
    void giocaCartaTest() {
        when(tavolo.inMostra(Card.get(Rank.FIVE, Suit.SPADES))).thenReturn(true);
        partita.addGiocatore(giocatore);
        assertThat(partita.giocaCarta(giocatore, Card.get(Rank.FIVE, Suit.SPADES)))
                .isEqualTo(2);
    }

    @Test
    void giocaCartaTest2() {
        when(giocatore.getPunti()).thenReturn(20);
        when(giocatore.getMazzettoTop()).thenReturn(Rank.FOUR);
        partita.addGiocatore(giocatore);
        assertThat(partita.giocaCarta(giocatore, Card.get(Rank.FOUR, Suit.SPADES))).isEqualTo(20);
    }

    @Test
    void giocatoreTurnoTest() {
        when(tavolo.inMostra(Card.get(Rank.FOUR, Suit.SPADES))).thenReturn(true);
        partita.addGiocatore(giocatore);
        assertThat(partita.giocaCarta(giocatore, Card.get(Rank.FOUR, Suit.SPADES)))
                .isEqualTo(2);
    }

    @Test
    void giocatoreTurnoTest2() {
        Giocatore giocatore3 = mock(Giocatore.class);
        when(giocatore3.getMazzettoTop()).thenReturn(Rank.QUEEN);
        when(giocatore3.getPunti()).thenReturn(10);
        when(giocatore.getMazzettoTop()).thenReturn(Rank.FIVE);
        when(giocatore.getPunti()).thenReturn(0);
        partita.addGiocatore(giocatore);
        partita.addGiocatore(giocatore3);
        assertThat(partita.giocaCarta(giocatore, Card.get(Rank.QUEEN, Suit.SPADES)))
                .isEqualTo(10);
    }

    @Test
    void strategiaCartaSuTavoloTest() {
        Giocatore player = mock(Giocatore.class);
        Giocatore player2 = mock(Giocatore.class);
        when(tavolo.inMostra(Card.get(Rank.EIGHT, Suit.SPADES))).thenReturn(true);
        when(player.getMano()).thenReturn(List.of(
                Card.get(Rank.EIGHT, Suit.SPADES),
                Card.get(Rank.SIX, Suit.HEARTS),
                Card.get(Rank.TWO, Suit.CLUBS)
        ));
        when(player2.getMano()).thenReturn(List.of(
                Card.get(Rank.SEVEN, Suit.SPADES),
                Card.get(Rank.SIX, Suit.HEARTS),
                Card.get(Rank.TWO, Suit.CLUBS)
        ));
        SelettoreCarta strategia = new ChoiseCardOnTable(SelettoreCarta.NULL, player);
        assertThat(strategia.choiseCard(player.getMano(), partita))
                .isEqualTo(Card.get(Rank.EIGHT, Suit.SPADES));
        assertThat(strategia.choiseCard(player2.getMano(), partita)).isNotEqualTo(null);
    }

    @Test
    void strategiaCartaTopAvversarioTest() {
        Giocatore player = mock(Giocatore.class);
        Giocatore enemy = mock(Giocatore.class);
        Tavolo table = mock(Tavolo.class);

        when(player.getMano()).thenReturn(List.of(
                Card.get(Rank.EIGHT, Suit.SPADES),
                Card.get(Rank.SIX, Suit.HEARTS),
                Card.get(Rank.FIVE, Suit.CLUBS)
        ));

        when(enemy.getMazzettoTop()).thenReturn(Rank.FIVE);
        when(player.getMazzettoTop()).thenReturn(Rank.EIGHT);
        partita.addGiocatore(player);
        partita.addGiocatore(enemy);
        SelettoreCarta strategia = new ChoiseCardOnEnemyTop(SelettoreCarta.NULL, player);
        assertThat(strategia.choiseCard(player.getMano(), partita))
                .isEqualTo(Card.get(Rank.FIVE, Suit.CLUBS));
    }

    @Test
    void strategiaCartaUgualeMioTopTest() {
        Giocatore player = mock(Giocatore.class);
        Tavolo table = mock(Tavolo.class);

        when(player.getMano()).thenReturn(List.of(
                Card.get(Rank.EIGHT, Suit.SPADES),
                Card.get(Rank.SIX, Suit.HEARTS),
                Card.get(Rank.FIVE, Suit.DIAMONDS),
                Card.get(Rank.FOUR, Suit.CLUBS),
                Card.get(Rank.EIGHT, Suit.CLUBS)
        ));

        when(player.getMazzettoTop()).thenReturn(Rank.EIGHT);
        SelettoreCarta strategia = new ChoiseCardEqualsMyTop(SelettoreCarta.NULL, player);
        assertThat(strategia.choiseCard(player.getMano(), partita))
                .isEqualTo(Card.get(Rank.EIGHT, Suit.CLUBS));
    }

    @Test
    void strategieChainedTest1() {
        Giocatore player = mock(Giocatore.class);
        Tavolo table = mock(Tavolo.class);

        when(player.getMano()).thenReturn(List.of(
                Card.get(Rank.EIGHT, Suit.SPADES),
                Card.get(Rank.SIX, Suit.HEARTS),
                Card.get(Rank.FIVE, Suit.DIAMONDS),
                Card.get(Rank.FOUR, Suit.CLUBS),
                Card.get(Rank.EIGHT, Suit.CLUBS)
        ));

        when(player.getMazzettoTop()).thenReturn(Rank.EIGHT);
        SelettoreCarta chain = new ChoiseCardOnTable(
                new ChoiseCardOnEnemyTop(
                        new ChoiseCardEqualsMyTop(SelettoreCarta.NULL, player), player), player);
        assertThat(chain.choiseCard(player.getMano(), partita))
                .isEqualTo(Card.get(Rank.EIGHT, Suit.CLUBS));
    }

}
