package it.unimi.di.sweng.reverseindex;


import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.assertj.core.api.Assertions.assertThat;

public class LetturaDocumentiTest {
    @ParameterizedTest
    @CsvSource({"'Sopra la panca la capra campa\nsotto la panca\nla capra crepa', 3"
    , "'Sopra la panca la capra campa\nsotto la panca', 2"})
    void letturaSempliceTest(String documenti, int nDocumenti){
        InvertedIndex SUT = new InvertedIndex(documenti);
        assertThat(SUT.size()).isEqualTo(nDocumenti);
    }

    @ParameterizedTest
    @CsvSource(
            {"'sotto la panca\nla capra', 'sotto [0]\nla [0, 1]\npanca [0]\ncapra [1]'"
            , "'Sopra la panca la capra campa\nsotto la panca', 'Sopra [0]\nla [0, 1]\npanca [0, 1]\ncapra [0]\ncampa [0]\nsotto [1]'"})
    void outputSemplice(String documenti, String output){
        InvertedIndex SUT = new InvertedIndex(documenti);
        OutputStrategy normalOutput = new NormalOutput();
        assertThat(SUT.produceOutput(normalOutput)).isEqualTo(output);
    }

    @ParameterizedTest
    @CsvSource(
            {"'sotto la panca\nla capra', 'capra [1]\nla [0, 1]\npanca [0]\nsotto [0]'"
                    , "'sopra la panca la capra campa\nsotto la panca', 'campa [0]\ncapra [0]\nla [0, 1]\npanca [0, 1]\nsopra [0]\nsotto [1]'"})
    void outputParoleOrdinateTest(String documenti, String output){
        InvertedIndex SUT = new InvertedIndex(documenti);
        OutputStrategy orderedOutput = new OrderedWordsOutput();
        assertThat(SUT.produceOutput(orderedOutput)).isEqualTo(output);
    }

    @ParameterizedTest
    @CsvSource(
            {"'sotto la panca\nla capra', 'la [0, 1]\nsotto [0]\npanca [0]\ncapra [1]'"
                    , "'sotto la panca\nla capra\nla sotto', 'la [0, 1, 2]\nsotto [0, 2]\npanca [0]\ncapra [1]'"})
    void outputParoleOrdinateIndexTest(String documenti, String output){
        InvertedIndex SUT = new InvertedIndex(documenti);
        OutputStrategy orderedOutput = new OrderedIndexesOutput();
        assertThat(SUT.produceOutput(orderedOutput)).isEqualTo(output);
    }

    @ParameterizedTest
    @CsvSource(
            {"'sotto la panca\nla capra', 'sotto [0]\nla    [0, 1]\npanca [0]\ncapra [1]'"
                    , "'Sopra la panca la capra campa\nsotto la panca', 'Sopra [0]\nla    [0, 1]\npanca [0, 1]\ncapra [0]\ncampa [0]\nsotto [1]'"})
    void outputParoleAllineateTest(String documenti, String output){
        InvertedIndex SUT = new InvertedIndex(documenti);
        OutputStrategy orderedOutput = new AlignedOutput();
        assertThat(SUT.produceOutput(orderedOutput)).isEqualTo(output);
    }

    @ParameterizedTest
    @CsvSource(
            {"'sotto la panca\nla capra', 'sotto la panca\nla capra'"
                    , "'Sopra la panca la capra campa\nsotto la panca', 'Sopra la panca la capra campa\nsotto la panca'"})
    void normalReadInput(String documenti, String output){
        NormalInputCreator normalInput = new NormalInputCreator();
        InvertedIndex SUT = new InvertedIndex(documenti, normalInput);
        assertThat(SUT.toString()).isEqualTo(output);
    }

    @ParameterizedTest
    @CsvSource(
            {"'sotto, la panca!', 'sotto la panca'"
                    , "'Sopra, la panca: la capra campa\nsotto. la panca', 'Sopra la panca la capra campa\nsotto la panca'"})
    void punctuationReadInput(String documenti, String output){
        PunctuationInputCreator punctuationInput = new PunctuationInputCreator();
        InvertedIndex SUT = new InvertedIndex(documenti, punctuationInput);
        assertThat(SUT.toString()).isEqualTo(output);
    }

    @ParameterizedTest
    @CsvSource(
            {"'sotto la panca', 'la', 'sotto panca'"
                    , "'Sopra la panca la capra campa\nsotto la panca', 'la\npanca', 'Sopra capra campa\nsotto'"})
    void stopWordsReadInput(String documenti, String stopWords, String output){
        StopWordsInputCreator stopWordsInput = new StopWordsInputCreator(stopWords);
        InvertedIndex SUT = new InvertedIndex(documenti, stopWordsInput);
        assertThat(SUT.toString()).isEqualTo(output);
    }

}
