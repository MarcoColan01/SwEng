package it.unimi.di.sweng.reverseindex;

public interface InputCreator {
    InputReader createInputReader(String documenti);
}
