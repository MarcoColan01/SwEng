package it.unimi.di.sweng.reverseindex;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Iterator;


public class StopWordsInputReader implements InputReader {

    private final String documenti;
    private final ArrayList<String> stopwords;

    public StopWordsInputReader(String documenti, ArrayList<String> stopwords) {
        this.documenti = documenti;
        this.stopwords = new ArrayList<>(stopwords);
    }

    @NotNull
    @Override
    public Iterator<String> iterator() {
        return new Iterator<>() {
            private final String[] sentences = documenti.split("\n");
            private int currentIndex = 0;

            @Override
            public boolean hasNext() {
                return currentIndex < sentences.length;
            }

            @Override
            public String next() {
                if (!hasNext()) {
                    throw new UnsupportedOperationException("Nessuna frase successiva disponibile.");
                }
                return removeStopWords(sentences[currentIndex++]);
            }
        };
    }

    private String removeStopWords(String sentence) {
        for (String word : stopwords) {
            sentence = sentence.replaceAll("\\s*\\b" + word + "\\b", "");
        }
        return sentence;
    }
}
