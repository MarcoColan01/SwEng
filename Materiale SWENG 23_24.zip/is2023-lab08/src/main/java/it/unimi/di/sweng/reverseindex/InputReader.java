package it.unimi.di.sweng.reverseindex;

public interface InputReader extends Iterable<String> {
}
