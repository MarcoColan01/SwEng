package it.unimi.di.sweng.reverseindex;

import org.jetbrains.annotations.NotNull;

import java.util.Iterator;

public class NormalInputReader implements InputReader {
    private final String documenti;
    public NormalInputReader(String documenti) {
        this.documenti = documenti;
    }
    @NotNull
    @Override
    public Iterator<String> iterator() {
        return new Iterator<>() {
            private final String[] sentences = documenti.split("\n");
            private int currentIndex = 0;

            @Override
            public boolean hasNext() {
                return currentIndex < sentences.length;
            }

            @Override
            public String next() {
                if (!hasNext()) {
                    throw new UnsupportedOperationException("Nessuna frase successiva disponibile.");
                }
                return sentences[currentIndex++];
            }
        };
    }
}
