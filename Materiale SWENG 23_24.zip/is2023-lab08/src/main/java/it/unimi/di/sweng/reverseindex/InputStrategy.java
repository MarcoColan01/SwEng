package it.unimi.di.sweng.reverseindex;

public interface InputStrategy {

}
