package it.unimi.di.sweng.reverseindex;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class NormalOutput extends AbstractOutput {

    @Override
    public String produceOutput(List<Documento> documenti) {
        riempiMappa(documenti);

        StringBuilder sb = new StringBuilder();
        for (String parola : occorrenze.keySet())
            sb.append(parola).append(" ").append(occorrenze.get(parola).toString()).append('\n');

        return sb.deleteCharAt(sb.length()-1).toString();
    }
}
