package it.unimi.di.sweng.reverseindex;

import org.jetbrains.annotations.NotNull;

import java.text.Normalizer;
import java.util.Iterator;

public class PunctuationInputReader implements InputReader {
    private final String documenti;
    public PunctuationInputReader(String documenti) {
        this.documenti = documenti;
    }
    @NotNull
    @Override
    public Iterator<String> iterator() {
        return new Iterator<>() {
            private final String[] sentences = documenti.split("\n");
            private int currentIndex = 0;

            @Override
            public boolean hasNext() {
                return currentIndex < sentences.length;
            }

            @Override
            public String next() {
                if (!hasNext()) {
                    throw new UnsupportedOperationException("Nessuna frase successiva disponibile.");
                }
                return removePunctuation(sentences[currentIndex++]);
            }
        };
    }

    private static String removePunctuation(String input) {
        String normalizedString = Normalizer.normalize(input, Normalizer.Form.NFD);
        String regex = "[^\\p{Alnum}\\s]"; // esclude caratteri non alfanumerici
        return normalizedString.replaceAll(regex, "");
    }
}
