package it.unimi.di.sweng.reverseindex;

import java.util.List;

public class AlignedOutput extends AbstractOutput {
    @Override
    public String produceOutput(List<Documento> documenti) {
        riempiMappa(documenti);
        int lenMax = getLenMax();
        StringBuilder sb = new StringBuilder();
        for (String parola : occorrenze.keySet()) {
            sb.append(parola).append(" ");
            createSpace(parola, lenMax, sb);
            sb.append(occorrenze.get(parola).toString()).append('\n');
        }
        return sb.deleteCharAt(sb.length() - 1).toString();
    }

    private static void createSpace(String parola, int lenMax, StringBuilder sb) {
        for (int i = 0; i < (lenMax - parola.length()); i++) {
            sb.append(" ");
        }
    }

    private int getLenMax() {
        int lenMax = 0;
        for (String parola1 : occorrenze.keySet()) {
            if (parola1.length() > lenMax) lenMax = parola1.length();
        }
        return lenMax;
    }
}
