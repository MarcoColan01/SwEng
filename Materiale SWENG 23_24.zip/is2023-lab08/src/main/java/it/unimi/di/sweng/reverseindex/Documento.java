package it.unimi.di.sweng.reverseindex;

import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.Iterator;

public class Documento implements Iterable<String> {
    private final String parole;

    public Documento(String s) {
        this.parole = s;
    }

    @NotNull
    @Override
    public Iterator<String> iterator() {
        return Arrays.stream(parole.split(" ")).iterator();
    }

    @Override
    public String toString() {
        return parole;
    }
}
