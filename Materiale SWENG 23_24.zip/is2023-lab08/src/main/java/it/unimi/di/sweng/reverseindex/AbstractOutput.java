package it.unimi.di.sweng.reverseindex;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public abstract class AbstractOutput implements OutputStrategy{
    HashMap<String, List<Integer>> occorrenze = new LinkedHashMap<>();

    void riempiMappa(List<Documento> documenti) {
        int index = 0;
        for (Documento doc : documenti) {
            for (String parola : doc) {
                if (!occorrenze.containsKey(parola)) {
                    occorrenze.put(parola, new ArrayList<>());
                    occorrenze.get(parola).add(index);
                } else if (!occorrenze.get(parola).contains(index)) {
                    occorrenze.get(parola).add(index);
                }
            }
            index++;
        }
    }

}
