package it.unimi.di.sweng.reverseindex;

public class PunctuationInputCreator implements InputCreator {
    @Override
    public InputReader createInputReader(String documenti) {
        return new PunctuationInputReader(documenti);
    }
}
