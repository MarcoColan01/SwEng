package it.unimi.di.sweng.reverseindex;

import java.util.*;

public class OrderedWordsOutput extends AbstractOutput {

    @Override
    public String produceOutput(List<Documento> documenti) {
        riempiMappa(documenti);
        StringBuilder sb = new StringBuilder();
        SortedSet<String> keys = new TreeSet<>(occorrenze.keySet());
        for (String parola : keys) {
            sb.append(parola).append(" ").append(occorrenze.get(parola).toString()).append('\n');
        }
        return sb.deleteCharAt(sb.length()-1).toString();
    }


}
