package it.unimi.di.sweng.reverseindex;

public class NormalInputCreator implements InputCreator {
    @Override
    public InputReader createInputReader(String documenti) {
        return new NormalInputReader(documenti);
    }
}
