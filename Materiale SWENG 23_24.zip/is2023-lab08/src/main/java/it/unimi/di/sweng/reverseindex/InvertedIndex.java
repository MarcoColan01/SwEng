package it.unimi.di.sweng.reverseindex;

import java.util.ArrayList;
import java.util.List;

public class InvertedIndex {
    private final List<Documento> documenti = new ArrayList<>();
    public InvertedIndex(String documenti) {
        for(String s : documenti.split("\n")){
            Documento documento = new Documento(s);
            this.documenti.add(documento);
        }
    }

    public InvertedIndex(String documenti, InputCreator creatorInput) {
        InputReader currentReader = creatorInput.createInputReader(documenti);
        for(String s : currentReader){
            Documento documento = new Documento(s);
            this.documenti.add(documento);
        }
    }

    public int size() {
        return documenti.size();
    }

    public String produceOutput(OutputStrategy strategy) {
        return strategy.produceOutput(new ArrayList<>(documenti));
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Documento doc : documenti) {
            sb.append(doc.toString()).append('\n');
        }
        return sb.deleteCharAt(sb.length()-1).toString();
    }
}
