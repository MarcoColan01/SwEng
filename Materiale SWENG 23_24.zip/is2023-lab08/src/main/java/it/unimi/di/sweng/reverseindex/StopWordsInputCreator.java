package it.unimi.di.sweng.reverseindex;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StopWordsInputCreator implements InputCreator {
    private final List<String> stopwords = new ArrayList<>();
    public StopWordsInputCreator(String stopWords) {
        this.stopwords.addAll(Arrays.asList(stopWords.split("\n")));
    }

    @Override
    public InputReader createInputReader(String documenti) {
        return new StopWordsInputReader(documenti, new ArrayList<>(stopwords));
    }
}
