package it.unimi.di.sweng.reverseindex;

public interface InputFactory {
    InputStrategy createInputNoPuntuaction();
}
