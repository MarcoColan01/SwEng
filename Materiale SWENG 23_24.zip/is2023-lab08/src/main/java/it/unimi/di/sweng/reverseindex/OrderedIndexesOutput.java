package it.unimi.di.sweng.reverseindex;

import java.util.*;

public class OrderedIndexesOutput extends AbstractOutput {
    @Override
    public String produceOutput(List<Documento> documenti) {
        riempiMappa(documenti);
        StringBuilder sb = new StringBuilder();
        ArrayList<String> orderedKeys = new ArrayList<>(occorrenze.keySet());
        orderedKeys.sort((o1, o2) -> {
            if (occorrenze.get(o1).size() > occorrenze.get(o2).size()) {
                return 1;
            }
            return -1;
        });
        Collections.reverse(orderedKeys);
        
        for (String parola : orderedKeys) {
            sb.append(parola).append(" ").append(occorrenze.get(parola).toString()).append('\n');
        }
        return sb.deleteCharAt(sb.length()-1).toString();
    }
}
