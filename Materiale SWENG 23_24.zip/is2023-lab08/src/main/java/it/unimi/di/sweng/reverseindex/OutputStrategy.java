package it.unimi.di.sweng.reverseindex;

import java.util.List;

public interface OutputStrategy {

    String produceOutput(List<Documento> documenti);
}
