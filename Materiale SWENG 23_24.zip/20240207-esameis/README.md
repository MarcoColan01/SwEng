# CORSO INGEGNERIA DEL SOFTWARE A.A. 2023/24

## APPELLO DEL 7 FEBBRAIO 2024

Marco Colangelo   matricola 980701

Occorre effettuare il fork di questo repository e modificare questo README
inserendo l'anagrafica seguendo lo schema sopra riportato. Inoltre vanno
concessi i permessi di lettura ai docenti (`carlo.bellettini` e `mattia.monga`).

## ELEZIONI NAZIONALI

Obiettivo dell'esercizio è progettare e realizzare un insieme di classi atte a
produrre un semplice programma Java che si occupi di raccogliere e mostrare i
voti espressi in una votazione che coinvolge macro-aree geografiche per le quali
è necessario scrutinare anche i risultati locali.

Sono candidate, in tutte le macro-aree, i seguenti partiti:

- PDI,
- PCI,
- PRI,
- PSI,
- PPI,
- PLI;

Le macro-aree geografiche sono:

- NORTH_WEST,
- NORTH_EAST,
- CENTRAL,
- SOUTH,
- ISLANDS;

Vengono già fornite due *Viste* del sistema:

- [`InputVote`](src/main/java/it/unimi/di/sweng/esame/view/InputVote.java):
  permette di immettere il voto per un partito in una determinata macro-area
  geografica.
- [`DisplayView`](src/main/java/it/unimi/di/sweng/esame/view/DisplayView.java):
  permette di visualizzare un elenco di risultati elettorali.

Viene fornita anche una prima versione della classe  [`Main`](src/main/java/it/unimi/di/sweng/esame/Main.java) che
permette d'istanziare la parte statica delle viste, e di una
interfaccia [`InputPresenter`](src/main/java/it/unimi/di/sweng/esame/presenter/InputPresenter.java).

**TUTTE LE CLASSI DATE POSSONO ESSERE DA VOI MODIFICATE (CANCELLATE, COMPLETATE) PER ADERIRE A VOSTRE IDEE DI
PROGETTAZIONE**

Lanciando il programma (tramite il task `run` di gradle) si ottiene una interfaccia simile a quella nella figura
sottostante **(le viste sono state adesso disposte in orizzontale per evitare problemi con schermi piccoli)**.

![GUI](bootGUI.png)

## TRACCIA

Completare, in modo da realizzare un'organizzazione del sistema di tipo
*Model-View-Presenter*, aggiungendo le classi necessarie in modo che
all'immissione di un nuovo voto le viste si aggiornino coerentemente:

- La vista "National Vote" deve mostrare il totale dei voti espressi per i 5
  partiti più votati a livello nazionale;
  la vista è ordinata in modo che il partito con più voti sia in cima (non è
  specificato alcun comportamento per il caso in cui due partiti abbiano lo
  stesso numero di voti).
- La vista "District Winners" deve mostrare il partito che ha ottenuto più voti
  in ciascuna macro-area geografica;
  la vista è ordinata secondo l'ordine delle macro-aree geografiche sopra
  riportato.


### Esempi di esecuzione

Il codice fornite prevede anche alcuni test di integrazione:

`testDisplayStart` controlla che all'inizio la situazione sia:

![GUI](img_testDisplayStart.png)

`testCorrectSingleInput` controlla che dopo una singola immissione ( al PLI nel
NORTH_EAST) la situazione sia:

![GUI](img_testCorrectSingleInput.png)

`testCorrectMultiInput` controlla che dopo alcune immissioni (voto al PLI nel
NORTH_EAST e NORTH_WEST) la situazione sia:

![GUI](img_testCorrectMultiInput.png)

`testCorrectOrderedNationalDisplay` controlla che dopo 6 immissioni (vedi
codice) l'ordine dei risultati nazionali sia corretto:

![GUI](img_testCorrectOrderedNationalDisplay.png)

`testCorrectOrderedDistrictDisplay` controlla che dopo 9 immissioni (vedi
codice) l'ordine dei risultati per macro-area sia corretto:

![GUI](img_testCorrectOrderedDistrictDisplay.png)


### Gestione input errati

Nel caso in cui l'utente inserisca un input non valido (ad esempio un partito o
una macro-area inesistente o vuota) il sistema
deve mostrare un messaggio di errore (tramite il metodo `showError`) nella vista appropriata.

![GUI](img_1_testInputError.png)
![GUI](img_2_testInputError.png)

![GUI](img_3_testInputError.png)
![GUI](img_4_testInputError.png)

Oltre che nei **test di unità**, potete se volete anche aggiungere nuovi **test di integrazione** .

### Processo

Una volta effettuato il **clone** del repository, il gruppo completa l'implementazione seguendo la *metodologia TDD*;
in maggior dettaglio, ripete i passi seguenti fino ad aver implementato tutte le funzionalità richieste:

* scelta la prossima funzionalità richiesta da implementare, inizia una feature di gitflow
* implementa un test per la funzionalità,
* verifica che **il codice compili correttamente**, ma l'**esecuzione del test fallisca**; solo a questo punto effettua
  un *commit*
  (usando `IntelliJ` o `git add` e `git commit`) iniziando il messaggio di commit con la stringa `ROSSO:`,
* aggiunge la minima implementazione necessaria a realizzare la funzionalità, in modo che **il test esegua con
  successo**; solo a questo punto
  effettua un *commit* (usando `IntelliJ` o `git add` e `git commit`) iniziando il messaggio di commit con la
  stringa `VERDE:`,
* procede, se necessario, al **refactoring** del codice, accertandosi che le modifiche non
  comportino il fallimento di alcun test; solo in questo caso fa seguire a ogni
  passo un *commit* (usando `IntelliJ` o `git add` e `git commit`)
  iniziando il messaggio di commit con la stringa `REFACTORING:`,
* ripete i passi precedenti fino a quando non considera la funzionalità realizzata nel suo complesso e allora chiude la
  feature di gitflow
* effettua un *push* dei passi svolti su `gitlab.di.unimi.it` con `IntelliJ` o`git push --all`.

### Testing

Mano a mano che si sviluppa il progetto, si deve controllare di mantenere una copertura, sia dei comandi che delle
decisioni, soddisfacente soprattutto per il codice rilaciato all'utente (se inferiore al 100% inserire un commento che spieghi perché non è possibile raggiungerlo).

Sono presenti anche alcuni test di integrazione che (una volta completato nella inizializzazione) il progetto
alla fine "dovrebbe" passare. 

### Consegna

Al termine del laboratorio dovete impacchettare l'**ultima versione stabile** come
una _release_ di gitflow chiamata "consegna" (usare esattamente questo nome) ed
effettuare un ultimo *push* di tutti i rami locali (**comprese eventuali feature
aperte ma non completate**); si ricordi anche che per i tag occorre un *push*
esplicito (`git push --tags`).

## **Verificate su `gitlab.di.unimi.it`** che ci sia la completa traccia dei *commit* effettuati nei vari *branch* e che ci siano anche i *tag*. Infine chiaramente anche di averne dato visibilità ai docenti. 
