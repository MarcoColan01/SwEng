package it.unimi.di.sweng.esame.view;


import static org.assertj.core.api.Assertions.assertThat;
import static org.testfx.api.FxAssert.verifyThat;
import static org.testfx.util.NodeQueryUtils.hasText;

import it.unimi.di.sweng.esame.Main;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import org.assertj.core.util.introspection.FieldSupport;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.testfx.api.FxRobot;
import org.testfx.framework.junit5.ApplicationExtension;
import org.testfx.framework.junit5.Start;


@ExtendWith(ApplicationExtension.class)
public class TestIntegrazione {
  private static final boolean HEADLESS = false;

  private OutputView nationalDisplay;
  private OutputView districtDisplay;
  private Label errorMessage;
  private TextField partyName;
  private TextField districtName;
  private Button voteButton;

  @BeforeAll
  public static void setupSpec() {
    if (HEADLESS) System.setProperty("testfx.headless", "true");
  }

  @Start
  public void start(@NotNull Stage primaryStage) {

    Main m = new Main();
    m.start(primaryStage);

    GridPane gp = (GridPane) primaryStage.getScene().getRoot();
    ObservableList<Node> view = gp.getChildren();

    InputVote input = (InputVote) view.get(0);
    nationalDisplay = (DisplayView) view.get(1);
    districtDisplay = (DisplayView) view.get(2);

    partyName = FieldSupport.EXTRACTION.fieldValue("partyName", TextField.class, input);
    districtName = FieldSupport.EXTRACTION.fieldValue("districtName", TextField.class, input);
    voteButton = FieldSupport.EXTRACTION.fieldValue("voteButton", Button.class, input);
    errorMessage = FieldSupport.EXTRACTION.fieldValue("error", Label.class, input);
  }

  @ParameterizedTest()
  @CsvSource(textBlock = """
      '' , SOUTH, empty party name
      PLI, ''   , empty district name
      PZI, SOUTH, not a party name
      PLI, BOH, not a district name
      """)
  void testInputError(String party, String district, String error, @NotNull FxRobot robot) {
    vote(party, district, robot);

    verifyThat(errorMessage, hasText(error));
  }

  @Test
  public void testDisplayStart() {
    assertThat(nationalDisplay.get(0)).isEqualTo("");
    assertThat(districtDisplay.get(0)).isEqualTo("");
  }

  @Test
  void testCorrectSingleInput(@NotNull FxRobot robot) {
    vote("PLI", "NORTH_EAST", robot);

    verifyThat(errorMessage, hasText(""));
    assertThat(nationalDisplay.get(0)).startsWith("PLI").endsWith("1");
    assertThat(districtDisplay.get(0)).startsWith("NORTH_EAST:").endsWith("PLI (1)");
  }

  @Test
  void testCorrectMultiInput(@NotNull FxRobot robot) {
    vote("PLI", "NORTH_EAST", robot);
    vote("PLI", "NORTH_WEST", robot);

    verifyThat(errorMessage, hasText(""));
    assertThat(nationalDisplay.get(0)).startsWith("PLI").endsWith("2");
    assertThat(districtDisplay.get(0)).endsWith("PLI (1)");
    assertThat(districtDisplay.get(1)).endsWith("PLI (1)");
  }

  @Test
  void testCorrectOrderedNationalDisplay(@NotNull FxRobot robot) {
    vote("PLI", "NORTH_EAST", robot);

    //FAST FAIL
    assertThat(nationalDisplay.get(0)).startsWith("PLI");

    vote("PLI", "NORTH_EAST", robot);
    vote("PLI", "SOUTH", robot);

    vote("PRI", "ISLANDS", robot);

    vote("PPI", "NORTH_EAST", robot);
    vote("PPI", "SOUTH", robot);


    verifyThat(errorMessage, hasText(""));
    assertThat(nationalDisplay.get(0)).startsWith("PLI").endsWith("3");
    assertThat(nationalDisplay.get(1)).startsWith("PPI").endsWith("2");
    assertThat(nationalDisplay.get(2)).startsWith("PRI").endsWith("1");
  }

  @Test
  void testCorrectOrderedDistrictDisplay(@NotNull FxRobot robot) {
    vote("PLI", "SOUTH", robot);

    //FAST FAIL
    assertThat(districtDisplay.get(0)).startsWith("SOUTH:");

    vote("PLI", "NORTH_EAST", robot);
    vote("PLI", "NORTH_EAST", robot);
    vote("PPI", "NORTH_EAST", robot);

    vote("PRI", "ISLANDS", robot);

    vote("PPI", "NORTH_WEST", robot);

    vote("PPI", "CENTRAL", robot);
    vote("PPI", "CENTRAL", robot);
    vote("PPI", "CENTRAL", robot);


    verifyThat(errorMessage, hasText(""));
    assertThat(districtDisplay.get(0)).startsWith("NORTH_WEST").endsWith("PPI (1)");
    assertThat(districtDisplay.get(1)).startsWith("NORTH_EAST").endsWith("PLI (2)");
    assertThat(districtDisplay.get(2)).startsWith("CENTRAL").endsWith("PPI (3)");
    assertThat(districtDisplay.get(3)).startsWith("SOUTH").endsWith("PLI (1)");
    assertThat(districtDisplay.get(4)).startsWith("ISLANDS").endsWith("PRI (1)");
  }

  private void vote(String party, String district, @NotNull FxRobot robot) {
    writeOnGui(robot, partyName, party);
    writeOnGui(robot, districtName, district);
    robot.clickOn(voteButton);
  }

  private void writeOnGui(@NotNull FxRobot robot, TextField input, String text) {
    robot.doubleClickOn(input);
    robot.write(text, 0);
  }

}
