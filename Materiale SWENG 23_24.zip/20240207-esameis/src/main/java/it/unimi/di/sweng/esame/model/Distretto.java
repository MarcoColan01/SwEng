package it.unimi.di.sweng.esame.model;

public enum Distretto {
    NORTH_WEST,
    NORTH_EAST,
    CENTRAL,
    SOUTH,
    ISLANDS;
}
