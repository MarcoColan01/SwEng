package it.unimi.di.sweng.esame.model;

import it.unimi.di.sweng.esame.Observable;
import it.unimi.di.sweng.esame.Observer;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class Model implements Observable<Voti> {
    private final @NotNull Voti voti = new Voti();
    private final @NotNull List<Observer<Voti>> observers = new ArrayList<>();

    public void addVoto(@NotNull Voto voto){
        voti.addVoto(voto);
        notifyObservers();
    }

    public @NotNull List<Voto> getVoti(){
        return voti.getVoti();
    }

    public @NotNull List<VotiPartito> getVotiNazionali(){
        return voti.getVotiNazionali();
    }

    @Override
    public void notifyObservers() {
        for (Observer<Voti> observer : observers) {
            observer.update(getState());
        }
    }

    @Override
    public void addObserver(@NotNull Observer<Voti> observer) {
        observers.add(observer);
    }

    @Override
    public @NotNull Voti getState() {
        return voti;
    }
}
