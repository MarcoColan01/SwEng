package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.Main;
import it.unimi.di.sweng.esame.Observer;
import it.unimi.di.sweng.esame.model.Model;
import it.unimi.di.sweng.esame.model.Voti;
import it.unimi.di.sweng.esame.view.OutputView;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class DisplayPresenter implements Observer<Voti> {
    private final @NotNull OutputView view;
    private final @NotNull Model model;
    private final @NotNull DisplayStrategy strategy;
    public DisplayPresenter(@NotNull OutputView view, @NotNull Model model, @NotNull DisplayStrategy strategy) {
        this.strategy = strategy;
        this.model = model;
        this.view = view;
        model.addObserver(this);
    }

    @Override
    public void update(@NotNull Voti state) {
        int i = 0;
        List<String> voti;
        if(strategy instanceof NationalVotesStrategy) voti =  strategy.getOutput(state.getVotiNazionali());
        else voti = strategy.getOutput(state.getVoti());
        for(int j = 0; j < voti.size() && j < Main.VIEWSIZE; j++){
            view.set(i++, voti.get(j));
        }
        if(i < Main.VIEWSIZE){
            for(int j = i; j < Main.VIEWSIZE; j++){
                view.set(j, "");
            }
        }
    }
}
