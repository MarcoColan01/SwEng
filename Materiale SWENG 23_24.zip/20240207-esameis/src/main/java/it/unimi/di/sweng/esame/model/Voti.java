package it.unimi.di.sweng.esame.model;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Voti {
    private final @NotNull Map<Partito, VotiPartito> votiNazionali = new HashMap<>();
    private final @NotNull List<Voto> voti = new ArrayList<>();

    public void addVoto(@NotNull Voto voto) {
        if(!votiNazionali.containsKey(voto.partito())){
            votiNazionali.put(voto.partito(), new VotiPartito(voto.partito(), 1));
        }else{
            int nVoti = votiNazionali.get(voto.partito()).voti();
            votiNazionali.replace(voto.partito(), new VotiPartito(voto.partito(), nVoti+1));
        }
        voti.add(new Voto(voto.partito(), voto.distretto()));
    }
    public @NotNull List<VotiPartito> getVotiNazionali() {
        return new ArrayList<>(votiNazionali.values());
    }

    public @NotNull List<Voto> getVoti() {
        return new ArrayList<>(voti);
    }
}
