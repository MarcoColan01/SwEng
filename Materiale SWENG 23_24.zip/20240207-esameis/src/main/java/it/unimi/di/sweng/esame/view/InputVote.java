package it.unimi.di.sweng.esame.view;

import it.unimi.di.sweng.esame.presenter.InputPresenter;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import org.jetbrains.annotations.NotNull;

public class InputVote extends Region implements InputView {

    private final @NotNull TextField partyName = new TextField();
    private final @NotNull TextField districtName = new TextField();
    private final @NotNull Button voteButton = new Button("Vote");
    private final @NotNull Label error = new Label("");


    public InputVote() {
        setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, new CornerRadii(5.0), Insets.EMPTY)));
        setBorder(new Border(new BorderStroke(null, BorderStrokeStyle.SOLID, new CornerRadii(5.0), new BorderWidths(2))));

        partyName.setPromptText("party name");
        districtName.setPromptText("district name");

        partyName.setPrefColumnCount(8);
        districtName.setPrefColumnCount(14);
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.add(partyName, 0, 0);
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.add(districtName, 1, 0);
        grid.add(voteButton, 2, 0);
        grid.add(error, 0, 1);

        this.getChildren().add(grid);
    }

    public void addHandlers(@NotNull InputPresenter presenter) {
        voteButton.setOnAction(eh -> presenter.action(partyName.getText(), districtName.getText()));
    }

    @Override
    public void showError(@NotNull String s) {
        error.setText(s);
        setBackground(new Background(new BackgroundFill(Color.YELLOW, new CornerRadii(5.0), Insets.EMPTY)));
    }

    @Override
    public void showSuccess() {
        error.setText("");
        partyName.clear();
        districtName.clear();
        setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, new CornerRadii(5.0), Insets.EMPTY)));
    }
}
