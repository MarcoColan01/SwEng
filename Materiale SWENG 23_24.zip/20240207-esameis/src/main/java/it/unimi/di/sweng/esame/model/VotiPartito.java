package it.unimi.di.sweng.esame.model;

import org.jetbrains.annotations.NotNull;

public record VotiPartito(@NotNull Partito partito, int voti) {
}
