package it.unimi.di.sweng.esame;

import it.unimi.di.sweng.esame.model.Model;
import it.unimi.di.sweng.esame.presenter.DisplayPresenter;
import it.unimi.di.sweng.esame.presenter.DistrictWinnersStrategy;
import it.unimi.di.sweng.esame.presenter.InputVotePresenter;
import it.unimi.di.sweng.esame.presenter.NationalVotesStrategy;
import it.unimi.di.sweng.esame.view.DisplayView;
import it.unimi.di.sweng.esame.view.InputVote;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import org.jetbrains.annotations.NotNull;


public class Main extends Application {
    public static final int VIEWSIZE = 5;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(@NotNull Stage primaryStage) {

        primaryStage.setTitle("Elections 2024");

        DisplayView national = new DisplayView(VIEWSIZE, "National Votes");
        DisplayView regions = new DisplayView(VIEWSIZE, "District Winners");

        InputVote input = new InputVote();

        GridPane gridPane = new GridPane();
        gridPane.setBackground(new Background(new BackgroundFill(Color.DARKGRAY, CornerRadii.EMPTY, Insets.EMPTY)));
        gridPane.setPadding(new Insets(10, 10, 10, 10));

        gridPane.add(input, 0, 0);
        GridPane.setColumnSpan(input, GridPane.REMAINING);

        gridPane.add(national, 0, 1);
        gridPane.add(regions, 1, 1);
        Model model = new Model();
        new InputVotePresenter(input, model);
        new DisplayPresenter(national, model, NationalVotesStrategy.INSTANCE);
        new DisplayPresenter(regions, model, DistrictWinnersStrategy.INSTANCE);
        model.notifyObservers();

        Scene scene = new Scene(gridPane);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
