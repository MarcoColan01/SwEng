package it.unimi.di.sweng.esame.model;

import org.jetbrains.annotations.NotNull;

public record Voto(@NotNull Partito partito, @NotNull Distretto distretto) {
    public static Voto creaVoto(@NotNull String party, @NotNull String district){
        if(party.isBlank()) throw new IllegalArgumentException("empty party name");
        if(district.isBlank()) throw new IllegalArgumentException("empty district name");
        Partito partito = Partito.valueOf(party);
        Distretto distretto = Distretto.valueOf(district);
        return new Voto(partito, distretto);
    }
}
