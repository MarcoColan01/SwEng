package it.unimi.di.sweng.esame.presenter;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public interface DisplayStrategy<T> {
    void sortVotes(@NotNull List<T> voti);

    List<String> getOutput(List<T> voti);
}
