package it.unimi.di.sweng.esame.presenter;


import it.unimi.di.sweng.esame.model.Model;
import it.unimi.di.sweng.esame.model.Voto;
import it.unimi.di.sweng.esame.view.InputView;
import org.jetbrains.annotations.NotNull;

public class InputVotePresenter implements InputPresenter {
    private final @NotNull InputView view;
    private final @NotNull Model model;

    public InputVotePresenter(@NotNull InputView view, @NotNull Model model) {
        this.view = view;
        this.model = model;
        view.addHandlers(this);
    }

    @Override
    public void action(@NotNull String partito, @NotNull String regione) {

        try {
            Voto voto = Voto.creaVoto(partito, regione);
            model.addVoto(voto);
            view.showSuccess();
        } catch (IllegalArgumentException e) {
            if (e.getMessage().startsWith("No enum constant it.unimi.di.sweng.esame.model.Partito.")) {
                view.showError("not a party name");
                return;
            }
            if (e.getMessage().startsWith("No enum constant it.unimi.di.sweng.esame.model.Distretto.")) {
                view.showError("not a district name");
                return;
            }
            view.showError(e.getMessage());
        }
    }
}
