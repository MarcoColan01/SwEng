package it.unimi.di.sweng.esame.model;

public enum Partito {
    PDI,
    PCI,
    PRI,
    PSI,
    PPI,
    PLI;
}
