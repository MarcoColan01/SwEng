package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.model.Distretto;
import it.unimi.di.sweng.esame.model.Partito;
import it.unimi.di.sweng.esame.model.Voto;
import org.jetbrains.annotations.NotNull;

import java.util.*;

public enum DistrictWinnersStrategy implements DisplayStrategy<Voto> {
    INSTANCE;
    @Override
    public void sortVotes(@NotNull List<Voto> voti) {
        voti.sort(Comparator.comparingInt(o -> o.distretto().ordinal()));
    }

    @Override
    public List<String> getOutput(@NotNull List<Voto> voti) {
        sortVotes(voti);
        List<String> output = new ArrayList<>();
        for (Distretto distretto: Distretto.values()){
            Map<Partito, Integer> votiMax = new HashMap<>();
            Partito vincitore = null;
            int max = -1;
            for(Voto voto: voti){
                if(voto.distretto().equals(distretto)){
                    if(!votiMax.containsKey(voto.partito()))
                        votiMax.put(voto.partito(), 1);
                    else votiMax.replace(voto.partito(), votiMax.get(voto.partito())+1);
                    if(votiMax.get(voto.partito()) > max){
                        vincitore = voto.partito();
                        max = votiMax.get(voto.partito());
                    }
                }

            }
            if(max > 0)
                output.add(String.format("%s: %s (%d)", distretto, vincitore, max));
        }
        return output;
    }
}
