package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.model.VotiPartito;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public enum NationalVotesStrategy implements DisplayStrategy<VotiPartito> {
    INSTANCE;
    @Override
    public void sortVotes(@NotNull List<VotiPartito> voti) {
        voti.sort((o1, o2) -> Integer.compare(o2.voti(), o1.voti()));
    }

    @Override
    public List<String> getOutput(@NotNull List<VotiPartito> voti) {
        sortVotes(voti);
        List<String> votes = new ArrayList<>();
        for (VotiPartito voto : voti) {
            votes.add(String.format("%s: %d", voto.partito(), voto.voti()));
        }
        return votes;
    }
}
