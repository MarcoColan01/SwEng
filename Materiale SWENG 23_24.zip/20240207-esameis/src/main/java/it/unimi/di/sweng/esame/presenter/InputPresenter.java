package it.unimi.di.sweng.esame.presenter;

import org.jetbrains.annotations.NotNull;

public interface InputPresenter {
  void action(@NotNull String text, @NotNull String text1);
}
