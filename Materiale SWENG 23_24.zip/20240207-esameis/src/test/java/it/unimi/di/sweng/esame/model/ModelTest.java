package it.unimi.di.sweng.esame.model;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

class ModelTest {

    @Test
    void testAddVoto(){
        Model SUT = new Model();
        SUT.addVoto(Voto.creaVoto("PLI", "ISLANDS"));
        SUT.addVoto(Voto.creaVoto("PLI", "CENTRAL"));
        assertThat(SUT.getVotiNazionali()).hasSize(1);
    }

    @Test
    void testAddVotoStessoPartito(){
        Model SUT = new Model();
        SUT.addVoto(Voto.creaVoto("PLI", "ISLANDS"));
        SUT.addVoto(Voto.creaVoto("PLI", "CENTRAL"));
        assertThat(SUT.getVotiNazionali()).hasSize(1);
        assertThat(SUT.getVoti()).hasSize(2);
    }
}