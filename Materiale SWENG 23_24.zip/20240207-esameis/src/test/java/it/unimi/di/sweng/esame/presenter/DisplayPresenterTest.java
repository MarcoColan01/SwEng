package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.model.Distretto;
import it.unimi.di.sweng.esame.model.Model;
import it.unimi.di.sweng.esame.model.Partito;
import it.unimi.di.sweng.esame.model.Voto;
import it.unimi.di.sweng.esame.view.OutputView;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;

class DisplayPresenterTest {
    @Test
    void TestUpdateNationalVotes(){
        OutputView view = mock(OutputView.class);
        Model model = spy(Model.class);
        DisplayPresenter SUT = new DisplayPresenter(view, model,NationalVotesStrategy.INSTANCE);
        model.addVoto(new Voto(Partito.PLI, Distretto.CENTRAL));
        model.addVoto(new Voto(Partito.PLI, Distretto.SOUTH));
        clearInvocations(view);
        model.addVoto(new Voto(Partito.PPI, Distretto.CENTRAL));
        verify(view).set(0, "PLI: 2");
        verify(view).set(1, "PPI: 1");
    }

    @Test
    void TestUpdateDistrictVotes(){
        OutputView view = mock(OutputView.class);
        Model model = spy(Model.class);
        DisplayPresenter SUT = new DisplayPresenter(view, model, DistrictWinnersStrategy.INSTANCE);
        model.addVoto(new Voto(Partito.PLI, Distretto.NORTH_WEST));
        model.addVoto(new Voto(Partito.PLI, Distretto.NORTH_WEST));
        model.addVoto(new Voto(Partito.PPI, Distretto.NORTH_WEST));
        model.addVoto(new Voto(Partito.PPI, Distretto.CENTRAL));
        clearInvocations(view);
        model.addVoto(new Voto(Partito.PPI, Distretto.CENTRAL));
        verify(view).set(0, "NORTH_WEST: PLI (2)");
        verify(view).set(1, "CENTRAL: PPI (2)");
    }

}