package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.model.*;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class DisplayStrategyTest {

    @Test
    void testNationalVotesSort(){
        DisplayStrategy SUT = NationalVotesStrategy.INSTANCE;
        List<VotiPartito> voti = new ArrayList<>();
        VotiPartito v1 = new VotiPartito(Partito.PLI, 10);
        VotiPartito v2 = new VotiPartito(Partito.PDI, 1);
        VotiPartito v3 = new VotiPartito(Partito.PRI, 5);
        VotiPartito v4 = new VotiPartito(Partito.PPI, 30);
        voti.add(v1);
        voti.add(v2);
        voti.add(v3);
        voti.add(v4);
        SUT.sortVotes(voti);
        assertThat(voti).containsExactly(v4, v1, v3, v2);
    }

    @Test
    void testNationalVotesDisplay(){
        DisplayStrategy SUT = NationalVotesStrategy.INSTANCE;
        List<VotiPartito> voti = new ArrayList<>();
        VotiPartito v1 = new VotiPartito(Partito.PLI, 10);
        VotiPartito v2 = new VotiPartito(Partito.PDI, 1);
        VotiPartito v3 = new VotiPartito(Partito.PRI, 5);
        VotiPartito v4 = new VotiPartito(Partito.PPI, 30);
        voti.add(v1);
        voti.add(v2);
        voti.add(v3);
        voti.add(v4);
        assertThat(SUT.getOutput(voti)).containsExactly(
                "PPI: 30",
                "PLI: 10",
                "PRI: 5",
                "PDI: 1"
        );
    }
    @Test
    void testDistrictWinnersSort(){
        DisplayStrategy SUT = DistrictWinnersStrategy.INSTANCE;
        List<Voto> voti = new ArrayList<>();
        Voto v1 = new Voto(Partito.PLI, Distretto.CENTRAL);
        Voto v2 = new Voto(Partito.PRI, Distretto.NORTH_WEST);
        Voto v3 = new Voto(Partito.PRI, Distretto.SOUTH);
        Voto v4 = new Voto(Partito.PSI, Distretto.NORTH_EAST);
        voti.add(v1);
        voti.add(v2);
        voti.add(v3);
        voti.add(v4);
        SUT.sortVotes(voti);
        assertThat(voti).containsExactly(v2, v4, v1, v3);
    }

    @Test
    void testDistrictWinnersDisplay(){
        DisplayStrategy SUT = DistrictWinnersStrategy.INSTANCE;
        List<Voto> voti = new ArrayList<>();
        Voto v1 = new Voto(Partito.PLI, Distretto.CENTRAL);
        Voto v2 = new Voto(Partito.PRI, Distretto.CENTRAL);
        Voto v3 = new Voto(Partito.PRI, Distretto.CENTRAL);
        Voto v4 = new Voto(Partito.PSI, Distretto.NORTH_EAST);
        voti.add(v1);
        voti.add(v2);
        voti.add(v3);
        voti.add(v4);
        assertThat(SUT.getOutput(voti)).containsExactly(
                "NORTH_EAST: PSI (1)",
             "CENTRAL: PRI (2)"
        );
    }

}