package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.model.Model;
import it.unimi.di.sweng.esame.view.InputView;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

class InputVotePresenterTest {
    @Test
    void testEmptyPartyName(){
        InputView view = mock(InputView.class);
        InputVotePresenter SUT = new InputVotePresenter(view, mock(Model.class));
        SUT.action("", "ISLANDS");
        verify(view).showError("empty party name");
    }

    @Test
    void testEmptyDistrictName(){
        InputView view = mock(InputView.class);
        InputVotePresenter SUT = new InputVotePresenter(view, mock(Model.class));
        SUT.action("PLI", "");
        verify(view).showError("empty district name");
    }

    @Test
    void testInvalidPartyName(){
        InputView view = mock(InputView.class);
        InputVotePresenter SUT = new InputVotePresenter(view, mock(Model.class));
        SUT.action("PSA", "ISLANDS");
        verify(view).showError("not a party name");
    }

    @Test
    void testInvalidRegionName(){
        InputView view = mock(InputView.class);
        InputVotePresenter SUT = new InputVotePresenter(view, mock(Model.class));
        SUT.action("PLI", "LOMBARDY");
        verify(view).showError("not a district name");
    }

    @Test
    void testInputOk(){
        InputView view = mock(InputView.class);
        InputVotePresenter SUT = new InputVotePresenter(view, mock(Model.class));
        SUT.action("PLI", "ISLANDS");
        verify(view).showSuccess();
    }

}