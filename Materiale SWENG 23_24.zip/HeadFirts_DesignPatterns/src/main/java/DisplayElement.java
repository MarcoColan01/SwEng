public interface DisplayElement {
    void display();
}
