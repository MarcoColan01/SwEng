package Strategy;

public interface QuackStrategy {
    String quack();
}
