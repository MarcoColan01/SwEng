package Strategy;

import org.jetbrains.annotations.NotNull;

public abstract class Duck {
     QuackStrategy quack;
     SwimStrategy swim;
     FlyStrategy fly;

     public String quack(){
         return quack.quack();
     }

    public String swim() {
         return swim.swim();
    }

    public String fly(){
         return fly.fly();
    }

    public void setSwimStrategy(@NotNull SwimStrategy swim){
         this.swim = swim;
    }

    public void setQuackStrategy(@NotNull QuackStrategy quack){
        this.quack = quack;
    }
}
