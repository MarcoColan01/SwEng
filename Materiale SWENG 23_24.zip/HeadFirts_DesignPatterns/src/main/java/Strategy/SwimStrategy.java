package Strategy;

public interface SwimStrategy {
    String swim();
}
