package Strategy;

public class RealSwim implements SwimStrategy {
    @Override
    public String swim() {
        return "I'm really swimming!";
    }
}
