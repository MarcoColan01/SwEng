package Strategy;

public class MallardDuck extends Duck {

    public MallardDuck(){
        quack = new RealQuack();
        swim = new RealSwim();
        fly = new RealFly();
    }
}
