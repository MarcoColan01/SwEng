package Strategy;

public class RealFly implements FlyStrategy {
    @Override
    public String fly() {
        return "I'm really flying!";
    }
}
