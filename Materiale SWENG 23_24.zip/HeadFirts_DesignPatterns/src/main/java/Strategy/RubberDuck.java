package Strategy;

public class RubberDuck extends Duck {
    public RubberDuck(){
        quack = new FakeQuack();
        swim = new FakeSwim();
        fly = new FakeFly();
    }
}
