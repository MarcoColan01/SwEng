package Strategy;

public class FakeSwim implements SwimStrategy {
    @Override
    public String swim() {
        return "I'm just floating";
    }
}
