package Strategy;

public class FakeFly implements FlyStrategy {
    @Override
    public String fly() {
        return "I can't fly";
    }
}
