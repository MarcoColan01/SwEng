package Strategy;

public class RealQuack implements QuackStrategy {
    @Override
    public String quack() {
        return "Quack!";
    }
}
