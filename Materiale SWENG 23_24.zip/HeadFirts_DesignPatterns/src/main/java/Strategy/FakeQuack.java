package Strategy;

public class FakeQuack implements QuackStrategy {
    @Override
    public String quack() {
        return "Mute";
    }
}
