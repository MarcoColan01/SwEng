package Strategy;

public class RedHeadDuck extends Duck {
    public RedHeadDuck(){
        quack = new RealQuack();
        swim = new RealSwim();
        fly = new RealFly();
    }
}
