package Strategy;

public interface FlyStrategy {
    String fly();
}
