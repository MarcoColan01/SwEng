import Strategy.Duck;
import Strategy.MallardDuck;
import Strategy.RubberDuck;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;


class DuckTest {
    @Test
    void differentQuackStrategy(){
        Duck mallardDuck = new MallardDuck();
        Duck rubberDuck = new RubberDuck();

        assertThat(mallardDuck.quack()).isEqualTo("Quack!");
        assertThat(rubberDuck.quack()).isEqualTo("Mute");
    }

    @Test
    void differentSwimStrategy(){
        Duck mallardDuck = new MallardDuck();
        Duck rubberDuck = new RubberDuck();

        assertThat(mallardDuck.swim()).isEqualTo("I'm really swimming!");
        assertThat(rubberDuck.swim()).isEqualTo("I'm just floating");
    }
}


