import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;

public class ObserverTest {
    @Test
    void observerTest(){
        WeatherData wd = new WeatherData();
        CurrentConditionsDisplay currentDisplay = mock(CurrentConditionsDisplay.class);
        wd.addObserver(currentDisplay);
        wd.changeMeasurements(80, 65, 30.4f);
        verify(currentDisplay).update(80, 65, 30.4f);
    }

    public static void main(String[] args) {
        WeatherData wd = new WeatherData();
        CurrentConditionsDisplay currentDisplay = new CurrentConditionsDisplay(wd);
        wd.changeMeasurements(80, 65, 30.4f);
        currentDisplay.display();
        wd.changeMeasurements(43, 15, 32.2f);
        currentDisplay.display();
    }
}
