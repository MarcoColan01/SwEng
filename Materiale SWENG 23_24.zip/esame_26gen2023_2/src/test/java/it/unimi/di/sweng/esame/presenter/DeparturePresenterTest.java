package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.model.Model;
import it.unimi.di.sweng.esame.view.DepartureView;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DeparturePresenterTest {
    @Test
    void testLeftDepartures() {
        DepartureView view = mock(DepartureView.class);
        Model model = spy(Model.class);
        DeparturePresenter SUT = new DeparturePresenter(view, model,
                new SortStrategy(),0);
        model.readFile();
        verify(view).set(0, " TI 3029 ALBENGA 14:32 0 ");
        verify(view).set(1, " TN 2170 MILANO CENTRALE 14:34 0 ");
    }

    @Test
    void testLeftDeparturesAfterDelayUpdate() {
        DepartureView view = mock(DepartureView.class);
        Model model = spy(Model.class);
        DeparturePresenter SUT = new DeparturePresenter(view, model,
                new SortStrategy(),0);
        model.readFile();
        clearInvocations(view);
        model.aggiornaRitardo("TI 3029", 300);
        verify(view).set(0, " TN 2170 MILANO CENTRALE 14:34 0 ");
        verify(view).set(1, " TTX 2470 MILANO CENTRALE 14:39 0 ");
    }

    @Test
    void testDepartureTrain(){
        DepartureView view = mock(DepartureView.class);
        Model model = spy(Model.class);
        DeparturePresenter SUT = new DeparturePresenter(view, model,
                new SortStrategy(),0);
        model.readFile();
        clearInvocations(view);
        SUT.action("TI 3029", "");
        verify(view).set(0, " TN 2170 MILANO CENTRALE 14:34 0 ");
    }
}