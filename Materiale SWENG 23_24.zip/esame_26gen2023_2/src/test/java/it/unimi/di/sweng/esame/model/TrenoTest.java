package it.unimi.di.sweng.esame.model;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

class TrenoTest {
    @Test
    void testTreno() {
        Treno SUT = Treno.creaTreno("TN 23456,MILANO,14:32,10");
        assertThat(SUT.toString()).isEqualTo(" TN 23456 MILANO 14:32 10 ");
    }

    @ParameterizedTest
    @CsvSource({"'TN 45567,MILANO,14:32,0', 'TN 32123,MILANO,14:45,0', 1",
            "'TN 45567,MILANO,15:32,0', 'TN 32123,MILANO,14:45,0', -1",
            "'TN 45567,MILANO,14:32,20', 'TN 32123,MILANO,14:45,0', -1",
            "'TN 45567,MILANO,14:32,0', 'TN 32123,MILANO,14:45,10', 1",
            "'TN 45567,MILANO,14:32,13', 'TN 32123,MILANO,14:45,0', 0"})
    void testCompareTreno(String t1, String t2, String res) {
        Treno treno1 = Treno.creaTreno(t1);
        Treno treno2 = Treno.creaTreno(t2);
        assertThat(treno1.compareTo(treno2)).isEqualTo(Integer.parseInt(res));
    }
}