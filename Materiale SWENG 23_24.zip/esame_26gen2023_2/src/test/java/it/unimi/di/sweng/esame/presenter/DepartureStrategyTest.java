package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.model.Treno;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

class DepartureStrategyTest {

    @Test
    void testSortTrains(){
        DepartureStrategy SUT = new SortStrategy();
        List<Treno> treni = new ArrayList<>();
        Treno t1 = Treno.creaTreno("TN 65433,MILANO,12:34,10");
        treni.add(t1);
        Treno t2 = Treno.creaTreno("TN 65433,MILANO,11:34,10");
        treni.add(t2);
        Treno t3 = Treno.creaTreno("TN 65433,MILANO,12:34,20");
        treni.add(t3);
        Treno t4 = Treno.creaTreno("TN 65433,MILANO,10:34,300");
        treni.add(t4);
        SUT.sortTrains(treni);
        assertThat(treni).containsExactly(t2, t1, t3, t4);

    }
}