package it.unimi.di.sweng.esame.model;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

class ModelTest {

    @Test
    void testModelGetState(){
        Model SUT = new Model();
        SUT.readFile();
        assertThat(SUT.getState()).hasSize(20);
    }
}