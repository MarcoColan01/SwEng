package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.model.Model;
import it.unimi.di.sweng.esame.view.SetDelayView;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;

class SetDelayPresenterTest {
    @Test
    void testUpdateOrario() {
        SetDelayView view = mock(SetDelayView.class);
        Model model = spy(Model.class);
        SetDelayPresenter SUT = new SetDelayPresenter(model, view);

        model.readFile();
        SUT.action("TN 10870", "10");
        assertThat(model.getState().toString())
                .contains(" TN 10870 MILANO GRECO PIRELLI 15:12 10 ");
    }
}