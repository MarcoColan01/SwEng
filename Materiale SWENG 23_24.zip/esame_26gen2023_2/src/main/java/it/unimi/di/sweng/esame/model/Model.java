package it.unimi.di.sweng.esame.model;

import it.unimi.di.sweng.esame.Main;
import it.unimi.di.sweng.esame.Observable;
import it.unimi.di.sweng.esame.Observer;
import org.jetbrains.annotations.NotNull;

import java.io.InputStream;
import java.util.*;

public class Model implements Observable<List<Treno>> {

    private final @NotNull Map<String, Treno> treni = new HashMap<>();
    private final @NotNull List<Observer<List<Treno>>> observers = new ArrayList<>();

    public void readFile() {
        InputStream is = Main.class.getResourceAsStream("/trains.csv");
        assert is != null;
        Scanner s = new Scanner(is);

        while (s.hasNextLine()) {
            String linea = s.nextLine();
            String[] el = linea.split(",");
            String cod = el[0];

            Treno treno = Treno.creaTreno(linea);
            treni.put(cod, treno);
        }
        notifyObservers();
    }

    @Override
    public void notifyObservers() {
        for (Observer<List<Treno>> observer : observers) {
            observer.update(getState());
        }
    }

    @Override
    public void addObserver(@NotNull Observer<List<Treno>> observer) {
        observers.add(observer);
    }

    @Override
    public List<Treno> getState() {
        return new ArrayList<>(treni.values());
    }

    public void aggiornaRitardo(@NotNull String cod, int delay) {
        if (treni.containsKey(cod)) {

            Treno treno = treni.get(cod);
            treni.replace(cod, new Treno(treno.cod(), treno.destination(), treno.orario(), delay));
            notifyObservers();
        }
    }

    public void trenoPartito(@NotNull String treno) {
        if(treni.containsKey(treno)){
            treni.remove(treno);
            notifyObservers();
        }
    }
}
