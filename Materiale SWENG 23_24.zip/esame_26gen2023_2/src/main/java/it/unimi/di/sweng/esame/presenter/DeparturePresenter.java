package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.Main;
import it.unimi.di.sweng.esame.Observer;
import it.unimi.di.sweng.esame.model.Model;
import it.unimi.di.sweng.esame.model.Treno;
import it.unimi.di.sweng.esame.view.DepartureView;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class DeparturePresenter implements Observer<List<Treno>>, InputPresenter {
    private final @NotNull Model model;
    private final @NotNull DepartureView view;
    private final @NotNull DepartureStrategy strategy;
    private final int startTrain;

    public DeparturePresenter(@NotNull DepartureView view, @NotNull Model model,
                              @NotNull DepartureStrategy strategy, int startTrain) {
        this.model = model;
        this.view = view;
        this.strategy = strategy;
        this.startTrain = startTrain;
        model.addObserver(this);
    }

    @Override
    public void update(@NotNull List<Treno> state) {
        int i = 0;
        List<String> treni = strategy.printSortedTrains(state);
        for (int j = 0; j + startTrain < treni.size() && j < Main.MAX_ROW_ITEMS_IN_VIEW; j++) {
            view.set(i++, treni.get(j + startTrain));
        }

    }

    @Override
    public void action(String text1, String text2) {
        model.trenoPartito(text1.substring(0,9).trim());
    }
}
