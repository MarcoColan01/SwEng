package it.unimi.di.sweng.esame.model;

import org.jetbrains.annotations.NotNull;

import java.time.Duration;
import java.time.LocalTime;

public record Treno(@NotNull String cod, @NotNull String destination,
                    @NotNull LocalTime orario, int delay) implements Comparable<Treno>{
    public static Treno creaTreno(@NotNull String treno) {
        String[] info = treno.split(",");
        int ora = 0;
        int minuti = 0;
        int ritardo = 0;
        if (info.length != 4) throw new IllegalArgumentException("Numero parametri errato");
        if (info[0].isBlank()) throw new IllegalArgumentException("Codice vuoto");
        if (!info[0].matches("^[A-Z]{2,3} \\d{4,5}$"))
            throw new IllegalArgumentException("Formato codice errato");
        if (info[1].isBlank()) throw new IllegalArgumentException("Destinazione vuota");
        try {
            ora = Integer.parseInt(info[2].split(":")[0]);
            minuti = Integer.parseInt(info[2].split(":")[1]);
            ritardo = Integer.parseInt(info[3]);
            if (ritardo < 0) throw new IllegalArgumentException("Ritardo negativo");
            return new Treno(info[0], info[1], LocalTime.of(ora,minuti), ritardo);
        }catch (NumberFormatException e) {
            throw new IllegalArgumentException("Ritardo in formato non numerico");
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    @Override
    public String toString() {
        return " " + cod + " "
                + destination + " "
                + String.format("%02d:%02d", orario.getHour(), orario.getMinute())
                + " " + String.format("%d ", delay);
    }
    @Override
    public int compareTo(@NotNull Treno treno2) {
        return treno2.orario.plusMinutes(Duration.ofMinutes(treno2.delay).toMinutes())
                .compareTo(orario.plusMinutes(Duration.ofMinutes(delay).toMinutes()));
    }
}
