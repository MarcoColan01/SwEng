package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.model.Model;
import it.unimi.di.sweng.esame.view.SetDelayView;
import org.jetbrains.annotations.NotNull;

public class SetDelayPresenter implements InputPresenter{
    private final @NotNull SetDelayView view;
    private final @NotNull Model model;

    public SetDelayPresenter(@NotNull Model model, @NotNull SetDelayView view){
        this.view = view;
        this.model = model;
        view.addHandlers(this);
    }
    @Override
    public void action(String cod, String ritardo) {
        try{
            int delay = Integer.parseInt(ritardo);
            if(delay < 0)
                throw new IllegalArgumentException("Impossibile settare ritardo negativo");
            model.aggiornaRitardo(cod, delay);
        }catch (NumberFormatException e){
            return;
        }
    }
}
