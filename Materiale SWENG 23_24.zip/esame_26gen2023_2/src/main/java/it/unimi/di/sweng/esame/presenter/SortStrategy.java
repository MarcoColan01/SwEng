package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.model.Treno;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class SortStrategy implements DepartureStrategy {
    @Override
    public void sortTrains(@NotNull List<Treno> treni) {
        treni.sort(Comparator.reverseOrder());
    }

    @Override
    public List<String> printSortedTrains(@NotNull List<Treno> treni) {
        sortTrains(treni);
        List<String> treniShowed = new ArrayList<>();
        for (Treno treno : treni) {
            treniShowed.add(treno.toString());
        }
        return treniShowed;
    }
}
