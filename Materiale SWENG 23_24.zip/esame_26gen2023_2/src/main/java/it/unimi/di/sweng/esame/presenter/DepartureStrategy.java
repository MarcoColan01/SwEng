package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.model.Treno;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public interface DepartureStrategy {
    void sortTrains(@NotNull List<Treno> treni);
    List<String> printSortedTrains(@NotNull List<Treno> treni);
}
