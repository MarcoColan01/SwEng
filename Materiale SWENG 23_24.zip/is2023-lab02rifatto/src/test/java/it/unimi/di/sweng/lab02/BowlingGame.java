package it.unimi.di.sweng.lab02;

import java.util.Arrays;

public class BowlingGame implements Bowling {
    private int score = 0;
    private final int[] lanci = new int[21];
    private int lancioCurr = 0;

    @Override
    public void roll(int pins) {
        lanci[lancioCurr] = pins;

        lancioCurr++;
    }

    @Override
    public int score() {
        if(perfect()){
            return 300;
        }
        int frame = 0;
        for(int i = 0; i < lanci.length; i++){
            if(isSpare(i, frame)){
                score += lanci[i+1];
            }
            if(isStrike(i)){
                boolean end = strikeScore(i, frame);
                frame = 0;
                if(end) return score;
            }
            score += lanci[i];
            frame ++;
            if(frame == 2) frame = 0;

        }
        return score;
    }

    private boolean perfect() {
        for(int i = 0; i < 12; i++){
            if(lanci[i] != 10) return false;
        }
        return true;
    }

    private boolean strikeScore(int i, int frame) {
        if(i == 18){
            score += lanci[i] + lanci[i+1] + lanci[i+2];
            return true;
        }
        if(frame == 0){
            score += lanci[i+1] + lanci[i+2];
        }else{
            score += lanci[i+2] + lanci[i+3];
        }
        return false;
    }

    private boolean isStrike(int i) {
        return lanci[i] == 10;
    }

    private boolean isSpare(int i, int frame) {
        return i > 0 && i != lanci.length-1 && lanci[i] + lanci[i-1] == 10 && (frame == 1);
    }

}
