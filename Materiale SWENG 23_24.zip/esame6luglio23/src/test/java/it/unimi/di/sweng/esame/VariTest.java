package it.unimi.di.sweng.esame;


import static org.assertj.core.api.Assertions.assertThat;
import org.assertj.core.api.Assertions;


class VariTest {

}