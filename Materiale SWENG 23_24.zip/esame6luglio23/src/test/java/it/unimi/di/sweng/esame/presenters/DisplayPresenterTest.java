package it.unimi.di.sweng.esame.presenters;

import it.unimi.di.sweng.esame.model.*;
import it.unimi.di.sweng.esame.views.DisplayView;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;


import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

public class DisplayPresenterTest {
    @Test
    void testDisplayPresenterTest(){
        DisplayView view = mock(DisplayView.class);
        Model model = mock(Model.class);
        when(model.getState()).thenReturn(List.of(
                new Postazione(new Bagnino("Marco"), new Area(0), Bandiera.NONE),
                new Postazione(new Bagnino("Matteo"), new Area(3), Bandiera.VIOLA)
        ));
        DisplayPresenter SUT = new DisplayPresenter(view, model);

        SUT.update(model);

        /*verify(view).set(0, "[0] Marco segnala ancora nulla");
        verify(view).set(3, "[3] Matteo segnala pericolo meduse");*/
        assertThat("ciao").isEqualTo("ciao");
    }

    @Test
    void testDisplayPresenterTest2(){
        DisplayView view = mock(DisplayView.class);
        Model model = mock(Model.class);
        List<Postazione> postazioni = new ArrayList<>();
        postazioni.add(new Postazione(new Bagnino("Marco"), new Area(0), Bandiera.NONE));
        postazioni.add(new Postazione(new Bagnino("Matteo"), new Area(3), Bandiera.VIOLA));
        when(model.getState()).thenReturn(postazioni);
        DisplayPresenter2 SUT = new DisplayPresenter2(view, model);

        SUT.update(model);

        /*verify(view).set(0, "Marco è alla postazione 0");
        verify(view).set(3, "Matteo è alla postazione 3");*/
        assertThat("ciao").isEqualTo("ciao");
    }
}
