package it.unimi.di.sweng.esame.presenters;

import it.unimi.di.sweng.esame.Observer;
import it.unimi.di.sweng.esame.model.*;
import it.unimi.di.sweng.esame.views.PostazioneView;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.mockito.Mockito.*;

class PresenterTest {
    @Test
    void presenterCheckNomeVuoto() {
        PostazioneView view = mock(PostazioneView.class);
        PostazionePresenter SUT = new PostazionePresenter(view, mock(Model.class), mock(Area.class));
        SUT.action("Arriva", "");

        verify(view).showError("nome vuoto");
    }

    @Test
    void presenterCheckNomeTroppoLungo() {
        PostazioneView view = mock(PostazioneView.class);
        PostazionePresenter SUT = new PostazionePresenter(view, mock(Model.class), mock(Area.class));
        SUT.action("Arriva", "Dimitri Dimitri Dimitri Dimitri Dimitri Dimitri Dimitri Dimitri Dimitri " +
                "Dimitri Dimitri Dimitri Dimitri Dimitri Dimitri Dimitri Dimitri Dimitri Dimitri " +
                "Dimitri Dimitri Dimitri Dimitri Dimitri Dimitri");
        verify(view).showError("nome troppo lungo");
    }

    @Test
    void presenterCheckNomeLunghezzaGiusta() {
        PostazioneView view = mock(PostazioneView.class);
        PostazionePresenter SUT = new PostazionePresenter(view, mock(Model.class), mock(Area.class));
        SUT.action("Arriva", "Marco");
        verify(view).showSuccess();
    }

    @Test
    void presenterCheckBandieraValida() {
        PostazioneView view = mock(PostazioneView.class);
        PostazionePresenter SUT = new PostazionePresenter(view, mock(Model.class), mock(Area.class));
        SUT.action("Segnala", "Marco,TURCHESE");
        verify(view).showError("Bandiera non valida");
    }

    @Test
    void presenterCheckBandieraNonSpecificata() {
        PostazioneView view = mock(PostazioneView.class);
        PostazionePresenter SUT = new PostazionePresenter(view, mock(Model.class), mock(Area.class));
        SUT.action("Segnala", "Marco,");
        verify(view).showError("Indicare colore bandiera");
    }

    @Test
    void presenterCheckBandieraOK() {
        PostazioneView view = mock(PostazioneView.class);
        PostazionePresenter SUT = new PostazionePresenter(view, mock(Model.class), mock(Area.class));
        SUT.action("Segnala", "Marco,ROSSA");
        verify(view).showSuccess();
    }

    @Test
    void presenterRactsToUpdate() {
        Area area  = mock(Area.class);
        Model model = mock(Model.class);
        Bagnino bagnino = mock(Bagnino.class);
        when(bagnino.nome()).thenReturn("Marco");
        PostazioneView view = mock(PostazioneView.class);

        when(model.getState()).thenReturn(List.of(
                new Postazione(bagnino, area, Bandiera.ROSSA)
        ));
        Observer<List<Postazione>> SUT = new PostazionePresenter(view, model, area);
        SUT.update(model);
        verify(view).setBagnino("Marco");

    }


}