package it.unimi.di.sweng.esame.model;

import it.unimi.di.sweng.esame.Observer;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

class ModelTest {
    @Test
    void checkModelloArrivoBagnino(){
        Model SUT = new Model();
        Bagnino bagnino = mock(Bagnino.class);
        Area area = mock(Area.class);
        SUT.arriva(bagnino, area);
        assertThat(SUT.getListaPosizioni()).containsExactly(new Postazione(bagnino, area, Bandiera.NONE));
    }

    @Test
    void checkModelloSegnalaBandiera(){
        Model SUT = new Model();
        Bagnino bagnino = mock(Bagnino.class);
        Bandiera bandiera = mock(Bandiera.class);
        Area area = mock(Area.class);
        SUT.arriva(bagnino, area);
        SUT.segnala(bagnino, bandiera);
        assertThat(SUT.getListaPosizioni()).containsExactly(new Postazione(bagnino, area, bandiera));
    }

    @Test
    void checkModelloSegnalaBandieraDaBagninoNonPresente(){
        Model SUT = new Model();
        Bagnino bagnino = mock(Bagnino.class);
        Bandiera bandiera = mock(Bandiera.class);
        assertThatThrownBy(() -> SUT.segnala(bagnino,bandiera))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("postazione non presidiata");
    }

    @Test
    void checkModelloArrivoBagninoFail(){
        Model SUT = new Model();
        Bagnino bagnino = mock(Bagnino.class);
        Area area = mock(Area.class);
        SUT.arriva(mock(Bagnino.class), area);
        assertThatThrownBy(()-> SUT.arriva(bagnino, area))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("postazione già occupata");
    }

    @Test
    void checkModelloArrivoBagninoGiaInAltraPostazione(){
        Model SUT = new Model();
        Bagnino bagnino = mock(Bagnino.class);
        Area area = mock(Area.class);
        SUT.arriva(bagnino, mock(Area.class));
        assertThatThrownBy(()-> SUT.arriva(bagnino, area))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("bagnino già presente in altra postazione");
    }

    @Test
    void modelUpdateOnlyIfChanged(){
        Model SUT = new Model();
        Observer<List<Postazione>> obs1 = mock(Observer.class);
        Bagnino bagnino = mock(Bagnino.class);
        Area area = mock(Area.class);

        SUT.addObserver(obs1);
        SUT.arriva(bagnino, area);

        verify(obs1).update(SUT);
    }

    @Test
    void modelUpdateOnlyIfChanged2(){
        Model SUT = new Model();
        Observer<List<Postazione>> obs1 = mock(Observer.class);
        Bagnino bagnino = mock(Bagnino.class);
        Area area = mock(Area.class);

        SUT.addObserver(obs1);
        SUT.arriva(bagnino, area);
        SUT.segnala(bagnino, Bandiera.ROSSA);

        verify(obs1, times(2)).update(SUT);
    }
}