package it.unimi.di.sweng.esame.presenters;

import it.unimi.di.sweng.esame.Main;
import it.unimi.di.sweng.esame.Observable;
import it.unimi.di.sweng.esame.Observer;
import it.unimi.di.sweng.esame.model.Model;
import it.unimi.di.sweng.esame.model.Postazione;
import it.unimi.di.sweng.esame.views.DisplayView;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class DisplayPresenter implements Observer<List<Postazione>> {
    private @NotNull final DisplayView view;
    private @NotNull final Model model;


    public DisplayPresenter(@NotNull DisplayView view, @NotNull Model model) {
        this.view = view;
        this.model = model;
        model.addObserver(this);
    }

    @Override
    public void update(@NotNull Observable<List<Postazione>> subject) {
        for (int i = 0; i < Main.NUMPOSTAZIONI; i++) {
            view.set(i, "postazione non presidiata");
        }
        for(Postazione postazione: subject.getState()){
            view.set(postazione.area().pos(), postazione.format1());
        }
    }
}
