package it.unimi.di.sweng.esame.model;

import it.unimi.di.sweng.esame.Main;

import java.util.Objects;

public final class Area {
    private final int pos;

    public Area(int pos) {
        if (pos < 0 || pos > Main.NUMPOSTAZIONI) throw new IllegalArgumentException("postazione non valida.");
        this.pos = pos;
    }

    public int pos() {
        return pos;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;
        if (obj == null || obj.getClass() != this.getClass()) return false;
        var that = (Area) obj;
        return this.pos == that.pos;
    }

    @Override
    public int hashCode() {
        return Objects.hash(pos);
    }

    @Override
    public String toString() {
        return "Area[" +
                "pos=" + pos + ']';
    }

}
