package it.unimi.di.sweng.esame.model;

import org.jetbrains.annotations.NotNull;

import java.util.Objects;

public final class Bagnino {
    private final String nome;

    public Bagnino(@NotNull String nome) {
        if (nome.isBlank()) throw new IllegalArgumentException("nome vuoto");
        if (nome.length() > 30) throw new IllegalArgumentException("nome troppo lungo");
        this.nome = nome;
    }

    public String nome() {
        return nome;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;
        if (obj == null || obj.getClass() != this.getClass()) return false;
        var that = (Bagnino) obj;
        return Objects.equals(this.nome, that.nome);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nome);
    }

    @Override
    public String toString() {
        return "Bagnino[" +
                "nome=" + nome + ']';
    }


}
