package it.unimi.di.sweng.esame.model;

import org.jetbrains.annotations.NotNull;

import java.util.Objects;

public final class Postazione {
    private final @NotNull Bagnino bagnino;
    private final @NotNull Area area;
    private final @NotNull Bandiera bandiera;

    public Postazione(@NotNull Bagnino bagnino, @NotNull Area area, @NotNull Bandiera bandiera) {
        this.bagnino = bagnino;
        this.area = area;
        this.bandiera = bandiera;
    }

    public @NotNull Bagnino bagnino() {
        return bagnino;
    }

    public @NotNull Area area() {
        return area;
    }

    public @NotNull Bandiera bandiera() {
        return bandiera;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;
        if (obj == null || obj.getClass() != this.getClass()) return false;
        var that = (Postazione) obj;
        return Objects.equals(this.bagnino, that.bagnino) &&
                Objects.equals(this.area, that.area) &&
                Objects.equals(this.bandiera, that.bandiera);
    }

    @Override
    public int hashCode() {
        return Objects.hash(bagnino, area, bandiera);
    }

    @Override
    public String toString() {
        return "Postazione[" +
                "bagnino=" + bagnino + ", " +
                "area=" + area + ", " +
                "bandiera=" + bandiera + ']';
    }

    public String format1(){
        return "{" + area.pos() + "} " + bagnino.nome() + " segnala " + bandiera.messaggio;
    }

    public String format2() {
        return bagnino.nome() + " è alla postazione " + area.pos();
    }
}
