package it.unimi.di.sweng.esame.model;

import it.unimi.di.sweng.esame.Observable;
import it.unimi.di.sweng.esame.Observer;
import it.unimi.di.sweng.esame.views.PostazioneView;
import org.jetbrains.annotations.NotNull;

import java.util.*;

public class Model extends State implements Observable<List<Postazione>> {
    private @NotNull final List<Observer<List<Postazione>>> observers = new ArrayList<>();


    @Override
    public void notifyObservers() {
        for (Observer<List<Postazione>> observer : observers) {
            observer.update(this);
        }
    }

    @Override
    public void addObserver(@NotNull Observer<List<Postazione>> observer) {
        observers.add(observer);
    }

    @Override
    public @NotNull List<Postazione> getState() {
        return getListaPosizioni();
    }

    @Override
    public void arriva(@NotNull Bagnino bagnino, @NotNull Area area) {
        super.arriva(bagnino, area);
        notifyObservers();
    }

    @Override
    public void segnala(@NotNull Bagnino bagnino, @NotNull Bandiera bandiera) {
        super.segnala(bagnino, bandiera);
        notifyObservers();
    }
}
