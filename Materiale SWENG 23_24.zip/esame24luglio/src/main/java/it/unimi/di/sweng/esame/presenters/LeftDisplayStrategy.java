package it.unimi.di.sweng.esame.presenters;

import it.unimi.di.sweng.esame.model.Segnalazione;
import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.List;

public class LeftDisplayStrategy implements DisplayStrategy {
    @Override
    public void sortSegnalazioni(@NotNull List<Segnalazione> segnalazioni) {
        segnalazioni.sort(Comparator.comparing(Segnalazione::getOrario));
    }

    @Override
    public String getSegnalazione(Segnalazione segnalazione) {
        return "Richiesto un "
                + segnalazione.getProfessione()
                + " all'appartamento "
                + segnalazione.getCodAppartamento()
                + " alle "
                + segnalazione.getOrario();
    }
}
