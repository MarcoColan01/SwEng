package it.unimi.di.sweng.esame.presenters;

import it.unimi.di.sweng.esame.Main;
import it.unimi.di.sweng.esame.Observable;
import it.unimi.di.sweng.esame.Observer;
import it.unimi.di.sweng.esame.model.Modello;
import it.unimi.di.sweng.esame.views.DisplayView;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class DisplayViewPresenter implements Observer<List<Segnalazione>> {
    private final @NotNull DisplayView view;
    private final @NotNull Modello model;
    private final @NotNull DisplayViewStrategy strategy;

    public DisplayViewPresenter(@NotNull DisplayView view, @NotNull Modello model, @NotNull DisplayViewStrategy strategy) {
        this.view = view;
        this.model = model;
        this.strategy = strategy;
        model.addObserver(this);
    }

    @Override
    public void update(@NotNull List<Segnalazione> state) {
        strategy.sortSegnalazioni(state);
        int i = 0;
        for(int j = 0; j < state.size() && j < Main.NUMVOCIELENCO; j++){
            if(!strategy.showSegnalazione(state.get(j)).isEmpty())
                view.set(i++, strategy.showSegnalazione(state.get(j)));
        }
        System.out.print(strategy.getClass());
        System.out.println(i);
        for(int j = i; j < Main.NUMVOCIELENCO;j++){
            view.set(j, "");
        }
    }
}
