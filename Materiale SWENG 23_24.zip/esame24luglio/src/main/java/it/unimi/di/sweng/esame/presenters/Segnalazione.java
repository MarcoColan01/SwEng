package it.unimi.di.sweng.esame.presenters;

import it.unimi.di.sweng.esame.Main;
import org.jetbrains.annotations.NotNull;

public record Segnalazione(@NotNull String codAppartamento, @NotNull String tecnico, @NotNull Coordinata coordinata,
                           @NotNull Orario orario) {
    public Segnalazione{
        if(!codAppartamento.matches("^[A-Z]\\d{3}$"))
            throw new IllegalArgumentException("Codice appartamento non valido");
        try{
            Tecnico.valueOf(tecnico);
        }catch (IllegalArgumentException e){
            throw  new IllegalArgumentException("Tecnico non valido");
        }
    }

    public double haversineDistance() {
        double lat1 = Math.toRadians(coordinata().latitudine());
        double lat2 = Math.toRadians(Main.AMMINISTRATORE.latitudine());
        double dLat = Math.abs(lat2-lat1);
        double dLon = Math.toRadians(Math.abs(coordinata.longitudine()-Main.AMMINISTRATORE.longitudine()));
        double a = Math.pow(Math.sin(dLat/2),2) + Math.pow(Math.sin(dLon/2),2) * Math.cos(lat1)*Math.cos(lat2);
        double c = 2 * Math.asin(Math.sqrt(a));
        return 6371*c;
    }
}
