package it.unimi.di.sweng.esame.presenters;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public interface DisplayViewStrategy {
    void sortSegnalazioni(@NotNull List<Segnalazione> segnalazioni);

    String showSegnalazione(@NotNull Segnalazione s1);
}
