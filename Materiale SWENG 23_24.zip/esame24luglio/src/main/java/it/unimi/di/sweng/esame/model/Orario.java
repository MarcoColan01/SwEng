package it.unimi.di.sweng.esame.model;

import org.jetbrains.annotations.NotNull;

public final class Orario implements Comparable<Orario>{
    private final int ora;
    private final int minuti;
    private final int secondi;
    static Orario ORARIO_NULL = new Orario("0:0:0");

    public Orario(String orario){
        String[] app = orario.split(":");
        try {
            this.ora = Integer.parseInt(app[0]);
            this.minuti = Integer.parseInt(app[1]);
            this.secondi = Integer.parseInt(app[2]);
        }catch (NumberFormatException e){
            throw new NumberFormatException("Orario errato");
        }
    }

    public int getMinuti() {
        return minuti;
    }

    public int getOra() {
        return ora;
    }

    public int getSecondi() {
        return secondi;
    }

    @Override
    public int compareTo(@NotNull Orario o) {
        int res = Integer.compare(this.ora, o.ora);
        if(res != 0) return res;
        else res = Integer.compare(this.minuti, o.minuti);
        if(res != 0) return res;
        else return Integer.compare(this.secondi, o.secondi);
    }

    @Override
    public String toString(){
        String ore = (ora < 10) ? "0" + ora : String.valueOf(ora);
        String min = (minuti < 10) ? "0" + minuti : String.valueOf(minuti);
        String sec = (secondi < 10) ? "0" + secondi : String.valueOf(secondi);

        return ore + ":" + min + ":" + sec;
    }
}
