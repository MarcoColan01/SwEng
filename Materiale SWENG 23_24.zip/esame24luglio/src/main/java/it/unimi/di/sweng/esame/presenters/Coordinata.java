package it.unimi.di.sweng.esame.presenters;

public record Coordinata(double latitudine, double longitudine) {

    public static Coordinata createCoordinata(String lat, String longtd) {
        try {
            double latitudine = Double.parseDouble(lat);
            double longitudine = Double.parseDouble(longtd);
            if (latitudine < -90 || latitudine > 90) throw new IllegalArgumentException("Latitudine non valida");
            if (longitudine < -180 || longitudine > 180) throw new IllegalArgumentException("Longitudine non valida");
            return new Coordinata(latitudine, longitudine);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Coordinata non valida");
        }
    }
}
