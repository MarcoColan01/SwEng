package it.unimi.di.sweng.esame.model;

import org.jetbrains.annotations.NotNull;

public final class Segnalazione {
    private final @NotNull String codAppartamento;
    private final @NotNull Professione professione;
    private final @NotNull Coordinata coordinata;
    private final @NotNull Orario orario;
    public Segnalazione(@NotNull String codAppartamento, @NotNull String professione,
                        @NotNull String lat, @NotNull String longitude, @NotNull Orario orario){
        if(!codAppartamento.matches("^[A-Z]\\d{3}$"))
            throw new IllegalArgumentException("Codice appartamento non valido");
        this.codAppartamento = codAppartamento;
        double latitude;
        double lon;
        try{
            latitude = Double.parseDouble(lat);
            if(latitude < -90 || latitude > 90)
                throw new IllegalArgumentException("Latitudine non valida");
        }catch(NumberFormatException e){
            throw new NumberFormatException("Latitudine non valida");
        }
        try{
            lon = Double.parseDouble(longitude);
            if(lon < -90 || lon > 90)
                throw new IllegalArgumentException("Longitudine non valida");
        }catch(NumberFormatException e){
            throw new NumberFormatException("Longitudine non valida");
        }
        this.coordinata = new Coordinata(latitude, lon);
        try{
            this.professione = Professione.valueOf(professione);
        }catch (IllegalArgumentException e){
            throw new IllegalArgumentException("Tecnico non valido");
        }
        this.orario = orario;
    }

    public Orario getOrario() {
        return orario;
    }

    public Professione getProfessione() {
        return professione;
    }

    public String getCodAppartamento() {
        return codAppartamento;
    }
}
