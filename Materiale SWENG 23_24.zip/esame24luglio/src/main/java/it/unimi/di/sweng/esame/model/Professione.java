package it.unimi.di.sweng.esame.model;

public enum Professione {
    IDRAULICO,
    FABBRO,
    FALEGNAME,
    ELETTRICISTA,
    MURATORE
}
