package it.unimi.di.sweng.esame.presenters;

public enum Tecnico {
    FABBRO,
    IDRAULICO,
    FALEGNAME,
    ELETTRICISTA,
    MURATORE

}
