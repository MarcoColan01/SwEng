package it.unimi.di.sweng.esame.presenters;

import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.List;

public class SecondDisplayViewStrategy implements DisplayViewStrategy {
    @Override
    public void sortSegnalazioni(@NotNull List<Segnalazione> segnalazioni) {
        segnalazioni.sort(Comparator.comparingDouble(Segnalazione::haversineDistance));
        segnalazioni.sort(Comparator.comparingInt(o -> Tecnico.valueOf(o.tecnico()).ordinal()));
    }

    @Override
    public String showSegnalazione(@NotNull Segnalazione s1) {
        if(!s1.tecnico().equals("FABBRO")) return "";
        return "Richiesto un "
                + s1.tecnico()
                + " all'appartamento "
                + s1.codAppartamento()
                + " a "
                + String.format("%.2f%s", s1.haversineDistance(), "km");
    }
}
