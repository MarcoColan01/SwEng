package it.unimi.di.sweng.esame.model;

import it.unimi.di.sweng.esame.Main;
import it.unimi.di.sweng.esame.Observable;
import it.unimi.di.sweng.esame.Observer;
import it.unimi.di.sweng.esame.presenters.Coordinata;
import it.unimi.di.sweng.esame.presenters.Orario;
import it.unimi.di.sweng.esame.presenters.Segnalazione;
import org.jetbrains.annotations.NotNull;

import java.io.InputStream;
import java.util.*;


public class Modello implements Observable<List<Segnalazione>> {
  private final Map<String, List<Segnalazione>> segnalazioni = new HashMap<>();
  private final List<Observer<List<Segnalazione>>> observers = new ArrayList<>();

  public void readFile() {
    InputStream is = Main.class.getResourceAsStream("/reports.csv");
    assert is != null;
    Scanner s = new Scanner(is);

    while (s.hasNextLine()) {
      String linea = s.nextLine();
      System.err.println(linea);

      String[] el = linea.split(";");
      Coordinata coordinata = Coordinata.createCoordinata(el[2], el[3]);
      Segnalazione segnalazione = new Segnalazione(el[0], el[1], coordinata, Orario.creaOrario(el[4]));
      if(!segnalazioni.containsKey(el[0])){
        List<Segnalazione> app = new ArrayList<>();
        app.add(segnalazione);
        segnalazioni.put(el[0], app);
      }else{
        segnalazioni.get(el[0]).add(segnalazione);
      }
      notifyObservers();
    }
  }

  @Override
  public void addObserver(@NotNull Observer<List<Segnalazione>> observer) {
    observers.add(observer);
  }

  @Override
  public void notifyObservers() {
    for (Observer<List<Segnalazione>> observer : observers) {
      observer.update(getState());
    }
  }

  @Override
  public List<Segnalazione> getState() {
    List<Segnalazione> app = new ArrayList<>();
    for(List<Segnalazione> s: segnalazioni.values()){
      app.addAll(s);
    }
    return new ArrayList<>(app);
  }

  public void addSegnalazione(@NotNull Segnalazione segnalazione) {
    if(!segnalazioni.containsKey(segnalazione.codAppartamento())){
      List<Segnalazione> app = new ArrayList<>();
      app.add(segnalazione);
      segnalazioni.put(segnalazione.codAppartamento(), app);
      notifyObservers();
    }else{
      for(Segnalazione app: segnalazioni.get(segnalazione.codAppartamento())){
        if(app.tecnico().equals(segnalazione.tecnico())) throw new IllegalArgumentException("intervento già presente");
      }
      segnalazioni.get(segnalazione.codAppartamento()).add(segnalazione);
      notifyObservers();
    }
  }

  public void removeSegnalazione(@NotNull String codAppartamento, @NotNull String tecnico) {
    if(!segnalazioni.containsKey(codAppartamento)) throw new IllegalArgumentException("intervento non presente");
    for(Segnalazione segnalazione: segnalazioni.get(codAppartamento)){
      if(segnalazione.tecnico().equals(tecnico)){
        segnalazioni.get(codAppartamento).remove(segnalazione);
        if(segnalazioni.get(codAppartamento).size() == 0) segnalazioni.remove(codAppartamento);
        notifyObservers();
        return;
      }
    }
    throw new IllegalArgumentException("intervento non presente");
  }
}
