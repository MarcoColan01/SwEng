package it.unimi.di.sweng.esame.presenters;

import org.jetbrains.annotations.NotNull;

public record Orario(int ora, int minuti, int secondi) implements Comparable<Orario>{

    public static Orario creaOrario(String orario){
        String[] ora = orario.split(":");
        if(ora.length != 3) throw new IllegalArgumentException("Orario non valido");
        try{
            return new Orario(Integer.parseInt(ora[0]),Integer.parseInt(ora[1]),Integer.parseInt(ora[2]));
        }catch (NumberFormatException e){
            return new Orario(0,0,0);
        }
    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append(ora < 10 ? String.format("0%d", ora) : ora).append(":");
        sb.append(minuti < 10 ? String.format("0%d", minuti) : minuti).append(":");
        sb.append(secondi < 10 ? String.format("0%d", secondi) : secondi).append(":");
        return sb.deleteCharAt(sb.length()-1).toString();
    }

    @Override
    public int compareTo(@NotNull Orario other) {
        int res = Integer.compare(other.ora, ora);
        if (res != 0) return res;
        res = Integer.compare(other.minuti, minuti);
        if(res != 0) return res;
        return Integer.compare(other.secondi, secondi);
    }
}
