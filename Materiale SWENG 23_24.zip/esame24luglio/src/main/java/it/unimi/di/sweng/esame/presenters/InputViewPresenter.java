package it.unimi.di.sweng.esame.presenters;

import it.unimi.di.sweng.esame.model.Modello;
import it.unimi.di.sweng.esame.views.InputView;
import org.jetbrains.annotations.NotNull;

public class InputViewPresenter implements Presenter{
    private final Modello model;
    private final InputView view;
    public InputViewPresenter(@NotNull Modello model, @NotNull InputView view){
        this.model = model;
        this.view = view;
        view.addHandlers(this);
    }
    @Override
    public void action(String comando, String args) {
        if(comando.equals("Segnala")){
            String[] cmd = args.split(";");
            if(cmd.length != 4) {
                view.showError("Servono 4 campi separati da punto e virgola");
                return;
            }
            try{
                Coordinata coordinata = Coordinata.createCoordinata(cmd[2], cmd[3]);
                Segnalazione segnalazione = new Segnalazione(cmd[0], cmd[1], coordinata, Orario.creaOrario("0:0:0"));
                model.addSegnalazione(segnalazione);
                view.showSuccess();
            } catch (IllegalArgumentException e){
                view.showError(e.getMessage());
            }
        }else if(comando.equals("Risolvi")){
            String[] cmd = args.split(";");
            if(cmd.length != 2) {
                view.showError("Servono 2 campi separati da punto e virgola");
                return;
            }
            try{
                model.removeSegnalazione(cmd[0], cmd[1]);
            }catch (IllegalArgumentException e){
                view.showError("intervento non presente");
            }
        }
    }
}
