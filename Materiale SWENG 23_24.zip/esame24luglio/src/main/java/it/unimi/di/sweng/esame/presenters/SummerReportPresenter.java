package it.unimi.di.sweng.esame.presenters;

import it.unimi.di.sweng.esame.model.Orario;
import it.unimi.di.sweng.esame.model.Professione;
import it.unimi.di.sweng.esame.model.Segnalazione;
import it.unimi.di.sweng.esame.views.DisplayView;
import it.unimi.di.sweng.esame.views.SummerReportView;
import org.jetbrains.annotations.NotNull;

public class SummerReportPresenter implements Presenter {
    private final SummerReportView view;

    public SummerReportPresenter(@NotNull SummerReportView view) {
        this.view = view;
        view.addHandlers(this);
    }

    @Override
    public void action(String comando, String args) {
        String[] info = args.split(";");
        if (info.length < 4) return;
        try {
            Segnalazione segnalazione = new Segnalazione(
                    info[0], info[1], info[2], info[3], new Orario(info[4]));
        } catch (Exception e) {
            view.showError(e.getMessage());
        }
    }
}
