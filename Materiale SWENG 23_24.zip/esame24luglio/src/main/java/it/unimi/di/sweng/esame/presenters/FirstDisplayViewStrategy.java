package it.unimi.di.sweng.esame.presenters;

import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.List;

public class FirstDisplayViewStrategy implements DisplayViewStrategy {
    @Override
    public void sortSegnalazioni(List<Segnalazione> segnalazioni) {
        segnalazioni.sort((o1, o2) -> o2.orario().compareTo(o1.orario()));
    }

    @Override
    public String showSegnalazione(@NotNull Segnalazione s1) {
        return "Richiesto un "
                + s1.tecnico()
                + " all'appartamento "
                + s1.codAppartamento()
                + " alle "
                + s1.orario().toString();
    }
}
