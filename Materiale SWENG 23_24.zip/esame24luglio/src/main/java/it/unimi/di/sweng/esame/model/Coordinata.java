package it.unimi.di.sweng.esame.model;

public record Coordinata(double latitudine, double longitudine) {
    public Coordinata{
        if(latitudine < -90 || latitudine > 90)
            throw new IllegalArgumentException("Latitudine non valida");
        if(longitudine < -90 || longitudine > 90)
            throw new IllegalArgumentException("Longitudine non valida");
    }
}
