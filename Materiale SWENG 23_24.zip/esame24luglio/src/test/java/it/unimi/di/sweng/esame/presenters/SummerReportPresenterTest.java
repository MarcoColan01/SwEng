package it.unimi.di.sweng.esame.presenters;

import it.unimi.di.sweng.esame.views.DisplayView;
import it.unimi.di.sweng.esame.views.SummerReportView;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

class SummerReportPresenterTest {
    @Test
    void testInputCodiceSbagliato(){
        SummerReportView view = mock(SummerReportView.class);
        SummerReportPresenter SUT = new SummerReportPresenter(view);
        SUT.action("segnala", "PP02;1;1;1;1:1:1");
        verify(view).showError("Codice appartamento non valido");
    }

    @Test
    void testMestiereSbagliato(){
        SummerReportView view = mock(SummerReportView.class);
        SummerReportPresenter SUT = new SummerReportPresenter(view);
        SUT.action("segnala", "P001;PROFESSORE;1;1;1:1:1");
        verify(view).showError("Tecnico non valido");
    }

    @Test
    void latitudineSbagliataTest(){
        SummerReportView view = mock(SummerReportView.class);
        SummerReportPresenter SUT = new SummerReportPresenter(view);
        SUT.action("segnala", "P001;ELETTRICISTA;-100;1;1:1:1");
        verify(view).showError("Latitudine non valida");
    }
    @Test
    void longitudineSbagliataTest(){
        SummerReportView view = mock(SummerReportView.class);
        SummerReportPresenter SUT = new SummerReportPresenter(view);
        SUT.action("segnala", "P001;ELETTRICISTA;90;-100;1:1:1");
        verify(view).showError("Longitudine non valida");
    }
}