package it.unimi.di.sweng.esame.presenters;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

class OrarioTest {
    @Test
    void testOrarioCostruzione(){
        Orario orario = Orario.creaOrario("11:45:43");
        assertThat(orario.toString()).isEqualTo("11:45:43");
    }

    @ParameterizedTest
    @CsvSource({"11:45:43, 10:45:43, -1",
            "11:41:43, 11:45:43, 1",
            "11:45:43, 11:45:48, 1",
            "11:45:43, 11:45:43, 0"})
    void testOrarioCompare(String o1, String o2, String res){
        Orario orario1 = Orario.creaOrario(o1);
        Orario orario2 = Orario.creaOrario(o2);
        assertThat(orario1.compareTo(orario2)).isEqualTo(Integer.parseInt(res));
    }
}