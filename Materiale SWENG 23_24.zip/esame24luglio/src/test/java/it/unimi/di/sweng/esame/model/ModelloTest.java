package it.unimi.di.sweng.esame.model;

import it.unimi.di.sweng.esame.presenters.Coordinata;
import it.unimi.di.sweng.esame.presenters.Orario;
import it.unimi.di.sweng.esame.presenters.Segnalazione;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class ModelloTest {
    @Test
    void testModelloReadFile(){
        Modello SUT = new Modello();
        SUT.readFile();
        assertThat(SUT.getState()).hasSize(11);
    }
}