package it.unimi.di.sweng.esame.presenters;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class DisplayPresenterStrategyTest {
    @Test
    void testFirstDisplayViewPresenterStrategy() {
        DisplayViewStrategy SUT = new FirstDisplayViewStrategy();
        List<Segnalazione> segnalazioni = new ArrayList<>();
        Segnalazione s1 = new Segnalazione("A201",
                "IDRAULICO",
                mock(Coordinata.class),
                Orario.creaOrario("07:55:20"));
        Segnalazione s2 = new Segnalazione("C201",
                "IDRAULICO",
                mock(Coordinata.class),
                Orario.creaOrario("06:55:20"));
        Segnalazione s3 = new Segnalazione("B201",
                "IDRAULICO",
                mock(Coordinata.class),
                Orario.creaOrario("10:55:20"));
        segnalazioni.add(s1);
        segnalazioni.add(s2);
        segnalazioni.add(s3);
        SUT.sortSegnalazioni(segnalazioni);
        System.out.println(segnalazioni);
        assertThat(segnalazioni).containsExactly(s2, s1, s3);
    }

    @Test
    void testOutputFirstView() {
        DisplayViewStrategy SUT = new FirstDisplayViewStrategy();
        Segnalazione s1 = new Segnalazione("A201",
                "IDRAULICO",
                mock(Coordinata.class),
                Orario.creaOrario("07:55:20"));
        assertThat(SUT.showSegnalazione(s1)).isEqualTo("Richiesto un IDRAULICO all'appartamento A201 alle 07:55:20");
    }

    @Test
    void testSecondDisplayViewPresenterStrategy() {
        DisplayViewStrategy SUT = new SecondDisplayViewStrategy();
        List<Segnalazione> segnalazioni = new ArrayList<>();
        Segnalazione s1 = new Segnalazione("A201",
                "IDRAULICO",
                Coordinata.createCoordinata("80", "100"),
                mock(Orario.class));
        Segnalazione s2 = new Segnalazione("C201",
                "IDRAULICO",
                Coordinata.createCoordinata("70", "10"),
                mock(Orario.class));
        Segnalazione s3 = new Segnalazione("B201",
                "IDRAULICO",
                Coordinata.createCoordinata("50", "150"),
                mock(Orario.class));
        segnalazioni.add(s1);
        segnalazioni.add(s2);
        segnalazioni.add(s3);
        SUT.sortSegnalazioni(segnalazioni);
        assertThat(segnalazioni).containsExactly(s2, s1, s3);
    }

    @Test
    void testOutputSecondView() {
        DisplayViewStrategy SUT = new SecondDisplayViewStrategy();
        Segnalazione s3 = new Segnalazione("B201",
                "FABBRO",
                Coordinata.createCoordinata("50", "150"),
                mock(Orario.class));
        Segnalazione s2 = new Segnalazione("C201",
                "IDRAULICO",
                Coordinata.createCoordinata("70", "10"),
                mock(Orario.class));
        assertThat(SUT.showSegnalazione(s3)).isEqualTo("Richiesto un FABBRO all'appartamento B201 a 8742,62km");
        assertThat(SUT.showSegnalazione(s2)).isEmpty();
    }
}