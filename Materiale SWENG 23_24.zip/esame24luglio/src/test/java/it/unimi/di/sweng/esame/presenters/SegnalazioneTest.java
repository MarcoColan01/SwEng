package it.unimi.di.sweng.esame.presenters;

import org.assertj.core.data.Offset;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class SegnalazioneTest {
    @Test
    void testHaversineDistance(){
        Segnalazione s1 = new Segnalazione("P234",
                "FABBRO",
                Coordinata.createCoordinata("80", "100"),
                mock(Orario.class));
        assertThat(s1.haversineDistance()).isCloseTo(5061.1, Offset.offset(0.01));
    }
}