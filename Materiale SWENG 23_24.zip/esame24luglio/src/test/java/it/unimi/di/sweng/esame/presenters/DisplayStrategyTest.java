package it.unimi.di.sweng.esame.presenters;

import it.unimi.di.sweng.esame.model.Orario;
import it.unimi.di.sweng.esame.model.Segnalazione;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

class DisplayStrategyTest {
    @Test
    void strategyDisplay1Test(){
        List<Segnalazione> segnalazioni = new ArrayList<>();
        Segnalazione s1 = new Segnalazione(
                "P098","MURATORE",
                "90","23",new Orario("08:34:54"));
        Segnalazione s2 = new Segnalazione(
                "P093","ELETTRICISTA",
                "21","45",new Orario("10:33:54"));
        Segnalazione s3 = new Segnalazione(
                "P091","FABBRO",
                "87","54",new Orario("07:11:24"));
        segnalazioni.add(s1);
        segnalazioni.add(s2);
        segnalazioni.add(s3);
        DisplayStrategy SUT = new LeftDisplayStrategy();
        SUT.sortSegnalazioni(segnalazioni);
        assertThat(segnalazioni).containsExactly(s3, s1, s2);
        assertThat(SUT.getSegnalazione(segnalazioni.get(0)))
                .isEqualTo("Richiesto un FABBRO all'appartamento P091 alle 07:11:24");
    }

    @Test
    void strategyDisplay2Test(){
        List<Segnalazione> segnalazioni = new ArrayList<>();
        Segnalazione s1 = new Segnalazione(
                "P098","FABBRO",
                "45.23","9.72",new Orario("08:34:54"));
        Segnalazione s2 = new Segnalazione(
                "P093","FABBRO",
                "45.24","9.5",new Orario("10:33:54"));
        Segnalazione s3 = new Segnalazione(
                "P091","FABBRO",
                "44.2","10.1",new Orario("07:11:24"));
        segnalazioni.add(s1);
        segnalazioni.add(s2);
        segnalazioni.add(s3);
        DisplayStrategy SUT = new LeftDisplayStrategy();
        SUT.sortSegnalazioni(segnalazioni);
        assertThat(segnalazioni).containsExactly(s3, s1, s2);
        assertThat(SUT.getSegnalazione(segnalazioni.get(0)))
                .isEqualTo("Richiesto un FABBRO all'appartamento P091 alle 07:11:24");
    }
}