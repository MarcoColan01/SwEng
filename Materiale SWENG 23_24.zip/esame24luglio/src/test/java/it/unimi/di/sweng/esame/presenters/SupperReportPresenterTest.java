package it.unimi.di.sweng.esame.presenters;

import it.unimi.di.sweng.esame.model.Modello;
import it.unimi.di.sweng.esame.views.InputView;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;

class SupperReportPresenterTest {

    @Test
    void testCodiceAppartamentoSbagliato(){
        InputView view = mock(InputView.class);
        InputViewPresenter SUT = new InputViewPresenter(mock(Modello.class), view);
        SUT.action("Segnala", "PP01;1;1;1");
        verify(view).showError("Codice appartamento non valido");
    }

    @Test
    void testTecnicoNonValido(){
        InputView view = mock(InputView.class);
        InputViewPresenter SUT = new InputViewPresenter(mock(Modello.class), view);
        SUT.action("Segnala", "P001;PESCIVENDOLO;1;1");
        verify(view).showError("Tecnico non valido");
    }

    @Test
    void testLatitudineNonValida(){
        InputView view = mock(InputView.class);
        InputViewPresenter SUT = new InputViewPresenter(mock(Modello.class), view);
        SUT.action("Segnala", "P001;IDRAULICO;-100;1");
        verify(view).showError("Latitudine non valida");
    }

    @Test
    void testLongitudineNonValida(){
        InputView view = mock(InputView.class);
        InputViewPresenter SUT = new InputViewPresenter(mock(Modello.class), view);
        SUT.action("Segnala", "P001;IDRAULICO;-80;200");
        verify(view).showError("Longitudine non valida");
    }

    @Test
    void testSegnalazioneGiaPresente(){
        InputView view = mock(InputView.class);
        Modello model = spy(Modello.class);
        InputViewPresenter SUT = new InputViewPresenter(model, view);
        model.readFile();
        SUT.action("Segnala", "P205;FABBRO;80;160");
        verify(view).showError("intervento già presente");
    }

    @Test
    void testChiudiSegnalazioneNonPresente(){
        InputView view = mock(InputView.class);
        Modello model = spy(Modello.class);
        InputViewPresenter SUT = new InputViewPresenter(model, view);
        model.readFile();
        SUT.action("Risolvi", "H010;FALEGNAME");
        verify(view).showError("intervento non presente");
    }
}