package it.unimi.di.sweng.lab04;

public interface ChainedHandEvaluator {
    HandRank handEvaluator(PokerHand ph);
}
