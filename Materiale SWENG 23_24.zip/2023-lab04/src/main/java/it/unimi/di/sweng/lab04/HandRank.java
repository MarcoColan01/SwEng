package it.unimi.di.sweng.lab04;

public enum HandRank {
    HIGH_CARD,
    ONE_PAIR,
    TWO_PAIR,
    FLUSH,
}
