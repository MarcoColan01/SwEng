package it.unimi.di.sweng.lab03;

public interface Interpreter {
	void input(String program);
}
