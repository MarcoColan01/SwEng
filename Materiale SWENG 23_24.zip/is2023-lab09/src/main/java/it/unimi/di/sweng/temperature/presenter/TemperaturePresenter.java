package it.unimi.di.sweng.temperature.presenter;

import it.unimi.di.sweng.temperature.Observable;
import it.unimi.di.sweng.temperature.model.Model;
import it.unimi.di.sweng.temperature.view.View;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class TemperaturePresenter implements Presenter {
    private final Model model;
    private final ScaleStrategy strategy;
    private final List<View> views = new ArrayList<>();
    public TemperaturePresenter(Model model, ScaleStrategy strategy) {
        this.model = model;
        this.strategy = strategy;

        model.addObserver(this);
    }

    @Override
    public void update(@NotNull Observable<Double> subject, @NotNull Double state) {
        double temp = strategy.convertFromCelsius(state);
        for(View view: views){
            view.setValue(String.format(Locale.US, "%.2f", temp));
        }
    }

    @Override
    public void action(@NotNull String text) {
        model.setTemp(strategy.convertToCelsius(Double.parseDouble(text)));
    }

    @Override
    public void addView(View view) {
        views.add(view);
        view.addHandlers(this);
    }
}
