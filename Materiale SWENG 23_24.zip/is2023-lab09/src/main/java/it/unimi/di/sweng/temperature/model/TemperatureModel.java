package it.unimi.di.sweng.temperature.model;

import it.unimi.di.sweng.temperature.Observer;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class TemperatureModel implements Model {
  private double temperature;
  private final List<Observer> observers = new ArrayList<>();
  private final double tolerance = 0.01;

  @Override
  public void notifyObservers() {
    for (Observer observer : observers) {
      observer.update(this, temperature);
    }
  }

  @Override
  public void addObserver(@NotNull Observer<Double> obs) {
    observers.add(obs);
  }

  @Override
  public @NotNull Double getState() {
    return null;
  }

  @Override
  public double getTemp() {
    return temperature;
  }

  @Override
  public void setTemp(double temp) {
    if (Math.abs(temp-temperature) < tolerance) return;
    temperature = temp;
    notifyObservers();
  }
}
