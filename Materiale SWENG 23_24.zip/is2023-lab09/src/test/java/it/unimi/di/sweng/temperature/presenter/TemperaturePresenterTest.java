package it.unimi.di.sweng.temperature.presenter;

import it.unimi.di.sweng.temperature.model.Model;
import it.unimi.di.sweng.temperature.view.View;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.Answer;

import java.util.Locale;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TemperaturePresenterTest {
    @Mock
    Model model;
    @Mock
    ScaleStrategy strategy;
    @InjectMocks
    TemperaturePresenter SUT;

    @BeforeEach
    void setUp() {
    }

    @ParameterizedTest
    @ValueSource(doubles = {0, 34, 93.2})
    void actionTest(double input) {
        when(strategy.convertToCelsius(anyDouble())).thenAnswer(invocation -> invocation.getArgument(0));
        SUT.action(String.valueOf(input));
        verify(model).setTemp(input);
        verify(strategy).convertToCelsius(input);
    }

    @ParameterizedTest
    @CsvSource({
            "0, 0.00",
            "34, 34.00",
            "93, 93.20"
    })
    void updateTest(double input, String output) {
        View view = mock(View.class);
        when(strategy.convertFromCelsius(anyDouble())).thenAnswer(invocation -> invocation.getArgument(0));
        SUT.addView(view);
        SUT.update(model, input);
        verify(view).setValue(output);
        verify(strategy).convertFromCelsius(input);
    }

    @Test
    void addToModel() {
        verify(model).addObserver(SUT);
    }

    @Test
    void addToView() {
        View view = mock(View.class);
        SUT.addView(view);
        verify(view).addHandlers(SUT);
    }
}
