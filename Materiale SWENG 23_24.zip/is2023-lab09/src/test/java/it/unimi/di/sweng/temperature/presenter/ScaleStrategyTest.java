package it.unimi.di.sweng.temperature.presenter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;

public class ScaleStrategyTest {
    ScaleStrategy SUT;

    @Test
    public void fahrenheitScaleTest(){
        SUT = FahrenheitScale.SCALE;
        assertThat(SUT.convertFromCelsius(34)).isCloseTo(93.2, within(0.01));
    }

    @ParameterizedTest
    @ValueSource(doubles = {0, 34, 93.2})
    public void fahrenheitScaleToCelsiusTest(double input) {
        SUT = FahrenheitScale.SCALE;
        assertThat(SUT.convertToCelsius(SUT.convertFromCelsius(input))).isCloseTo(input, within(0.01));
    }

    @Test
    public void CelsiusScaleTest(){
        SUT = CelsiusScale.SCALE;
        assertThat(SUT.convertFromCelsius(34)).isCloseTo(34, within(0.01));
    }

    @ParameterizedTest
    @ValueSource(doubles = {0, 34, 93.2})
    public void celsiusScaleToCelsiusTest(double input) {
        SUT = CelsiusScale.SCALE;
        assertThat(SUT.convertToCelsius(SUT.convertFromCelsius(input))).isCloseTo(input, within(0.01));
    }
}
