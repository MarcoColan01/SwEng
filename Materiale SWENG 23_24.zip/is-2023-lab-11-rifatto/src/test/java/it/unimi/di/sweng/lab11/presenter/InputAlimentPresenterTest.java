package it.unimi.di.sweng.lab11.presenter;

import it.unimi.di.sweng.lab11.model.ItemQuantity;
import it.unimi.di.sweng.lab11.model.Model;
import it.unimi.di.sweng.lab11.view.InputAlimentView;
import it.unimi.di.sweng.lab11.view.InputView;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

class InputAlimentPresenterTest {
    @ParameterizedTest
    @CsvSource({" '',3,empty item name",
            "mele,aa, not a number",
            "mele, -3, negative number"
    })
    void testErrorAction(String item, String qty, String error){
        InputAlimentView view = mock(InputAlimentView.class);
        InputAlimentPresenter SUT = new InputAlimentPresenter(view, mock(Model.class));
        SUT.action(item, qty);
        verify(view).showError(error);
    }


    @Test
    void showCorrectInput(){
        InputView view = mock(InputView.class);
        InputAlimentPresenter SUT = new InputAlimentPresenter(view, mock(Model.class));
        SUT.action("mele", "5");
        Model model = mock(Model.class);
        verify(view).showSuccess();
    }
}