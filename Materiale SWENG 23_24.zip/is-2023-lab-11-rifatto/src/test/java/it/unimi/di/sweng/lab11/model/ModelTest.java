package it.unimi.di.sweng.lab11.model;

import it.unimi.di.sweng.lab11.Main;
import org.assertj.core.util.introspection.FieldSupport;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class ModelTest {
    @Test
    void testSimpleAddItem(){
        Model SUT = new Model();
        SUT.addAliment(new ItemQuantity("mele", 3));
        assertThat(SUT.getToBuyList())
                .containsExactly(new ItemQuantity("mele", 3));
    }

    @Test
    void testAddAlreadyPresentItem(){
        Model SUT = new Model();
        SUT.addAliment(new ItemQuantity("mele", 3));
        SUT.addAliment(new ItemQuantity("mele", 5));
        assertThat(SUT.getToBuyList())
                .containsExactly(new ItemQuantity("mele", 7));
    }

    @Test
    void testErrorAddItem(){
        Model SUT = new Model();
        for (int i = 0; i < Main.MAX_FOOD; i++) {
            SUT.addAliment(new ItemQuantity("item"+i, 3));
        }
        assertThatThrownBy(()->SUT.addAliment(mock(ItemQuantity.class)))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("too many items");
    }
}