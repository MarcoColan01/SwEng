package it.unimi.di.sweng.lab11.model;

import org.jetbrains.annotations.NotNull;

public final class ItemQuantity{
    private final @NotNull String name;
    private final int qty;

    public ItemQuantity(@NotNull String name, int qty){
        if(name.isBlank()) throw new IllegalArgumentException("empty item name");
        if(qty < 0) throw new IllegalArgumentException("negative number");
        this.name = name;
        this.qty = qty;

    }

    public @NotNull String getName() {
        return name;
    }

    public int getQty() {
        return qty;
    }

    public @NotNull ItemQuantity incrementa(@NotNull ItemQuantity item) {
        return new ItemQuantity(getName(), getQty()+ item.getQty());
    }
}
