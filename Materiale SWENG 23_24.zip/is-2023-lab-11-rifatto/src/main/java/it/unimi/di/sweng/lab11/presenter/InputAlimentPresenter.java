package it.unimi.di.sweng.lab11.presenter;

import it.unimi.di.sweng.lab11.model.ItemQuantity;
import it.unimi.di.sweng.lab11.model.Model;
import it.unimi.di.sweng.lab11.view.InputAlimentView;
import it.unimi.di.sweng.lab11.view.InputView;
import org.jetbrains.annotations.NotNull;

public class InputAlimentPresenter implements InputPresenter{
    private final @NotNull InputView view;
    private final @NotNull Model model;
    public InputAlimentPresenter(@NotNull InputView view, @NotNull Model model) {
        this.view = view;
        this.model = model;
        view.addHandlers(this);
    }

    @Override
    public void action(@NotNull String text, @NotNull String text1) {
        try{
            model.addAliment(new ItemQuantity(text,Integer.parseInt(text1)));
            view.showSuccess();
        }catch(NumberFormatException e){
            view.showError("not a number");
        }catch(IllegalArgumentException e){
            view.showError(e.getMessage());
        }
    }
}
