package it.unimi.di.sweng.lab11;

import org.jetbrains.annotations.NotNull;

public interface Observable<T> {
    void addObserver(Observer<T> observer);
    void notifyObservers();
    T getToBuyList();
}
