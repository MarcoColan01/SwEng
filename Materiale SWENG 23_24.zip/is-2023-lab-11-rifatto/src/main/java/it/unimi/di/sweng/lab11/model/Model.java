package it.unimi.di.sweng.lab11.model;

import it.unimi.di.sweng.lab11.Observable;
import it.unimi.di.sweng.lab11.Observer;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Model implements Observable<List<ItemQuantity>> {
    private @NotNull final Map<String, ItemQuantity> aliments = new HashMap<>();
    private @NotNull final List<Observer<List<ItemQuantity>>> observers = new ArrayList<>();
    public void addAliment(@NotNull ItemQuantity item) {
        if(!aliments.containsKey(item.getName()))
            if(aliments.size() == 8) throw new IllegalArgumentException("too many items");
            else aliments.put(item.getName(), item);
        else aliments.put(item.getName(), aliments.get(item.getName()).incrementa(item));
        notifyObservers();
    }

    @Override
    public void addObserver(@NotNull Observer<List<ItemQuantity>> observer) {
        observers.add(observer);
    }

    @Override
    public void notifyObservers() {
        for (Observer<List<ItemQuantity>> observer : observers) {
            observer.update(this);
        }
    }

    @Override
    public @NotNull List<ItemQuantity> getToBuyList() {
        return new ArrayList<>(aliments.values());
    }
}
