package it.unimi.di.sweng.lab12.model;

import it.unimi.di.sweng.lab12.Main;

public record Spesa(String nome, int amount) {
    public Spesa {
        if(nome.isBlank()) throw new IllegalArgumentException("empty friend name");
        if(!Main.FRIENDS.contains(nome)) throw new IllegalArgumentException("not a friend name");
        if(amount < 0) throw new IllegalArgumentException("negative amount");
    }
}
