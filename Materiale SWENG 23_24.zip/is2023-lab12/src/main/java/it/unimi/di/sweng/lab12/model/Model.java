package it.unimi.di.sweng.lab12.model;

import it.unimi.di.sweng.lab12.Main;
import it.unimi.di.sweng.lab12.presenter.Observer;
import org.jetbrains.annotations.NotNull;


import java.util.*;

public class Model implements Observable<Map<String, Double>> {
    private final Map<String, Double> debitori = new HashMap<>();
    private final Map<String, Double> creditori = new HashMap<>();

    private final @NotNull List<Observer<Map<String, Double>>> observers = new ArrayList<>();

    public void addSpesa(Spesa spesa) {
        double amount = 0;
        double amountPerPerson  = (double) spesa.amount()/5;
        for(String nome: Main.FRIENDS){
            amount = 0;
            if(nome.equals(spesa.nome())) amount = amountPerPerson*4;
            else amount = amount - amountPerPerson;
            if(creditori.containsKey(nome)){
                amount += creditori.get(nome);
                creditori.remove(nome);
            } else if (debitori.containsKey(nome)) {
                amount -= debitori.get(nome);
                debitori.remove(nome);
            }
            if(amount < 0){
                debitori.put(nome, Math.abs(amount));
            }else if(amount > 0 ) creditori.put(nome, Math.abs(amount));
        }
        notifyObservers();
    }

    public Map<String, Double> getDebitori() {
        return Collections.unmodifiableMap(debitori);
    }

    @Override
    public void notifyObservers() {
        for (Observer<Map<String, Double>> observer : observers) {
            observer.update(this);
        }
    }

    @Override
    public void addObserver(@NotNull Observer<Map<String, Double>> observer) {
        observers.add(observer);
    }

    public Map<String, Double> getCreditori() {
        return Collections.unmodifiableMap(creditori);
    }
}
