package it.unimi.di.sweng.lab12.presenter;

import it.unimi.di.sweng.lab12.model.Spesa;
import it.unimi.di.sweng.lab12.view.InputView;
import org.jetbrains.annotations.NotNull;

public class InputExpensePresenter implements InputPresenter {
    private @NotNull final InputView view;
    public InputExpensePresenter(@NotNull InputView view) {
        this.view = view;
        view.addHandlers(this);
    }

    @Override
    public void action(@NotNull String nome, @NotNull String importo) {
        try {
            if(importo.isBlank()) {
                view.showError("empty amount");
            }else{
                Spesa spesa = new Spesa(nome, Integer.parseInt(importo));
                //model.addSpesa(nome, importo);
                view.showSuccess();
            }
        }catch(NumberFormatException e){
                view.showError("not an integer amount");
        }catch(IllegalArgumentException e){
            view.showError(e.getMessage());
        }
    }
}