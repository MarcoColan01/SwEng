package it.unimi.di.sweng.lab12.presenter;

import it.unimi.di.sweng.lab12.model.Model;
import it.unimi.di.sweng.lab12.model.Observable;
import it.unimi.di.sweng.lab12.view.DisplayView;
import org.jetbrains.annotations.NotNull;

import java.util.Map;

public class DisplayViewPresenter implements Observer<Map<String,Double>>{
    private @NotNull final Model model;
    private @NotNull final DisplayView view;
    public DisplayViewPresenter(@NotNull Model model, @NotNull DisplayView view) {
        this.model = model;
        this.view = view;
        model.addObserver(this);
    }

    @Override
    public void update(@NotNull Observable<Map<String, Double>> subject) {
        int i = 0;
        for(String s : subject.getCreditori().keySet()){
            view.set(i++, s + " " + subject.getCreditori().get(s));
        }
    }
}
