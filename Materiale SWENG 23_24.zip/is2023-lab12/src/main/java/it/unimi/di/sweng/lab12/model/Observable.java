package it.unimi.di.sweng.lab12.model;

import it.unimi.di.sweng.lab12.presenter.Observer;
import org.jetbrains.annotations.NotNull;

import java.util.Map;

public interface Observable<T> {
    void notifyObservers();
    void addObserver(@NotNull Observer<Map<String, Double>> observer);
    Map<String, Double> getDebitori();
    Map<String, Double> getCreditori();
}
