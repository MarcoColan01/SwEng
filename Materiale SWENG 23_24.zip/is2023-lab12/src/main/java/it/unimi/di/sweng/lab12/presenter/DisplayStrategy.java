package it.unimi.di.sweng.lab12.presenter;

public interface DisplayStrategy {

}
