# CORSO INGEGNERIA DEL SOFTWARE A.A. 2023/24

## LABORATORIO 12 (VALUTATO)

* TEAMMATE 1: Colangelo Marco  980701
* TEAMMATE 2: Garberi Davide  984703

Ogni coppia di studenti effettua il **fork** di questo repository.
L'utente che ha effettuato il fork modifica questo README inserendo le opportune **informazioni sui
membri del team** seguendo lo schema sopra riportato.
Inoltre, concede i permessi di scrittura al proprio compagno di team e i **permessi di lettura** ai
docenti (`carlo.bellettini` e `mattia.monga`).

## Suddivisione delle spese

Obiettivo dell'esercizio è progettare e realizzare un insieme di classi atte a
produrre un semplice programma Java che si occupi di gestire la divisione di
spese comuni fra 5 persone: ogni spesa (un numero intero di Euro) è sostenuta da
una persona e produce un debito per ciascuna delle altre, in modo che tutti
contribuiscano con la medesima quota (in generale la quota non è un numero
intero, è possibile ricorrere anche ai centesimi).

Vengono già fornite due *Viste* del sistema:

- [`InputExpenseView`](src/main/java/it/unimi/di/sweng/lab12/view/InputExpenseView.java):
  permette di immettere la spesa sostenuta da uno specifico membro del gruppo.
- [`DisplayView`](src/main/java/it/unimi/di/sweng/lab12/view/DisplayView.java):
  permette di visualizzare un elenco di persone e il loro debito o credito nei confronti del gruppo.

Viene fornita anche una prima versione della classe  [`Main`](src/main/java/it/unimi/di/sweng/lab12/Main.java) che
permette d'istanziare la parte statica delle viste, e di una
interfaccia [`InputPresenter`](src/main/java/it/unimi/di/sweng/lab12/presenter/InputPresenter.java).

**TUTTE LE CLASSI DATE POSSONO ESSERE DA VOI MODIFICATE (CANCELLATE, COMPLETATE) PER ADERIRE A VOSTRE IDEE DI
PROGETTAZIONE**

Lanciando il programma (tramite il task `run` di gradle) si ottiene una interfaccia simile a quella nella figura
sottostante **(le viste sono state adesso disposte in orizzontale per evitare problemi con schermi piccoli)**.

![GUI](bootGUI.png)

## TRACCIA

Completare, in modo da realizzare un'organizzazione del sistema di tipo
*Model-View-Presenter*, aggiungendo le classi necessarie in modo che
all'immissione di una nuova spesa le viste si aggiornino coerentemente:

- La vista con titolo ADA riporta il debito o credito di Ada
- La vista con titolo BRUNO riporta il debito o credito di Bruno
- La vista con titolo CREDITORS riporta la lista dei componenti il gruppo con un
  credito (> 0) in ordine decrescente di credito
- La vista con titolo DEBTORS riporta la lista dei componenti il gruppo con un
  debito (< 0) in ordine decrescente di debito (cioè in ordine crescente dal
  punto di vista numerico)

(I componenti "in pari" cioè senza crediti né debiti non vengono riportati né
fra i creditori né fra i debitori)


### Esempi di esecuzione

Il codice fornite prevede anche alcuni test di integrazione:

`testCreditorsDisplayStart` controlla che all'inizio la situazione sia:

![GUI](startGUI.png)

`testCorrectSingleInput` controlla che dopo una singola immissione (Ada paga 6 euro) la situazione sia:

![GUI](singleGUI.png)

`testCorrectMultiInput` controlla che dopo alcune immissioni (Chiara paga 4 euro, Ada paga 1 euro) la situazione sia:

![GUI](multiGUI.png)

`testCorrectOrderDisplay` controlla che dopo alcune immissioni (Elena paga 5 euro, Bruno paga 1 euro, Dario paga 10 euro) la situazione sia:

![GUI](orderGUI.png)


### Gestione input errati

Nel caso in cui l'utente inserisca un input non valido (ad esempio una spesa negativa, un nome diverso dai 5 previsti, etc.) il sistema
deve mostrare un messaggio di errore (tramite il metodo `showError`) nella vista appropriata.

Oltre che nei **test di unità**, potete se volete anche aggiungere nuovi **test di integrazione** .

### Processo

Una volta effettuato il **clone** del repository, il gruppo completa l'implementazione seguendo la *metodologia TDD*;
in maggior dettaglio, ripete i passi seguenti fino ad aver implementato tutte le funzionalità richieste:

* scelta la prossima funzionalità richiesta da implementare, inizia una feature di gitflow
* implementa un test per la funzionalità,
* verifica che **il codice compili correttamente**, ma l'**esecuzione del test fallisca**; solo a questo punto effettua
  un *commit*
  (usando `IntelliJ` o `git add` e `git commit`) iniziando il messaggio di commit con la stringa `ROSSO:`,
* aggiunge la minima implementazione necessaria a realizzare la funzionalità, in modo che **il test esegua con
  successo**; solo a questo punto
  effettua un *commit* (usando `IntelliJ` o `git add` e `git commit`) iniziando il messaggio di commit con la
  stringa `VERDE:`,
* procede, se necessario, al **refactoring** del codice, accertandosi che le modifiche non
  comportino il fallimento di alcun test; solo in questo caso fa seguire a ogni
  passo un *commit* (usando `IntelliJ` o `git add` e `git commit`)
  iniziando il messaggio di commit con la stringa `REFACTORING:`,
* ripete i passi precedenti fino a quando non considera la funzionalità realizzata nel suo complesso e allora chiude la
  feature di gitflow
* effettua un *push* dei passi svolti su `gitlab.di.unimi.it` con `IntelliJ` o`git push --all`.

### Testing

Mano a mano che si sviluppa il progetto, si deve controllare di mantenere una copertura, sia dei comandi che delle
decisioni, soddisfacente soprattutto per il codice rilaciato all'utente (se inferiore al 100% inserire un commento che spieghi perché non è possibile raggiungerlo).

Sono presenti anche alcuni test di integrazione che (una volta completato nella inizializzazione) il progetto
alla fine "dovrebbe" passare. 

### Consegna

Al termine del laboratorio dovete impacchettare l'**ultima versione stabile** come
una _release_ di gitflow chiamata "consegna" (usare esattamente questo nome) ed
effettuare un ultimo *push* di tutti i rami locali (**comprese eventuali feature
aperte ma non completate**).

## **Verificate su `gitlab.di.unimi.it`** che ci sia la completa traccia dei *commit* effettuati nei vari *branch* e che ci siano anche i *tag*. Infine chiaramente anche di averne dato visibilità ai docenti. 
