package it.unimi.di.sweng.reverseindex;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.assertj.core.api.Assertions.assertThat;

public class InvertedIndexTest {
    @ParameterizedTest
    @CsvSource({"'sotto la panca\nla capra campa', 2",
            "'sotto la\npanca la capra\n campa', 3"})
    void simpleInputTest(String input, String output){
        InvertedIndex SUT = new InvertedIndex(input);
        assertThat(SUT.getDocuments()).isEqualTo(Integer.valueOf(output));
    }

    @ParameterizedTest
    @CsvSource({"'sotto, la panca', sotto la panca",
            "'sotto la, panca la capra.\ncampa!', 'sotto la panca la capra\ncampa'"})
    void inputNoPuntuactionTest(String input, String output){
        InputStrategy inStr = new InputNoPuntuaction(input);
        InvertedIndex SUT = new InvertedIndex(inStr);
        assertThat(SUT.toString()).isEqualTo(output);
    }

    @ParameterizedTest
    @CsvSource({"'sotto la panca', 'sotto panca'",
            "'sotto la panca la capra\ncampa', 'sotto panca capra\ncampa'"})
    void inputNoStopWordTest(String input, String output){
        InputStrategy inStr = new InputNoStopWord(input, "la");
        InvertedIndex SUT = new InvertedIndex(inStr);
        assertThat(SUT.toString()).isEqualTo(output);
    }

    @ParameterizedTest
    @CsvSource({"'sotto la panca la capra\ncampa', 'sotto [0]\nla [0]\npanca [0]\ncapra [0]\ncampa [1]'"})
    void outputIndiciTest(String input, String output){
        OutputStrategy ordOut = new OutputIndicized();
        InvertedIndex SUT = new InvertedIndex(input);
        assertThat(SUT.createOutput(ordOut)).isEqualTo(output);
    }

    @ParameterizedTest
    @CsvSource({"'sotto la panca\nla capra\nla sotto', 'la [0, 1, 2]\nsotto [0, 2]\npanca [0]\ncapra [1]'"})
    void outputLunghezzaIndiciTest(String input, String output){
        OutputStrategy ordOut = new OutputIndexLength();
        InvertedIndex SUT = new InvertedIndex(input);
        assertThat(SUT.createOutput(ordOut)).isEqualTo(output);
    }

    @ParameterizedTest
    @CsvSource({"'sotto la panca\nla capra', 'capra [1]\nla [0, 1]\npanca [0]\nsotto [0]'"})
    void outputLunghezzaParoleTest(String input, String output){
        OutputStrategy ordOut = new OutputWordLength();
        InvertedIndex SUT = new InvertedIndex(input);
        assertThat(SUT.createOutput(ordOut)).isEqualTo(output);
    }

    @ParameterizedTest
    @CsvSource({"'input1.txt', 'sotto la panca\nla capra'"})
    void inputFileTest(String input, String output){
        InputStrategy inStr = new InputFile(input);
        InvertedIndex SUT = new InvertedIndex(inStr);
        assertThat(SUT.toString()).isEqualTo(output);
    }
}
