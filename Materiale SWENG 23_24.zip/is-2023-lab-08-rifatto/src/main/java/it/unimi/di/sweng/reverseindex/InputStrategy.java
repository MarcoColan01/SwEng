package it.unimi.di.sweng.reverseindex;

import java.util.Iterator;

public interface InputStrategy {
    Iterator<String> iterator();
}
