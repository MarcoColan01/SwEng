package it.unimi.di.sweng.reverseindex;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class InputFile implements InputStrategy {
    private final List<String> text = new ArrayList<>();
    public InputFile(String input) {
        try(BufferedReader reader = new BufferedReader(new FileReader(input))){
            String s;
            while((s = reader.readLine()) != null){
                text.add(s);
            }
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    @Override
    public Iterator<String> iterator() {
        return new ArrayList<>(text).iterator();
    }
}
