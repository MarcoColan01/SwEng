package it.unimi.di.sweng.reverseindex;

import java.util.ArrayList;
import java.util.List;

public class OutputWordLength extends AbstractOutput {

        @Override
        public String createOutput(List<String> documenti){
        riempiMappa(documenti);
        ArrayList<String> parole = new ArrayList<>(occorrenze.keySet());
        parole.sort(String::compareTo);
        for(String s: parole){
            sb.append(s).append(" ").append(occorrenze.get(s).toString()).append("\n");
        }
        return sb.deleteCharAt(sb.length()-1).toString();
    }
}
