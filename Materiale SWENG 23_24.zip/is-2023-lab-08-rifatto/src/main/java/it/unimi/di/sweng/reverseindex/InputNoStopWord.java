package it.unimi.di.sweng.reverseindex;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class InputNoStopWord implements InputStrategy {
    private final List<String> text = new ArrayList<>();
    public InputNoStopWord(String input, String stopword) {
        for(String s: input.split("\n")){
            s = s.replaceAll(stopword, "")
                    .replaceAll("\\s+", " ");
            text.add(s);
        }
    }

    @Override
    public Iterator<String> iterator() {
        return new ArrayList<>(text).iterator();
    }
}
