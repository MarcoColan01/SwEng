package it.unimi.di.sweng.reverseindex;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public abstract class AbstractOutput implements OutputStrategy {
    StringBuilder sb = new StringBuilder();
    Map<String, List<Integer>> occorrenze = new LinkedHashMap<>();
    public void riempiMappa(List<String> documenti) {
        int nline = 0;
        for (String frase : documenti) {
            for (String s : frase.split(" ")) {
                if (occorrenze.containsKey(s) && !occorrenze.get(s).contains(nline)) {
                    occorrenze.get(s).add(nline);
                } else {
                    occorrenze.put(s, new ArrayList<>());
                    occorrenze.get(s).add(nline);
                }
            }
            nline++;
        }
    }
}
