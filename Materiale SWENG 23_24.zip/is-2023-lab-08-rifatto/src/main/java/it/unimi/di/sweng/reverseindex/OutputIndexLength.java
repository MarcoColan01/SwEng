package it.unimi.di.sweng.reverseindex;

import java.util.ArrayList;
import java.util.List;

public class OutputIndexLength extends AbstractOutput {
    @Override
    public String createOutput(List<String> documenti){
        riempiMappa(documenti);
        ArrayList<String> parole = new ArrayList<>(occorrenze.keySet());
        parole.sort((o1, o2) ->{
            if(occorrenze.get(o1).size() > occorrenze.get(o2).size()) return -1;
            else return 1;
        });
        for(String s: parole){
            sb.append(s).append(" ").append(occorrenze.get(s).toString()).append("\n");
        }
        return sb.deleteCharAt(sb.length()-1).toString();
    }

}
