package it.unimi.di.sweng.reverseindex;

import java.util.*;

public class InvertedIndex {
    private final List<String> documenti = new ArrayList<>();
    public InvertedIndex(String input) {
        documenti.addAll(Arrays.asList(input.split("\n")));
    }

    public InvertedIndex(InputStrategy inStr) {
        Iterator<String> it = inStr.iterator();
        while(it.hasNext()){
            documenti.add(it.next());
        }
    }

    public int getDocuments() {
        return documenti.size();
    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        for(String s: documenti){
            sb.append(s).append("\n");
        }
        return sb.deleteCharAt(sb.length()-1).toString();
    }

    public String createOutput(OutputStrategy ordOut) {
        return ordOut.createOutput(new ArrayList<>(documenti));
    }
}
