package it.unimi.di.sweng.reverseindex;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class InputNoPuntuaction implements InputStrategy {
    private final List<String> text = new ArrayList<>();
    public InputNoPuntuaction(String input) {
        String regex = "[^a-zA-Z\\s]";
        for(String frase: input.split("\n")){
            frase = frase.replaceAll(regex, "");
            text.add(frase);
        }
    }

    @Override
    public Iterator<String> iterator() {
        return new ArrayList<>(text).iterator();
    }
}
