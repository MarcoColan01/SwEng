package it.unimi.di.sweng.reverseindex;

import java.util.*;

public class OutputIndicized extends AbstractOutput {
    @Override
    public String createOutput(List<String> documenti){
        riempiMappa(documenti);
        for(String s: occorrenze.keySet()){
            sb.append(s).append(" ").append(occorrenze.get(s).toString()).append("\n");
        }
        return sb.deleteCharAt(sb.length()-1).toString();
    }
}
