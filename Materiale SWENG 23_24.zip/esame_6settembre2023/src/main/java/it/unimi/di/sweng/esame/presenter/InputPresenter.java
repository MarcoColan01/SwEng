package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.model.Insegnante;
import it.unimi.di.sweng.esame.model.Modello;
import it.unimi.di.sweng.esame.model.Supplenza;
import it.unimi.di.sweng.esame.views.USRView;
import org.jetbrains.annotations.NotNull;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class InputPresenter implements Presenter{
    private final USRView view;
    private final @NotNull Modello model;

    public InputPresenter(@NotNull USRView view, @NotNull Modello model) {
        this.view = view;
        this.model = model;
        view.addHandlers(this);
    }

    @Override
    public void action(String command, String args) {
        switch (command) {
            case "Inserisci" : {
                String[] campi = args.split(":");
                if(campi.length != 4) {
                    view.showError("I campi devono essere 4");
                    return;
                }
                try {
                    Supplenza supplenza = new Supplenza(campi[0],
                            Integer.parseInt(campi[1]),
                            campi[2],
                            new SimpleDateFormat("dd/MM/yyyy").parse(campi[3]));
                    model.addRichiesta(supplenza);
                    view.showSuccess();
                } catch (IllegalArgumentException e) {
                    view.showError(e.getMessage());
                    return;
                } catch (ParseException e) {
                    view.showError("Data inizio non corretta");
                    return;
                }
                break;
            }
            case "Accetta" : {
                try {
                    String[] campi = args.split(":");
                    Insegnante insegnante = new Insegnante(campi[0]);
                    String codIstituto = campi[1];
                    Date data = new SimpleDateFormat("dd/MM/yyyy").parse(campi[2]);
                    model.accettaRichiesta(insegnante.cod(), codIstituto, data);
                    view.showSuccess();
                } catch (IllegalArgumentException e) {
                    view.showError(e.getMessage());
                    return;
                } catch (ParseException e) {
                    view.showError("Data inizio non corretta");
                    return;
                }
                break;
            }
            default: {
                view.showError("Comando non riconosciuto");
            }
        }

    }
}
