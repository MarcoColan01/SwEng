package it.unimi.di.sweng.esame.model;

import org.jetbrains.annotations.NotNull;

import java.time.ZonedDateTime;
import java.util.Date;

public record Supplenza(@NotNull String cod, int durata, @NotNull String comune, @NotNull Date date) {
    public Supplenza {
        char[] codice = cod.toCharArray();
        if(codice.length != 5)
            throw new IllegalArgumentException("Codice istituto non valido");
        if((codice[0] < 65 || codice[0] > 90) ||  (codice[1] < 65 || codice[1] > 90) || (codice[2] < 48 || codice[2] > 57) ||
                (codice[3] < 48 || codice[3] > 57) || (codice[4] < 48 || codice[4] > 57))
            throw new IllegalArgumentException("Codice istituto non valido");
        if(durata < 0)
            throw new IllegalArgumentException("Durata non può essere negativa");
    }
}
