package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.Main;
import it.unimi.di.sweng.esame.Observable;
import it.unimi.di.sweng.esame.Observer;
import it.unimi.di.sweng.esame.model.Modello;
import it.unimi.di.sweng.esame.model.Supplenza;
import it.unimi.di.sweng.esame.views.DisplayView;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class DisplayPresenter implements Observer<List<Supplenza>> {
    private final DisplayView view;
    private final DisplayStrategy strategy;

    public DisplayPresenter(DisplayView view, Modello model, DisplayStrategy strategy) {
        this.view = view;
        this.strategy = strategy;
        model.addObserver(this);
    }

    @Override
    public void update(@NotNull Observable<List<Supplenza>> subject) {
        List<Supplenza> tmp = subject.getState();
        strategy.sortView(tmp);
        int count = 0;
        for (Supplenza supplenza : tmp) {
            if(count >= Main.NUMVOCIELENCO) break;
            view.set(count++, strategy.getSupplenza(supplenza));
        }
        for(int i = count; i < Main.NUMVOCIELENCO; i++)
            view.set(i, "");
    }
}
