package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.model.Supplenza;
import org.jetbrains.annotations.NotNull;

import java.text.SimpleDateFormat;
import java.util.List;

public enum RightViewStrategy implements DisplayStrategy {
    INSTANCE;
    @Override
    public void sortView(@NotNull List<Supplenza> supplenze) {
        supplenze.sort((o1, o2) -> {
            int res = Integer.compare(o1.durata(), o2.durata());
            if(res == 0) return o1.date().compareTo(o2.date());
            return res;
        });
    }

    @Override
    public @NotNull String getSupplenza(@NotNull Supplenza supplenza) {
        String formattedDate = new SimpleDateFormat("dd/MM/yyyy").format(supplenza.date());
        return supplenza.durata()
                + " : dal "
                + formattedDate
                + " - "
                + supplenza.cod();
    }
}
