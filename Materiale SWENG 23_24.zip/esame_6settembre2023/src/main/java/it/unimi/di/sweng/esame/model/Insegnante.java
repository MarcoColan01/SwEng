package it.unimi.di.sweng.esame.model;

import org.jetbrains.annotations.NotNull;

public record Insegnante(@NotNull String cod) {
    public Insegnante {
        char[] codice = cod.toCharArray();
        if(codice.length != 4)
            throw new IllegalArgumentException("Codice insegnante non valido");
        if((codice[0] < 65 || codice[0] > 90) ||  (codice[1] < 48 || codice[1] > 57) || (codice[2] < 48 || codice[2] > 57) ||
                (codice[3] < 65 || codice[3] > 90))
            throw new IllegalArgumentException("Codice insegnante non valido");
    }
}
