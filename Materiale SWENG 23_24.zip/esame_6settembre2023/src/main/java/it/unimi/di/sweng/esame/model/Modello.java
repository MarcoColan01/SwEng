package it.unimi.di.sweng.esame.model;

import it.unimi.di.sweng.esame.Observable;
import it.unimi.di.sweng.esame.Observer;
import org.jetbrains.annotations.NotNull;

import java.io.InputStream;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


public class Modello implements Observable<List<Supplenza>> {

    private final @NotNull Map<String, List<Supplenza>> supplenze = new HashMap<>();
    private final @NotNull List<Observer<List<Supplenza>>> observers = new ArrayList<>();

    public void readFile() {
        InputStream is = Modello.class.getResourceAsStream("/reports.csv");
        assert is != null;
        Scanner s = new Scanner(is);

        while (s.hasNextLine()) {
            String linea = s.nextLine();
            String[] el = linea.split(":");

            try {
                Supplenza supplenza = new Supplenza(el[0], Integer.parseInt(el[1]), el[2],
                        new SimpleDateFormat("dd/MM/yyyy").parse(el[3]));
                List<Supplenza> suppl = new ArrayList<>();
                if(!supplenze.containsKey(el[0])) {
                    suppl.add(supplenza);
                } else{
                    suppl = supplenze.get(el[0]);
                    suppl.add(supplenza);
                }
                supplenze.put(el[0], suppl);
            } catch (ParseException e) {
            }
        }
    }

    @Override
    public void notifyObservers() {
        for (Observer<List<Supplenza>> observer : observers) {
            observer.update(this);
        }
    }

    public @NotNull List<Supplenza> getState() {
        List<Supplenza> state = new ArrayList<>();
        for (List<Supplenza> value : supplenze.values()) {
            state.addAll(value);
        }
        return new ArrayList<>(state);
    }

    @Override
    public void addObserver(@NotNull Observer<List<Supplenza>> observer) {
        observers.add(observer);
    }

    public void addRichiesta(@NotNull Supplenza supplenza) {
        List<Supplenza> s = new ArrayList<>();
        if(!supplenze.containsKey(supplenza.cod())) s.add(supplenza);
        else{
            s = supplenze.get(supplenza.cod());
            s.add(supplenza);
        }
        supplenze.put(supplenza.cod(), s);
        notifyObservers();
    }

    public void accettaRichiesta(@NotNull String codInsegnante, @NotNull String istituto, @NotNull Date dataInizio) {
        if(!supplenze.containsKey(istituto)) throw new IllegalArgumentException("Richiesta non presente");
        for(Supplenza supplenza: supplenze.get(istituto)){
            if(supplenza.cod().equals(istituto) && supplenza.date().equals(dataInizio)) {
                supplenze.get(istituto).remove(supplenza);
                notifyObservers();
                return;
            }
        }
        throw new IllegalArgumentException("Richiesta non presente");
    }
}
