package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.model.Supplenza;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public interface DisplayStrategy {
    void sortView(@NotNull List<Supplenza> supplenze);
    @NotNull String getSupplenza(@NotNull Supplenza supplenza);
}
