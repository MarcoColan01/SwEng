package it.unimi.di.sweng.esame.presenter;

public interface Presenter {
  void action(String text1, String text2);
}
