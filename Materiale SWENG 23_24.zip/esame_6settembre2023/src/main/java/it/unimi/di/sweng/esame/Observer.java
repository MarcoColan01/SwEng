package it.unimi.di.sweng.esame;

import it.unimi.di.sweng.esame.model.Supplenza;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public interface Observer<T> {
    void update(@NotNull Observable<List<Supplenza>> subject);
}
