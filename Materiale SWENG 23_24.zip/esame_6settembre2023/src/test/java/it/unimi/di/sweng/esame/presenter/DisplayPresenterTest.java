package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.model.Modello;
import it.unimi.di.sweng.esame.model.Supplenza;
import it.unimi.di.sweng.esame.views.DisplayView;
import org.junit.jupiter.api.Test;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DisplayPresenterTest {

    @Test
    void correctUpdateTest() {
        DisplayView view = mock(DisplayView.class);
        Modello model = mock(Modello.class);
        DisplayStrategy strategy = LeftViewStrategy.INSTANCE;
        DisplayPresenter SUT = new DisplayPresenter(view, model, strategy);

        List<Supplenza> supplenze = new ArrayList<>();
        Supplenza s1 = new Supplenza("BG202", 1, "Varese",
                Date.valueOf(LocalDate.of(2023, 9, 3)));
        Supplenza s2 = new Supplenza("BG202", 1, "Bergamo",
                Date.valueOf(LocalDate.of(2023, 9, 4)));
        Supplenza s3 = new Supplenza("BG202", 1, "Varese",
                Date.valueOf(LocalDate.of(2023, 9, 2)));
        supplenze.add(s1);
        supplenze.add(s2);
        supplenze.add(s3);
        when(model.getState()).thenReturn(supplenze);
        SUT.update(model);
        verify(view).set(0, "Bergamo : dal 04/09/2023 - BG202");
        verify(view).set(1, "Varese : dal 02/09/2023 - BG202");
        verify(view).set(2, "Varese : dal 03/09/2023 - BG202");
    }
}