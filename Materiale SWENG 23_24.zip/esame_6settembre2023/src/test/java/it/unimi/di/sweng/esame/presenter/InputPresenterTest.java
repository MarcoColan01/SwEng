package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.model.Modello;
import it.unimi.di.sweng.esame.views.USRView;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

class InputPresenterTest {

    USRView view = mock(USRView.class);
    InputPresenter SUT = new InputPresenter(view, mock(Modello.class));

    @ParameterizedTest
    @ValueSource(strings =
            {
                    "PP02:1:1:11/08/1999",
                    "P002P:1:1:11/08/1999",
                    "00002:1:1:11/08/1999"
            }
    )
    void segnalaCodiceIstitutoNonValidoTest(String input) {
        SUT.action("Inserisci",input);
        verify(view).showError("Codice istituto non valido");
    }

    @Test
    void dataNonValidaTest() {
        SUT.action("Inserisci","LC169:8:Lecco:11-09-2023");
        verify(view).showError("Data inizio non corretta");
    }

    @Test
    void durataNonValidaTest() {
        SUT.action("Inserisci","LC169:-8:Lecco:11/09/2023");
        verify(view).showError("Durata non può essere negativa");
    }

    @ParameterizedTest
    @ValueSource(strings =
            {
                    "PP02:1:11/08/1999",
                    "0002:1:11/08/1999",
                    "P002Q:1:1/08/1999"
            }
    )
    public void accettaConCodiceInsegnanteNonValidoTest(String input) {
        SUT.action("Accetta",input);
        verify(view).showError("Codice insegnante non valido");
    }

}