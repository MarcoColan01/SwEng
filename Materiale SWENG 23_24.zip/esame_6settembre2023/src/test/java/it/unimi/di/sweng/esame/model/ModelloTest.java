package it.unimi.di.sweng.esame.model;

import it.unimi.di.sweng.esame.Observer;
import org.junit.jupiter.api.Test;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

class ModelloTest {
    @Test
    void readFileTest(){
        Modello SUT = new Modello();
        SUT.readFile();
        assertThat(SUT.getState()).hasSize(7);
    }

    @Test
    void addRichiestaTest(){
        Modello SUT = new Modello();
        SUT.addRichiesta(new Supplenza("DP000", 2, "Milano",
                Date.valueOf(LocalDate.of(2020, 5, 13))));
        SUT.addRichiesta(new Supplenza("DP000", 2, "Milano",
                Date.valueOf(LocalDate.of(2021, 5, 13))));
        SUT.addRichiesta(new Supplenza("PS000", 2, "Milano",
                Date.valueOf(LocalDate.of(2020, 5, 13))));
        assertThat(SUT.getState()).hasSize(3);
    }

    @Test
    void accettaRichiestaTest(){
        Modello SUT = new Modello();
        SUT.addRichiesta(new Supplenza("DP000", 2, "Milano",
                Date.valueOf(LocalDate.of(2020, 5, 13))));
        SUT.addRichiesta(new Supplenza("DP000", 2, "Milano",
                Date.valueOf(LocalDate.of(2021, 5, 13))));
        SUT.accettaRichiesta("S34A", "DP000", Date.valueOf(LocalDate.of(2021, 5, 13)));
        assertThat(SUT.getState()).hasSize(1);
    }

    @Test
    void accettaRichiestaNonPresenteTest(){
        Modello SUT = new Modello();
        SUT.addRichiesta(new Supplenza("DP000", 2, "Milano",
                Date.valueOf(LocalDate.of(2020, 5, 13))));
        assertThatThrownBy(() -> SUT.accettaRichiesta("S34A", "DP001",
                Date.valueOf(LocalDate.of(2021, 5, 13))))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Richiesta non presente");
    }

    @Test
    void notifyObserversTest(){
        Modello SUT = new Modello();
        Observer<List<Supplenza>> obs1 = mock(Observer.class);
        SUT.addObserver(obs1);
        SUT.addRichiesta(new Supplenza("DP000", 2, "Milano",
                Date.valueOf(LocalDate.of(2020, 5, 13))));
        verify(obs1).update(SUT);
    }

}