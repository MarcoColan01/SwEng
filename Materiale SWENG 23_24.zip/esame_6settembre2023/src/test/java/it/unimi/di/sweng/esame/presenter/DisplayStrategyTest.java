package it.unimi.di.sweng.esame.presenter;

import it.unimi.di.sweng.esame.model.Supplenza;
import org.junit.jupiter.api.Test;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

class DisplayStrategyTest {
    @Test
    void leftViewStrategyTest(){
        DisplayStrategy SUT = LeftViewStrategy.INSTANCE;
        List<Supplenza> supplenze = new ArrayList<>();
        Supplenza s1 = new Supplenza("BG202", 1, "Varese",
                Date.valueOf(LocalDate.of(2023, 9, 3)));
        Supplenza s2 = new Supplenza("BG202", 1, "Bergamo",
                Date.valueOf(LocalDate.of(2023, 9, 4)));
        Supplenza s3 = new Supplenza("BG202", 1, "Varese",
                Date.valueOf(LocalDate.of(2023, 9, 2)));
        supplenze.add(s1);
        supplenze.add(s2);
        supplenze.add(s3);
        SUT.sortView(supplenze);
        assertThat(supplenze).containsExactly(s2, s3, s1);
    }

    @Test
    void leftViewDisplayStrategyTest(){
        DisplayStrategy SUT = LeftViewStrategy.INSTANCE;
        Supplenza s1 = new Supplenza("BG202", 1, "Varese",
                Date.valueOf(LocalDate.of(2023, 9, 3)));
        assertThat(SUT.getSupplenza(s1)).isEqualTo("Varese : dal 03/09/2023 - BG202");
    }

    @Test
    void rightViewStrategyTest(){
        DisplayStrategy SUT = RightViewStrategy.INSTANCE;
        List<Supplenza> supplenze = new ArrayList<>();
        Supplenza s1 = new Supplenza("BG202", 4, "Varese",
                Date.valueOf(LocalDate.of(2023, 9, 3)));
        Supplenza s2 = new Supplenza("BG202", 2, "Bergamo",
                Date.valueOf(LocalDate.of(2023, 9, 4)));
        Supplenza s3 = new Supplenza("BG202", 4, "Varese",
                Date.valueOf(LocalDate.of(2023, 9, 2)));
        supplenze.add(s1);
        supplenze.add(s2);
        supplenze.add(s3);
        SUT.sortView(supplenze);
        assertThat(supplenze).containsExactly(s2, s3, s1);
    }

    @Test
    void rightViewDisplayStrategyTest(){
        DisplayStrategy SUT = RightViewStrategy.INSTANCE;
        Supplenza s1 = new Supplenza("BG202", 1, "Varese",
                Date.valueOf(LocalDate.of(2023, 9, 3)));
        assertThat(SUT.getSupplenza(s1)).isEqualTo("1 : dal 03/09/2023 - BG202");
    }
}