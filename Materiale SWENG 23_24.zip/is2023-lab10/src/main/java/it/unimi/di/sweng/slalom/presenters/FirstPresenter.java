package it.unimi.di.sweng.slalom.presenters;

import it.unimi.di.sweng.slalom.model.Model;
import it.unimi.di.sweng.slalom.views.OutputView;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class FirstPresenter implements Presenter{
    private final Model model;
    private final List<OutputView> views = new ArrayList<>();

    public FirstPresenter(Model model) {
        this.model = model;
    }

    @Override
    public void action(@NotNull String name, @NotNull String time) {
        model.setTime(name, Double.parseDouble(time));
    }

    @Override
    public void addView(OutputView view) {

    }

    @Override
    public void update(Model model, String name, double input) {
        for (OutputView view :  views) {

        }
    }
}
