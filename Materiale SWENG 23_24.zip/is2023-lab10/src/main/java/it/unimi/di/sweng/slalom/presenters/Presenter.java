package it.unimi.di.sweng.slalom.presenters;

import it.unimi.di.sweng.slalom.model.Model;
import it.unimi.di.sweng.slalom.views.OutputView;
import org.jetbrains.annotations.NotNull;

public interface Presenter {
  void action(@NotNull String text1, @NotNull String text2);

  void addView(OutputView view);

  void update(Model model, String name, double input);
}
