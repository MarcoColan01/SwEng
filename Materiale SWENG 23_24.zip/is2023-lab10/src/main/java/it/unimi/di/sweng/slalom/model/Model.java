package it.unimi.di.sweng.slalom.model;

import org.jetbrains.annotations.NotNull;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Model {

    private final Map<String, Double> sciatori = new LinkedHashMap<>();
    public void readFilePrimaManche(@NotNull Scanner s) {
        while (s.hasNextLine()) {
            String linea = s.nextLine();
            String[] el = linea.split(";");
            String name = el[0];
            double time = Double.parseDouble(el[1]);
            sciatori.put(name, time);
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
      for (String s : sciatori.keySet()) {
        sb.append(s).append(";").append(sciatori.get(s)).append("\n");
      }
      return sb.deleteCharAt(sb.length()-1).toString();
    }

    public void setTime(@NotNull String name, double time) {
        sciatori.put(name, time);
    }

    public double getTime(@NotNull String name) {
        return sciatori.get(name);
    }
}
