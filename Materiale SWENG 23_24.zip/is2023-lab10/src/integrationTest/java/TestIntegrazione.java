import static org.assertj.core.api.Assertions.assertThat;
import static org.testfx.api.FxAssert.verifyThat;
import static org.testfx.matcher.control.LabeledMatchers.hasText;

import it.unimi.di.sweng.slalom.Main;
import it.unimi.di.sweng.slalom.views.NextSkierView;
import it.unimi.di.sweng.slalom.views.RankView;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import org.assertj.core.util.introspection.FieldSupport;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.testfx.api.FxRobot;
import org.testfx.framework.junit5.ApplicationExtension;
import org.testfx.framework.junit5.Start;


@ExtendWith(ApplicationExtension.class)
@TestMethodOrder(MethodOrderer.MethodName.class)
public class TestIntegrazione  {
  private RankView firstRun;
  private RankView secondRun;
  private RankView totalRun;
  private NextSkierView nextSkier;
  private Label errorMessage;

  private static final boolean HEADLESS = false;


  @BeforeAll
  public static void setupSpec() {
    if (HEADLESS) System.setProperty("testfx.headless", "true");
  }

  @Start
  public void start(Stage primaryStage) {
    Main m = new Main();
    m.start(primaryStage);

    GridPane gp = (GridPane) primaryStage.getScene().getRoot();
    ObservableList<Node> view = gp.getChildren();

    nextSkier = (NextSkierView) view.get(0);

    firstRun = (RankView) view.get(1);
    secondRun = (RankView) view.get(2);
    totalRun = (RankView) view.get(3);
    errorMessage = FieldSupport.EXTRACTION.fieldValue("error", Label.class, nextSkier);

  }

  @Test
  public void testSomething(FxRobot robot) {
    assertThat(firstRun.get(2)).startsWith("BRIGNONE Federica").endsWith("57.98");
    assertThat(nextSkier.getName()).startsWith("STJERNESUND Thea Louise");

    robot.doubleClickOn(nextSkier);
    robot.write("57.50");
    robot.press(KeyCode.ENTER);
    robot.release(KeyCode.ENTER);
    assertThat(secondRun.get(0)).startsWith("STJERNESUND").endsWith("57.50");
    assertThat(totalRun.get(0)).startsWith("STJERNESUND").endsWith("1:56.89");

    robot.doubleClickOn(nextSkier);
    robot.write("58.90");
    robot.press(KeyCode.ENTER);
    robot.release(KeyCode.ENTER);

    robot.doubleClickOn(nextSkier);
    robot.write("58.81");
    robot.press(KeyCode.ENTER);
    robot.release(KeyCode.ENTER);

    assertThat(secondRun.get(0)).startsWith("STJERNESUND").endsWith("57.50");
    assertThat(secondRun.get(1)).startsWith("VLHOVA");
    assertThat(secondRun.get(2)).startsWith("LIENSBERGER");

    assertThat(totalRun.get(0)).startsWith("STJERNESUND");
    assertThat(totalRun.get(1)).startsWith("VLHOVA").endsWith("1:58.15");
    assertThat(totalRun.get(2)).startsWith("LIENSBERGER").endsWith("1:58.24");
  }

  @Test
  public void testInputNonValido(FxRobot robot) {
    robot.doubleClickOn(nextSkier);
    robot.write("-20");
    robot.press(KeyCode.ENTER);
    robot.release(KeyCode.ENTER);
    verifyThat(errorMessage, hasText("Tempo deve essere positivo"));
  }


  @Test
  public void testInputNonValido2(FxRobot robot) {
    for (int i = 0; i < 15; i++) {
      robot.doubleClickOn(nextSkier);
      robot.write("55");
      robot.press(KeyCode.ENTER);
      robot.release(KeyCode.ENTER);
      verifyThat(errorMessage, hasText(""));
    }
    robot.doubleClickOn(nextSkier);
    robot.write("55");
    robot.press(KeyCode.ENTER);
    robot.release(KeyCode.ENTER);
    verifyThat(errorMessage, hasText("Gara già finita"));
  }

  @Test
  public void testInputNonValido3(FxRobot robot) {
    robot.doubleClickOn(nextSkier);
    robot.write("76.5");
    robot.press(KeyCode.ENTER);
    robot.release(KeyCode.ENTER);
    verifyThat(errorMessage, hasText("Il tempo della singola manche deve essere inferiore ai 60 secondi"));
  }

  @Test
  public void testInputNonValido4(FxRobot robot) {
    robot.doubleClickOn(nextSkier);
    robot.write("pippo");
    robot.press(KeyCode.ENTER);
    robot.release(KeyCode.ENTER);
    verifyThat(errorMessage, hasText("Il tempo deve essere un numero"));
  }
}
