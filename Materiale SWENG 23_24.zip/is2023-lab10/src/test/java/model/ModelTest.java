package model;

import it.unimi.di.sweng.slalom.model.Model;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import static org.assertj.core.api.Assertions.assertThat;

public class ModelTest {

    @ParameterizedTest
    @CsvSource({"'BRIGNONE Federica;57.98\n" +
            "GASIENICA-DANIEL Maryna;59.24\n" +
            "GISIN Michelle;59.19\n" +
            "GUT-BEHRAMI Lara;59.07\n" +
            "HECTOR Sara;57.56\n" +
            "HOLDENER Wendy;59.21\n" +
            "HROVAT Meta;58.48\n" +
            "LIENSBERGER Katharina;59.34\n" +
            "MOWINCKEL Ragnhild;58.58\n" +
            "O BRIEN Nina;58.81\n" +
            "RAST Camille;59.29\n" +
            "STJERNESUND Thea Louise;59.39\n" +
            "TRUPPE Katharina;57.86\n" +
            "VLHOVA Petra;59.34\n" +
            "WORLEY Tessa;58.93'"})
    void readSciatoriTest(String output){
        Model SUT = new Model();
        Scanner s = null;
        try {
            s = new Scanner(new File("C:\\Users\\cola0\\is2023-lab10\\src\\main\\resources\\first"));
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        SUT.readFilePrimaManche(s);
        assertThat(SUT.toString()).isEqualTo(output);
    }
    @Test
    void testSetterGetter(){
        Model model = new Model();
        model.setTime("GIOVANNI rossi", 51.47);
        assertThat(model.getTime("GIOVANNI rossi")).isEqualTo(51.47);
    }

}
