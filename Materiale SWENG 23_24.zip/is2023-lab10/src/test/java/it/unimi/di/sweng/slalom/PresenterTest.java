package it.unimi.di.sweng.slalom;

import it.unimi.di.sweng.slalom.model.Model;
import it.unimi.di.sweng.slalom.presenters.FirstPresenter;
import it.unimi.di.sweng.slalom.views.OutputView;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;

public class PresenterTest {
    @ParameterizedTest
    @CsvSource({"GIOVANNI rossi;51.34"})
    void actionTest(String input) {
        Model model = mock(Model.class);

        FirstPresenter SUT = new FirstPresenter(model);

        SUT.action(input.split(";")[0], input.split(";")[1]);

        verify(model).setTime(input.split(";")[0], Double.parseDouble(input.split(";")[1]));
    }

    @ParameterizedTest
    @ValueSource(doubles = {58.97})
    void updateTest(double input) {
        OutputView view = mock(OutputView.class);
        Model model = mock(Model.class);
        when(model.getTime("GIOVANNI rossi")).thenReturn(51.43);
        FirstPresenter SUT = new FirstPresenter(model);
        SUT.addView(view);
        SUT.update(model, "GIOVANNI rossi", input);
        verify(model).setTime("GIOVANNI rossi",input);
    }
}
