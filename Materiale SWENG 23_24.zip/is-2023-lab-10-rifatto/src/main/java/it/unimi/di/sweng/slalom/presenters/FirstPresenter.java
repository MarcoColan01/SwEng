package it.unimi.di.sweng.slalom.presenters;

import it.unimi.di.sweng.slalom.Observable;
import it.unimi.di.sweng.slalom.model.Model;
import it.unimi.di.sweng.slalom.views.InputView;
import it.unimi.di.sweng.slalom.views.NextSkierView;
import it.unimi.di.sweng.slalom.views.OutputView;
import it.unimi.di.sweng.slalom.views.RankView;
import org.jetbrains.annotations.NotNull;

public class FirstPresenter implements Presenter{
    private final Model model;
    private final InputView inputView = new NextSkierView();
    private final OutputView outputView = new RankView("First manche", 15);

    public FirstPresenter(@NotNull Model model) {
        this.model = model;
        model.addObserver(this);
        inputView.addHandlers(this);
    }

    @Override
    public void action(@NotNull String text1, @NotNull String text2) {
        
    }

    @Override
    public void update(@NotNull Observable<Model.Sciatore> subject, Model.@NotNull Sciatore state) {

    }
}
