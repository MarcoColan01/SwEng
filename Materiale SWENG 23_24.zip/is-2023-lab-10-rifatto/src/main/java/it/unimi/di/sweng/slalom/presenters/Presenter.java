package it.unimi.di.sweng.slalom.presenters;

import it.unimi.di.sweng.slalom.Observer;
import it.unimi.di.sweng.slalom.model.Model;
import org.jetbrains.annotations.NotNull;

public interface Presenter extends Observer<Model.Sciatore> {
  void action(@NotNull String text1, @NotNull String text2);
}
