package it.unimi.di.sweng.slalom.model;

import it.unimi.di.sweng.slalom.Observable;
import it.unimi.di.sweng.slalom.Observer;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Model implements SciatoriModel {

    private final List<Sciatore> sciatori = new ArrayList<>();
    private final List<Observer> observers = new ArrayList<>();

    @Override
    public void notifiObservers() {
        for (Observer observer : observers) {
            observer.update(this, sciatori);
        }
    }

    @Override
    public void addObserver(@NotNull Observer<Sciatore> obs) {
        observers.add(obs);
    }

    @Override
    public List<Sciatore> getSciatore() {
        return new ArrayList<>(sciatori);
    }

    @Override
    public void setSciatore(@NotNull Sciatore sciatore) {
        sciatori.add(sciatore);
    }

    public static class Sciatore {
        private final String nome;
        private final double tempo;

        public Sciatore(@NotNull String nome, double tempo) {
            this.nome = nome;
            this.tempo = tempo;
        }

        public String getNome() {
            return nome;
        }

        public double getTempo() {
            return tempo;
        }
    }

    public void readFilePrimaManche(@NotNull Scanner s) {
        while (s.hasNextLine()) {
            String linea = s.nextLine();
            String[] el = linea.split(";");
            String name = el[0];
            double time = Double.parseDouble(el[1]);
            Sciatore sciatore = new Sciatore(name, time);
        }
        System.out.println(sciatori);
    }

}
