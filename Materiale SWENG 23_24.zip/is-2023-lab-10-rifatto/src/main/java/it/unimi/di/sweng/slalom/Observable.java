package it.unimi.di.sweng.slalom;

import org.jetbrains.annotations.NotNull;

import it.unimi.di.sweng.slalom.Observer;

public interface Observable<T> {
    void notifiObservers();
    void addObserver(@NotNull Observer<T> obs);
}
