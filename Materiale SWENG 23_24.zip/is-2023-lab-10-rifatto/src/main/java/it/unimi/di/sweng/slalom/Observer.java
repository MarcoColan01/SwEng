package it.unimi.di.sweng.slalom;

import it.unimi.di.sweng.slalom.Observable;
import org.jetbrains.annotations.NotNull;

public interface Observer<T> {
    void update(@NotNull Observable<T> subject, @NotNull T state);
}
