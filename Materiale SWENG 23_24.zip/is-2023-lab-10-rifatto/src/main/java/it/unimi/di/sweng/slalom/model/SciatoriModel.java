package it.unimi.di.sweng.slalom.model;

import it.unimi.di.sweng.slalom.Observable;

import java.util.List;

public interface SciatoriModel extends Observable<Model.Sciatore> {
    List<Model.Sciatore> getSciatore();
    void setSciatore(Model.Sciatore sciatore);
}
