package it.unimi.di.sweng.temperature.presenter;

import it.unimi.di.sweng.temperature.Observable;
import it.unimi.di.sweng.temperature.model.Model;
import org.jetbrains.annotations.NotNull;

public class TemperaturePresenter implements Presenter {
    private final Model model;

    public TemperaturePresenter(Model model) {
        this.model = model;
    }

    @Override
    public void update(@NotNull Observable<Double> subject, @NotNull Double state) {

    }

    @Override
    public void action(@NotNull String text) {
        model.setTemp(Double.parseDouble(text));
    }
}
