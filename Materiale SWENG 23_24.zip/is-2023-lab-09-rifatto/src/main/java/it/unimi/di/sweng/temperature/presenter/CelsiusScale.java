package it.unimi.di.sweng.temperature.presenter;

import it.unimi.di.sweng.temperature.presenter.ScaleStrategy;

public enum CelsiusScale implements ScaleStrategy {
    SCALE;

    @Override
    public double convertFromCelsius(double temperature) {
        return temperature;
    }

    @Override
    public double convertToCelsius(double temperature) {
        return temperature;
    }
}
