package it.unimi.di.sweng.temperature.model.Presenter;

import it.unimi.di.sweng.temperature.model.Model;
import it.unimi.di.sweng.temperature.presenter.ScaleStrategy;
import it.unimi.di.sweng.temperature.presenter.TemperaturePresenter;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class TemperaturePresenterTest {
    @Mock
    Model model;
    @Mock
    ScaleStrategy scale;
    @InjectMocks
    TemperaturePresenter SUT;

    @ParameterizedTest
    @ValueSource(doubles = {0, 34, 93.2})
    void actionTest(double input) {
        SUT.action(String.valueOf(input));
        verify(model).setTemp(input);
    }
}

