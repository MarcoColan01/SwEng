package it.unimi.di.sweng.temperature.model.Presenter;

import it.unimi.di.sweng.temperature.presenter.CelsiusScale;
import it.unimi.di.sweng.temperature.presenter.FahrenheitScale;
import it.unimi.di.sweng.temperature.presenter.ScaleStrategy;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.*;

public class ScaleStrategyTest {
     ScaleStrategy SUT;

     @Test
    void fahrenheitScaleTest(){
         SUT = FahrenheitScale.SCALE;
         assertThat(SUT.convertFromCelsius(34)).isCloseTo(93.2, within(0.01));
     }

    @ParameterizedTest
    @ValueSource(doubles = {50, 30, 20})
    void fahrenheitScaleToCelsiusTest(double input){
        SUT = FahrenheitScale.SCALE;
        assertThat(SUT.convertToCelsius(SUT.convertFromCelsius(input)))
                .isCloseTo(input, within(0.01));
    }
    @Test
    void celsiusScaleTest(){
        SUT = CelsiusScale.SCALE;
        assertThat(SUT.convertToCelsius(40)).isEqualTo(40);
    }
}
