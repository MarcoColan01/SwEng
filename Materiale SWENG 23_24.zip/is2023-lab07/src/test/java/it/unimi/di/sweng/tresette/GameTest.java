package it.unimi.di.sweng.tresette;

import it.unimi.di.sweng.tresette.common.Card;
import it.unimi.di.sweng.tresette.common.Deck;
import it.unimi.di.sweng.tresette.common.Rank;
import it.unimi.di.sweng.tresette.common.Suit;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

//@ExtendWith(MockitoExtension.class)

public class GameTest {
    @ParameterizedTest
    @CsvSource({"5C, RC, 2",
    "AS, CD, 1"})
    void playTurnTest(String carta1, String carta2, String res){
        Deck deck = mock(Deck.class);
        Player p1 = mock(Player.class);
        Player p2 = mock(Player.class);
        Game SUT = new Game(p1,p2,deck);
        when(p1.chooseAttackCard(p2)).thenReturn(Card.of(carta1));
        when(p2.chooseAnswerCard(p1)).thenReturn(Card.of(carta2));
        assertThat(SUT.playTurn()).isEqualTo(Integer.parseInt(res));
    }

    @ParameterizedTest
    @CsvSource({"21, 10, 'Winner: Marco con punteggio: 21'"})
    void playGameTest(String pointsP1, String pointsP2, String res){
        Deck deck = mock(Deck.class);
        Player p1 = mock(Player.class);
        Player p2 = mock(Player.class);
        when(deck.isEmpty()).thenReturn(true);
        when(p1.getPoints()).thenReturn(Integer.parseInt(pointsP1));
        when(p1.getName()).thenReturn("Marco");
        when(p2.getName()).thenReturn("Riccardo");
        when(p2.getPoints()).thenReturn(Integer.parseInt(pointsP2));
        Game SUT = new Game(p1,p2,deck);
        assertThat(SUT.playGame()).isEqualTo(res);
    }
}
