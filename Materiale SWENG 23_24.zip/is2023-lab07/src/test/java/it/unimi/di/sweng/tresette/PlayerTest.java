package it.unimi.di.sweng.tresette;

import it.unimi.di.sweng.tresette.common.Card;
import it.unimi.di.sweng.tresette.common.Rank;
import it.unimi.di.sweng.tresette.common.Suit;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static it.unimi.di.sweng.tresette.MockUtils.whenIterated;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIterable;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
@ExtendWith(MockitoExtension.class)
public class PlayerTest {
    @Test
    void compararePlayersTest(){
        Player p1 = mock(Player.class);
        Player p2 = mock(Player.class);
        when(p1.getPoints()).thenReturn(10);
        when(p2.getPoints()).thenReturn(7);
        when(p1.compareTo(p2)).thenCallRealMethod();
        assertThat(p1.compareTo(p2)).isPositive();
    }

    @Test
    void iterablePlayersTest(){
        Player SUT = new Player("Marco");
        SUT.giveCard(Card.get(Rank.CINQUE, Suit.COPPE));
        assertThatIterable(SUT).hasSize(1);
    }
    @Test
    void playerPointsTest(){
        Player SUT = new Player("Marco");
        SUT.addToPersonalDeck(Card.get(Rank.CINQUE, Suit.COPPE));
        assertThat(SUT.getPoints()).isEqualTo(0);
    }
}
