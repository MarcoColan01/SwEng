package it.unimi.di.sweng.tresette;

import it.unimi.di.sweng.tresette.common.Card;
import it.unimi.di.sweng.tresette.common.Rank;
import it.unimi.di.sweng.tresette.common.Suit;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;


import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

public class StrategyTest{
    @ParameterizedTest
    @CsvSource({
            "AC RD"
    })
    void strategiaAttaccoValMaxTest(String mano1){
        Player p1 = mock(Player.class);
        when(p1.iterator()).thenAnswer(invocation -> of(mano1));
        Strategy SUT = new AtkPointMax(null);
        assertThat(SUT.chooseCard(p1, null)).isEqualTo(
                Card.get(Rank.ASSO, Suit.COPPE));
    }

    @ParameterizedTest
    @CsvSource({
            "AC 3D, 3D",
            "RD 5B, RD"
    })
    void strategiaAttaccoOrdinalMaxTest(String mano1, String res){
        Player p1 = mock(Player.class);
        when(p1.iterator()).thenAnswer(invocation -> of(mano1));
        Strategy SUT = new AtkOrdinalMax(null);
        assertThat(SUT.chooseCard(p1, null)).isEqualTo(Card.of(res));
    }

    @ParameterizedTest
    @CsvSource({
            "AC 3D, 2D, 3D"
    })
    void strategiaDifesaOrdinalMaxTest(String mano1, String playedCard, String res){
        Player p1 = mock(Player.class);
        when(p1.iterator()).thenAnswer(invocation -> of(mano1));
        Strategy SUT = new DifOrdinalMax(Strategy.NULL);
        assertThat(SUT.chooseCard(p1, Card.of(playedCard))).isEqualTo(Card.of(res));
    }

    @ParameterizedTest
    @CsvSource({
            "AC 3D, 3D",
            "RD 5B, RD"
    })
    void strategiaAttaccoTreTest(String mano1, String res){
        Player p1 = mock(Player.class);
        when(p1.iterator()).thenAnswer(invocation -> of(mano1));
        Strategy SUT = new AtkTre(Strategy.NULL);
        assertThat(SUT.chooseCard(p1, null)).isEqualTo(Card.of(res));
    }

    @ParameterizedTest
    @CsvSource({
            "AC 3D, 3D",
            "RD 2B, 2B"
    })
    void strategiaAttaccoChainedTest1(String mano1, String res){
        Player p1 = mock(Player.class);
        when(p1.iterator()).thenAnswer(invocation -> of(mano1));
        Strategy SUT = new AtkTre(new AtkOrdinalMax(Strategy.NULL));
        assertThat(SUT.chooseCard(p1, null)).isEqualTo(Card.of(res));
    }

    private static Iterator<Card> of(String mano) {
        List<Card> cards = new ArrayList<>();
        for (String str : mano.split(" ")) {
            cards.add(Card.of(str));
        }
        return new ArrayList<>(cards).iterator();
    }
}
