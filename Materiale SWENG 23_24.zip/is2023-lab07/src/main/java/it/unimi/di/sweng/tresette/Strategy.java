package it.unimi.di.sweng.tresette;

import it.unimi.di.sweng.tresette.common.Card;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public interface Strategy {
 Strategy NULL = new Strategy() {
   @Override
   public @NotNull Card chooseCard(Player player, Card playedCard) {
     return player.iterator().next();
   }
 };

  @NotNull
  Card chooseCard(Player player, Card playedCard);
}
