package it.unimi.di.sweng.tresette;

import it.unimi.di.sweng.tresette.common.Card;
import it.unimi.di.sweng.tresette.common.Rank;
import org.jetbrains.annotations.NotNull;

public class AtkTre implements Strategy {
    private final Strategy next;
    public AtkTre(Strategy next) {
        this.next = next;
    }

    @Override
    public @NotNull Card chooseCard(Player player, Card playedCard) {
        for(Card card: player){
            if(card.getRank().equals(Rank.TRE)) return card;
        }
        return next.chooseCard(player, playedCard);
    }
}
