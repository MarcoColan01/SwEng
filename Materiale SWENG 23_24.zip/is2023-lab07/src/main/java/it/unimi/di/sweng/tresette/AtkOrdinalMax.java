package it.unimi.di.sweng.tresette;

import it.unimi.di.sweng.tresette.common.Card;
import org.jetbrains.annotations.NotNull;

public class AtkOrdinalMax implements Strategy {
    private final Strategy next;
    public AtkOrdinalMax(Strategy next) {
        this.next = next;
    }

    @Override
    public @NotNull Card chooseCard(Player player, Card playedCard) {
        Card cardToPlay = player.iterator().next();
        for(Card card: player){
            if(card.getRank().ordinal() < cardToPlay.getRank().ordinal()) cardToPlay = card;
        }
        if(cardToPlay.getRank().ordinal() < 5) return cardToPlay;
        return next.chooseCard(player, playedCard);
    }
}
