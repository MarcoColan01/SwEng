package it.unimi.di.sweng.tresette;

import it.unimi.di.sweng.tresette.common.Card;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class AtkPointMax implements Strategy {
    private final Strategy next;
    public AtkPointMax(Strategy next) {
        this.next = next;
    }

    @Override
    public @NotNull Card chooseCard(Player player, Card playedCard) {
        Card cardToPlay = player.iterator().next();
        for(Card card: player){
            if(card.getRank().points() > cardToPlay.getRank().points()) cardToPlay = card;
        }
        if(cardToPlay.getRank().points() > 0.0) return cardToPlay;
        return next.chooseCard(player, playedCard);
    }
}
