package it.unimi.di.sweng.tresette.common;

public enum Rank {
  //TODO se volete potete aggiunge attributi e metodi


  TRE(0.3),
  DUE(0.3),
  ASSO(1),
  RE(0.3),
  CAVALLO(0.3),
  FANTE(0.3),
  SETTE(0),
  SEI(0),
  CINQUE(0),
  QUATTRO(0);

  private final double points;

  Rank(double points) {
    this.points = points;
  }

  public double points() {
    return points;
  }
}
