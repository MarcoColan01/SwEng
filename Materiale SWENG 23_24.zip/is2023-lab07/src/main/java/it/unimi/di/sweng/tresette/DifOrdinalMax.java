package it.unimi.di.sweng.tresette;

import it.unimi.di.sweng.tresette.common.Card;
import org.jetbrains.annotations.NotNull;

public class DifOrdinalMax implements Strategy {
    private final Strategy next;
    public DifOrdinalMax(Strategy next) {
        this.next = next;
    }

    @Override
    public @NotNull Card chooseCard(Player player, Card playedCard) {
        Card cardToPlay = null;
        for(Card card: player){
            if(card.getSuit().equals(playedCard.getSuit())){
                if(cardToPlay == null || (card.getRank().ordinal() < cardToPlay.getRank().ordinal()))
                    cardToPlay = card;
            }
        }
        if(cardToPlay == null) return next.chooseCard(player, playedCard);
        return cardToPlay;
    }
}
