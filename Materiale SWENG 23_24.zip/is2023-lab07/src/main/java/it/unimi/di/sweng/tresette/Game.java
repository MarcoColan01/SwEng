package it.unimi.di.sweng.tresette;

import it.unimi.di.sweng.tresette.common.Card;
import it.unimi.di.sweng.tresette.common.Deck;
import it.unimi.di.sweng.tresette.common.Rank;
import it.unimi.di.sweng.tresette.common.Suit;
import org.jetbrains.annotations.NotNull;

public class Game {

    private final Deck deck;
    private final Player[] players = new Player[2];

    @NotNull
    private Player attackPlayer;

    public Game(@NotNull Player p1, @NotNull Player p2, @NotNull Deck d) {
        deck = d;
        players[0] = p1;
        players[1] = p2;
        attackPlayer = p1;
    }

    @NotNull
    public Player opponentOf(@NotNull Player player) {
        if (players[0] == player)
            return players[1];
        return players[0];
    }

    public int playTurn() {
        Card attackCard = attackPlayer.chooseAttackCard(opponentOf(attackPlayer));
        Card answerCard = opponentOf(attackPlayer).chooseAnswerCard(attackPlayer);
        attackPlayer = establishTurnWinner(attackCard, answerCard);
        attackPlayer.addToPersonalDeck(attackCard);
        attackPlayer.addToPersonalDeck(answerCard);
        if(attackPlayer == players[0]) return 1;
        return 2;
    }

    private @NotNull Player establishTurnWinner(Card attackCard, Card answerCard) {
        if (!attackCard.getSuit().equals(answerCard.getSuit())) return attackPlayer;
        if (attackCard.getRank().ordinal() > answerCard.getRank().ordinal()) return opponentOf(attackPlayer);
        return attackPlayer;
    }

    public @NotNull String playGame() {
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < 10; i++){
            players[0].giveCard(deck.draw());
            players[1].giveCard(deck.draw());
        }
        while(!deck.isEmpty()){
            attackPlayer.giveCard(deck.draw());
            opponentOf(attackPlayer).giveCard(deck.draw());
            playTurn();
        }
        attackPlayer.giveCard(Card.get(Rank.ASSO, Suit.DENARI));
        sb.append("Winner: ");
        if(attackPlayer.compareTo(opponentOf(attackPlayer)) > 0)
            sb.append(attackPlayer.getName()).append(" con punteggio: ").append(attackPlayer.getPoints());
        else sb.append(opponentOf(attackPlayer).getName()).append(" con punteggio: ").append(opponentOf(attackPlayer).getPoints());
        return sb.toString();
    }
}
