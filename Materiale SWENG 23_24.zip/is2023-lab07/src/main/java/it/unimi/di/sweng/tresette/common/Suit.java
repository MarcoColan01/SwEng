package it.unimi.di.sweng.tresette.common;

public enum Suit {
  SPADE, COPPE, DENARI, BASTONI;
}
