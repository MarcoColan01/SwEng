package it.unimi.di.sweng.tresette;

import it.unimi.di.sweng.tresette.common.Card;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Player implements Comparable<Player>, Iterable<Card>{


  private @NotNull final String name;
  private @NotNull final List<Card> cards = new ArrayList<>();
  private @NotNull final List<Card> personalDeck = new ArrayList<>();
  private Strategy attackStrategy;
  private Strategy answerStrategy;


  public Player(@NotNull String name) {
    this.name = name;
  }

  public void giveCard(@NotNull Card card){
    cards.add(card);
  }

  public void setAnswerStrategy(@NotNull Strategy answerStrategy){
    this.answerStrategy = answerStrategy;
  }

  public void setAttackStrategy(@NotNull Strategy attackStrategy){
    this.attackStrategy = attackStrategy;
  }

  public void addToPersonalDeck(@NotNull Card card){
    personalDeck.add(card);
  }

  @NotNull
  private Card chooseCardWithStrategy(Player opponent, @NotNull Strategy strategy) {
    Card card = null;
    return card;
  }

  @NotNull
  public Card chooseAttackCard(Player opponent) {
    return chooseCardWithStrategy(opponent, attackStrategy);
  }

  @NotNull
  public Card chooseAnswerCard(Player opponent) {
    return chooseCardWithStrategy(opponent, answerStrategy);
  }

  public int getPoints() {
    int points = 0;
    for(Card card: personalDeck){
       points += (int) card.getRank().points();
    }
    return points;
  }

  @NotNull
  public String getName() {
    return name;
  }

  @Override
  @NotNull
  public String toString() {
    return getName() +
        " <" + getPoints() + ">" +
        " " + cards;
  }

  public void shoutResult() {
    System.out.printf("Sono %s e ho vinto con %d punti%n", getName(), getPoints());
  }

  @Override
  public int compareTo(@NotNull Player enemy) {
    return Integer.compare(this.getPoints(), enemy.getPoints());
  }

  @NotNull
  @Override
  public Iterator<Card> iterator() {
    return new ArrayList<>(cards).iterator();
  }
}
