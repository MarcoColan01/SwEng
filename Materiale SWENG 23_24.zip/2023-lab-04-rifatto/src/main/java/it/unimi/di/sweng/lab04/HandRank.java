package it.unimi.di.sweng.lab04;

public enum HandRank {
    ONE_PAIR,
    TWO_PAIR,
    FLUSH,
    THREE_OF_A_KIND,
    HIGH_CARD
}
